# language: Python 3.10+, file: epic_store.py
# Поиск цен в Epic Games Store и открытие браузера.

import json
import sys
import urllib.parse
import webbrowser

try:
    import requests
except ImportError:
    requests = None

from logger import get_logger

log = get_logger()

# Эндпоинт https://graphql.epicgames.com/graphql больше не работает (404/410).
# Актуальные хосты, которые использует сам store.epicgames.com и лаунчер.
_GRAPHQL_ENDPOINTS = [
    "https://store.epicgames.com/graphql",
    "https://www.epicgames.com/graphql",
    "https://launcher.store.epicgames.com/graphql",
]

_GRAPHQL_QUERY = """
query SearchStoreQuery($locale: String!, $country: String!, $limit: Int!, $offset: Int!, $q: String!) {
    searchStoreQuery(locale: $locale, country: $country, limit: $limit, offset: $offset, q: $q) {
        elements {
            product {
                title
                urlSlug
                namespace
                id
                isFree
                offers {
                    price {
                        finalPrice
                        originalPrice
                    }
                    promotion {
                        discountPercentage
                    }
                }
                catalogNs {
                    mappings {
                        pageSlug
                    }
                }
            }
        }
    }
}
"""


def _get_json(url: str) -> dict | None:
    if requests:
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "application/json"
        }
        try:
            resp = requests.get(url, headers=headers, timeout=10)
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            log.debug(f"Epic GET error: {e}")
            return None
    else:
        import urllib.request
        req = urllib.request.Request(url)
        req.add_header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read().decode())
        except Exception as e:
            log.debug(f"Epic urllib error: {e}")
            return None


def search_epic(query: str) -> list[dict]:
    """Поиск игры в Epic Games Store через GraphQL.

    Перебирает несколько хостов, потому что старый
    graphql.epicgames.com/graphql отключён и отдаёт 404.
    """
    if not query or not query.strip():
        return []

    variables = {
        "locale": "en-US",
        "country": "US",
        "limit": 5,
        "offset": 0,
        "q": query.strip()
    }
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Content-Type": "application/json"
    }
    payload = {"query": _GRAPHQL_QUERY, "variables": variables}

    last_error = None
    for endpoint in _GRAPHQL_ENDPOINTS:
        try:
            if requests:
                resp = requests.post(endpoint, json=payload, headers=headers, timeout=10)
                resp.raise_for_status()
                data = resp.json()
            else:
                import urllib.request
                req = urllib.request.Request(
                    endpoint,
                    data=json.dumps(payload).encode("utf-8"),
                    headers=headers,
                    method="POST"
                )
                with urllib.request.urlopen(req, timeout=10) as r:
                    data = json.loads(r.read().decode("utf-8", errors="ignore"))

            if isinstance(data, dict):
                elements = data.get("data", {}).get("searchStoreQuery", {}).get("elements", [])
                if isinstance(elements, list):
                    if elements:
                        log.info("Epic GraphQL: %s вернул %d результатов для '%s'", endpoint, len(elements), query)
                    return elements
                # Если структура ответа неожиданная — пробуем следующий хост.
                log.debug("Epic GraphQL %s: неожиданная структура ответа", endpoint)
        except Exception as e:
            last_error = e
            log.debug("Epic GraphQL %s ошибка: %s", endpoint, e)

    log.warning("Epic GraphQL: все эндпоинты недоступны для '%s' (%s)", query, last_error)
    return []


def get_price(item: dict) -> str:
    try:
        product = item.get("product", {})
        if product.get("isFree"):
            return "БЕСПЛАТНО"

        offers = product.get("offers") or []
        offer = offers[0] if offers else {}

        price_info = offer.get("price", {})
        final_price = price_info.get("finalPrice", 0)
        original_price = price_info.get("originalPrice", 0)

        promotion = offer.get("promotion", {})
        if promotion and promotion.get("discountPercentage") == 100:
            return "БЕСПЛАТНО"

        if not final_price and not original_price:
            return "Цена не указана"

        price_str = f"${final_price / 100:.2f}"

        if original_price > final_price:
            discount = int((1 - final_price / original_price) * 100)
            price_str += f" (было ${original_price / 100:.2f}, -{discount}%)"

        return price_str
    except Exception:
        return "Цена не указана"


def get_store_url(item: dict) -> str:
    try:
        product = item.get("product", {})

        catalog_ns = product.get("catalogNs") or {}
        mappings = catalog_ns.get("mappings") or []
        for m in mappings:
            if isinstance(m, dict) and m.get("pageSlug"):
                return f"https://store.epicgames.com/en-US/p/{m['pageSlug']}"

        slug = product.get("urlSlug") or product.get("slug")
        if slug:
            return f"https://store.epicgames.com/en-US/p/{slug}"

    except Exception:
        pass
    return ""


def find_and_open_store(game_name: str) -> bool:
    """Ищет игру в Epic и сразу открывает её страницу в браузере."""
    log.info(f"Поиск в Epic Store: {game_name}")
    results = search_epic(game_name)

    if not results:
        log.info("В Epic ничего не найдено, открываем поиск.")
        search_url = f"https://store.epicgames.com/en-US/browse?q={urllib.parse.quote_plus(game_name)}"
        webbrowser.open(search_url)
        return True

    best = results[0]
    url = get_store_url(best)
    price = get_price(best)

    log.info(f"Найдено в Epic: {best.get('product', {}).get('title', game_name)} | Цена: {price}")

    if url:
        webbrowser.open(url)
        return True
    else:
        search_url = f"https://store.epicgames.com/en-US/browse?q={urllib.parse.quote_plus(game_name)}"
        webbrowser.open(search_url)
        return True