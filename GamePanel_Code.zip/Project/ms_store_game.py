# language: Python 3.10+, file: ms_store_game.py
# Поиск цен в Microsoft Store и открытие браузера.

import sys
import webbrowser
from urllib.parse import quote_plus

try:
    import requests
    from bs4 import BeautifulSoup
except ImportError:
    requests = None
    BeautifulSoup = None

from logger import get_logger

log = get_logger()


def search_microsoft_store(game_name: str) -> list[dict]:
    """Поиск игры в Microsoft Store и возврат списка результатов."""
    if not requests or not BeautifulSoup:
        log.error("ms_store_game: не установлены requests или beautifulsoup4")
        return []

    url = f"https://www.microsoft.com/en-us/store/search?q={quote_plus(game_name)}"
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        )
    }

    try:
        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()
    except requests.RequestException as e:
        log.warning(f"MS Store search failed: {e}")
        return []

    soup = BeautifulSoup(response.text, "html.parser")

    products = []
    for card in soup.find_all("div", class_=lambda c: c and "ProductCard" in c):
        name_el = card.find("span", string=lambda s: s and len(s.strip()) > 0)
        if not name_el:
            continue

        price_el = card.find("span", class_=lambda c: c and "price" in c.lower())
        price = price_el.get_text(strip=True) if price_el else "Цена не указана"

        link_el = card.find("a")
        link = ""
        if link_el and link_el.get("href"):
            href = link_el["href"]
            link = f"https://www.microsoft.com{href}" if href.startswith("/") else href

        name = name_el.get_text(strip=True)
        products.append({"name": name, "price": price, "link": link})

    return products


def find_and_open_store(game_name: str) -> bool:
    """Ищет игру и сразу открывает её страницу (или поиск) в браузере."""
    log.info(f"Поиск в MS Store: {game_name}")
    products = search_microsoft_store(game_name)

    if not products:
        # Если парсинг не удался (Cloudflare) или пусто — открываем страницу поиска
        log.info("Прямые результаты не найдены, открываем поиск.")
        search_url = f"https://www.microsoft.com/en-us/store/search?q={quote_plus(game_name)}"
        webbrowser.open(search_url)
        return True

    # Берем первый результат (самый релевантный)
    best = products[0]
    if best["link"]:
        log.info(f"Открываем страницу игры: {best['link']}")
        webbrowser.open(best["link"])
        return True
    else:
        search_url = f"https://www.microsoft.com/en-us/store/search?q={quote_plus(game_name)}"
        webbrowser.open(search_url)
        return True