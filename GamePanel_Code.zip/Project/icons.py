# language: Python 3.10+, file: icons.py
# Иконки exe + обложки Steam и Epic.

import os
import io
import re
import json
import ctypes
import ctypes.wintypes
import urllib.parse
import urllib.request
import threading
from concurrent.futures import ThreadPoolExecutor
from PIL import Image, ImageTk, ImageDraw, ImageFont, ImageOps
from config import CACHE_DIR, state
from logger import get_logger

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

log = get_logger()

def get_dpi_scale():
    if os.name != "nt": return 1.0
    try:
        hdc = ctypes.windll.user32.GetDC(0)
        dpi = ctypes.windll.gdi32.GetDeviceCaps(hdc, 88)
        ctypes.windll.user32.ReleaseDC(0, hdc)
        return dpi / 96.0
    except Exception:
        return 1.0

SCALE = get_dpi_scale()
ICON_SIZE = (int(160 * SCALE), int(75 * SCALE))

_icon_executor = ThreadPoolExecutor(max_workers=4)

# Карточки в библиотеке пересоздаются при прокрутке (виртуализация), поэтому:
#  • _label_for_title хранит ПОСЛЕДНИЙ label игры — готовая обложка применяется к нему,
#    а не к уже уничтоженному виджету;
#  • _inflight не даёт запускать повторную загрузку одной и той же обложки.
_label_for_title = {}
_inflight = set()
_inflight_lock = threading.Lock()

def _safe_name(title):
    return re.sub(r'[<>:"/\\|?*]', "_", title)

def _cache_path(title):
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
    except OSError as e:
        log.error(f"Не создать CACHE_DIR: {e}")
    return os.path.join(CACHE_DIR, f"{_safe_name(title)}_v12.png")

def _save_cache_atomic(img, path):
    tmp = path + ".tmp"
    try:
        img.save(tmp, "PNG")
        os.replace(tmp, path)
        return True
    except Exception as e:
        log.error(f"Не сохранить кэш {path}: {e}")
        try:
            if os.path.exists(tmp): os.remove(tmp)
        except OSError: pass
        return False

def _clean_title(title):
    if not title: return ""
    t = title.replace(" (Epic)", "").replace(" (Steam)", "").replace(" (Microsoft)", "").strip()
    t = re.sub(r'\s*\([a-f0-9]{4}\)$', '', t, flags=re.IGNORECASE)
    for suffix in [" Director's Cut", " Deluxe Edition", " Ultimate Edition", " - Staging Branch", " - Dedicated Server", " Demo", " Beta"]:
        if t.lower().endswith(suffix.lower()): 
            t = t[:-len(suffix)].strip()
    return t

def _pad_cover(img, size=ICON_SIZE):
    img = ImageOps.contain(img, size, method=Image.Resampling.LANCZOS)
    bg = Image.new("RGBA", size, (27, 32, 43, 255))
    bg.paste(img, ((size[0] - img.width) // 2, (size[1] - img.height) // 2), img)
    return bg

def _download_image(url):
    try:
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
        if HAS_REQUESTS:
            r = requests.get(url, headers=headers, timeout=10)
            r.raise_for_status()
            img = Image.open(io.BytesIO(r.content)).convert("RGBA")
        else:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as resp:
                img = Image.open(io.BytesIO(resp.read())).convert("RGBA")
        return _pad_cover(img)
    except Exception:
        return None

STEAM_IMG_FORMATS = ["header.jpg", "capsule_231x87.jpg", "library_600x900.jpg", "library_hero.jpg", "logo.png"]

def _fetch_steam_cover_by_appid(appid):
    base = "https://cdn.cloudflare.steamstatic.com/steam/apps"
    for fmt in STEAM_IMG_FORMATS:
        img_url = f"{base}/{appid}/{fmt}"
        img = _download_image(img_url)
        if img: return img
    return None

def fetch_steam_cover(title, appid=None):
    try:
        clean = _clean_title(title)
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
        
        if appid and str(appid).isdigit():
            img = _fetch_steam_cover_by_appid(appid)
            if img: return img

        encoded = urllib.parse.quote(clean)
        url = f"https://steamcommunity.com/actions/SearchApps/{encoded}"
        try:
            if HAS_REQUESTS:
                r = requests.get(url, headers=headers, timeout=8)
                if r.status_code == 200:
                    data = r.json()
                    if data and len(data) > 0:
                        new_appid = data[0]["appid"]
                        return _fetch_steam_cover_by_appid(new_appid)
            else:
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=8) as resp:
                    data = json.loads(resp.read().decode())
                    if data and len(data) > 0:
                        new_appid = data[0]["appid"]
                        return _fetch_steam_cover_by_appid(new_appid)
        except Exception: 
            pass
        return None
    except Exception as e:
        log.error(f"fetch_steam_cover '{title}': {e}")
        return None

def _pick_epic_image(images):
    wanted = ["DieselStoreFrontWide", "OfferImageWide", "Takeover", "OfferImageTall", "DieselStoreFrontTall", "Thumbnail"]
    for t in wanted:
        for img in images:
            if isinstance(img, dict) and img.get("type") == t and img.get("url"): return img["url"]
    for img in images:
        if isinstance(img, dict) and img.get("url"): return img["url"]
    return None

def _fetch_epic_cover_by_graphql(title):
    clean = _clean_title(title)
    if not clean: return None
    
    query = """
    query searchStoreQuery($keywords: String!, $country: String!, $locale: String!) {
      Catalog {
        searchStore(keywords: $keywords, country: $country, locale: $locale, count: 5) {
          elements { title keyImages { type url } }
        }
      }
    }
    """
    body = json.dumps({"query": query, "variables": {"keywords": clean, "country": "US", "locale": "en-US"}})
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Origin": "https://store.epicgames.com",
        "Referer": "https://store.epicgames.com/"
    }
    
    try:
        if HAS_REQUESTS:
            r = requests.post("https://store.epicgames.com/graphql", data=body, headers=headers, timeout=10)
            r.raise_for_status()
            data = r.json()
        else:
            req = urllib.request.Request("https://store.epicgames.com/graphql", data=body.encode("utf-8"), headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                
        elements = (data.get("data", {}).get("Catalog", {}).get("searchStore", {}).get("elements", []))
        for el in elements:
            if not isinstance(el, dict): continue
            if el.get("title", "").lower() == clean.lower():
                img_url = _pick_epic_image(el.get("keyImages") or [])
                if img_url: return _download_image(img_url)
        if elements and isinstance(elements[0], dict):
            img_url = _pick_epic_image(elements[0].get("keyImages") or [])
            if img_url: return _download_image(img_url)
    except Exception: 
        pass
    return None

def fetch_epic_cover(title, namespace=None, catalog_item_id=None):
    return _fetch_epic_cover_by_graphql(title)

class _ICONINFO(ctypes.Structure):
    _fields_ = [("fIcon", ctypes.wintypes.BOOL), ("xHotspot", ctypes.wintypes.DWORD), ("yHotspot", ctypes.wintypes.DWORD), ("hbmMask", ctypes.wintypes.HBITMAP), ("hbmColor", ctypes.wintypes.HBITMAP)]

class _BITMAP(ctypes.Structure):
    _fields_ = [("bmType", ctypes.wintypes.LONG), ("bmWidth", ctypes.wintypes.LONG), ("bmHeight", ctypes.wintypes.LONG), ("bmWidthBytes", ctypes.wintypes.LONG), ("bmPlanes", ctypes.wintypes.WORD), ("bmBitsPixel", ctypes.wintypes.WORD), ("bmBits", ctypes.c_void_p)]

class _BMIH(ctypes.Structure):
    _fields_ = [("biSize", ctypes.wintypes.DWORD), ("biWidth", ctypes.wintypes.LONG), ("biHeight", ctypes.wintypes.LONG), ("biPlanes", ctypes.wintypes.WORD), ("biBitCount", ctypes.wintypes.WORD), ("biCompression", ctypes.wintypes.DWORD), ("biSizeImage", ctypes.wintypes.DWORD), ("biXPelsPerMeter", ctypes.wintypes.LONG), ("biYPelsPerMeter", ctypes.wintypes.LONG), ("biClrUsed", ctypes.wintypes.DWORD), ("biClrImportant", ctypes.wintypes.DWORD)]

def extract_exe_icon(exe_path):
    if not exe_path or not os.path.exists(exe_path) or os.name != "nt": return None
    try:
        user32 = ctypes.windll.user32
        gdi32 = ctypes.windll.gdi32
        user32.PrivateExtractIconsW.restype = ctypes.wintypes.UINT
        user32.PrivateExtractIconsW.argtypes = [ctypes.wintypes.LPCWSTR, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.wintypes.UINT), ctypes.wintypes.UINT, ctypes.wintypes.UINT]
        user32.GetIconInfo.restype = ctypes.wintypes.BOOL
        user32.GetIconInfo.argtypes = [ctypes.c_void_p, ctypes.POINTER(_ICONINFO)]
        user32.DestroyIcon.restype = ctypes.wintypes.BOOL
        user32.DestroyIcon.argtypes = [ctypes.c_void_p]
        user32.GetDC.restype = ctypes.wintypes.HDC
        user32.GetDC.argtypes = [ctypes.wintypes.HWND]
        user32.ReleaseDC.restype = ctypes.c_int
        user32.ReleaseDC.argtypes = [ctypes.wintypes.HWND, ctypes.wintypes.HDC]
        gdi32.GetObjectW.restype = ctypes.c_int
        gdi32.GetObjectW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
        gdi32.CreateCompatibleDC.restype = ctypes.wintypes.HDC
        gdi32.CreateCompatibleDC.argtypes = [ctypes.wintypes.HDC]
        gdi32.SelectObject.restype = ctypes.c_void_p
        gdi32.SelectObject.argtypes = [ctypes.wintypes.HDC, ctypes.c_void_p]
        gdi32.GetDIBits.restype = ctypes.c_int
        gdi32.GetDIBits.argtypes = [ctypes.wintypes.HDC, ctypes.c_void_p, ctypes.wintypes.UINT, ctypes.wintypes.UINT, ctypes.c_void_p, ctypes.POINTER(_BMIH), ctypes.wintypes.UINT]
        gdi32.DeleteDC.restype = ctypes.wintypes.BOOL
        gdi32.DeleteDC.argtypes = [ctypes.wintypes.HDC]
        gdi32.DeleteObject.restype = ctypes.wintypes.BOOL
        gdi32.DeleteObject.argtypes = [ctypes.c_void_p]

        hicon = ctypes.c_void_p()
        size = max(ICON_SIZE)
        n_icons = user32.PrivateExtractIconsW(ctypes.c_wchar_p(exe_path), 0, size, size, ctypes.byref(hicon), None, 1, 0)
        if n_icons <= 0 or not hicon.value: return None
        info = _ICONINFO()
        if not user32.GetIconInfo(hicon, ctypes.byref(info)):
            user32.DestroyIcon(hicon)
            return None
        bmp = _BITMAP()
        gdi32.GetObjectW(info.hbmColor, ctypes.sizeof(bmp), ctypes.byref(bmp))
        w, h = bmp.bmWidth, bmp.bmHeight
        if w == 0 or h == 0:
            user32.DestroyIcon(hicon)
            if info.hbmColor: gdi32.DeleteObject(info.hbmColor)
            if info.hbmMask: gdi32.DeleteObject(info.hbmMask)
            return None
        hdc = user32.GetDC(None)
        mem = gdi32.CreateCompatibleDC(hdc)
        bmi = _BMIH(biSize=ctypes.sizeof(_BMIH), biWidth=w, biHeight=-h, biPlanes=1, biBitCount=32, biCompression=0)
        buf = ctypes.create_string_buffer(w * h * 4)
        old = gdi32.SelectObject(mem, info.hbmColor)
        gdi32.GetDIBits(mem, info.hbmColor, 0, h, buf, ctypes.byref(bmi), 0)
        gdi32.SelectObject(mem, old)
        gdi32.DeleteDC(mem)
        user32.ReleaseDC(None, hdc)
        if info.hbmColor: gdi32.DeleteObject(info.hbmColor)
        if info.hbmMask: gdi32.DeleteObject(info.hbmMask)
        user32.DestroyIcon(hicon)
        
        img = Image.frombytes("RGBA", (w, h), buf.raw, "raw", "BGRA")
        return _pad_cover(img)
    except Exception: return None

def create_fallback_icon(text, size=ICON_SIZE):
    img = Image.new("RGBA", size, color=(27, 32, 43, 255))
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle([0, 0, size[0]-1, size[1]-1], radius=6, outline=(60, 68, 85, 255), width=2)
    
    is_demo = bool(re.search(r"\bdemo\b", str(text), re.IGNORECASE))
    words = [w for w in text.split() if w and w[0].isalnum()]
    initials = "DEMO" if is_demo else ("".join(w[0] for w in words[:2]).upper() if words else "GM")
    initials = re.sub(r"[^A-Za-zА-Яа-я0-9]", "", initials) or "GM"
    
    try: font = ImageFont.truetype("Segoe UI", int((22 if is_demo else 30) * SCALE))
    except IOError: font = ImageFont.load_default()
    
    bbox = draw.textbbox((0, 0), initials, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    draw.text(((size[0] - tw) / 2, (size[1] - th) / 2 - 2), initials, fill=(100, 110, 130, 255), font=font)
    return img

def load_game_icon(title, exe_path, appid=None, label=None,
                   root=None, is_epic=False, namespace=None, catalog_item_id=None, slug=None,
                   icon_path=None):
    if label is not None:
        _label_for_title[title] = label
    cached = _cache_path(title)
    
    if os.path.exists(cached):
        try:
            img = Image.open(cached)
            if img.size != ICON_SIZE: img = _pad_cover(img)
            photo = ImageTk.PhotoImage(img)
            state["icon_cache"][title] = photo
            if label: label.config(image=photo)
            return photo
        except Exception:
            try: os.remove(cached)
            except OSError: pass

    # Для MS Store/Xbox сначала пробуем штатные изображения пакета.
    package_dir = os.path.dirname(exe_path) if exe_path and os.path.isfile(exe_path) else ""
    asset_candidates = [icon_path] if icon_path else []
    if package_dir:
        asset_candidates.extend(os.path.join(package_dir, candidate) for candidate in
            ("Assets/StoreLogo.png", "Assets/Square150x150Logo.png",
             "Assets/Square44x44Logo.png", "StoreLogo.png",
             "Square150x150Logo.png", "Square44x44Logo.png"))
    for asset in asset_candidates:
        if asset and os.path.isfile(asset):
            try:
                with Image.open(asset) as source:
                    img = _pad_cover(source.convert("RGBA"))
                _save_cache_atomic(img, cached)
                photo = ImageTk.PhotoImage(img)
                state["icon_cache"][title] = photo
                if label: label.config(image=photo)
                return photo
            except Exception:
                continue

    # Берем иконку из exe, если игра установлена
    if exe_path and os.path.exists(exe_path):
        img = extract_exe_icon(exe_path)
        if img:
            _save_cache_atomic(img, cached)
            try:
                photo = ImageTk.PhotoImage(img)
                state["icon_cache"][title] = photo
                if label: label.config(image=photo)
                return photo
            except Exception as e: log.error(f"PhotoImage из exe {title}: {e}")

    try:
        photo = ImageTk.PhotoImage(create_fallback_icon(title))
    except Exception as e:
        log.error(f"Fallback icon {title}: {e}")
        return None

    state["icon_cache"][title] = photo
    if label: label.config(image=photo)
    if re.search(r"\bdemo\b", str(title), re.IGNORECASE):
        return photo

    def worker():
        try:
            img = None
            try:
                if is_epic: img = fetch_epic_cover(title, namespace, catalog_item_id)
                if img is None and appid and str(appid).isdigit(): img = fetch_steam_cover(title, appid)
                if img is None and not is_epic: img = fetch_steam_cover(title, None)
            except Exception as e:
                log.error(f"worker иконки '{title}': {e}")

            if img is None and exe_path and os.path.exists(exe_path):
                img = extract_exe_icon(exe_path)

            if img is None: return
            _save_cache_atomic(img, cached)
            def apply():
                target = _label_for_title.get(title) or label
                if not (target and target.winfo_exists()): return
                if getattr(target, "game_title", title) != title: return
                try:
                    new_photo = ImageTk.PhotoImage(img)
                    state["icon_cache"][title] = new_photo
                    target.config(image=new_photo)
                    target.image = new_photo
                except Exception: pass
            if root:
                try: root.after(0, apply)
                except Exception: pass
        finally:
            with _inflight_lock:
                _inflight.discard(title)

    with _inflight_lock:
        if title in _inflight:
            return photo
        _inflight.add(title)
    try:
        _icon_executor.submit(worker)
    except Exception as e:
        with _inflight_lock:
            _inflight.discard(title)
        log.error(f"Очередь иконок '{title}': {e}")

    return photo
