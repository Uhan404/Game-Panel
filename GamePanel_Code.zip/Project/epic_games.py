# language: Python 3.10+, file: epic_games.py
# Epic Games: чтение локальных манифестов + билдеры URI для Launcher.

import os
import re
import json
import glob

from logger import get_logger

log = get_logger()

_NON_GAME_PREFIXES = ("UE_", "QuixelBridge", "Fab_", "Fab", "UnrealEngine")


def ensure_writable_dir(path):
    if not path:
        return False, "Путь пустой."
    try:
        path = os.path.normpath(path)
        if os.path.exists(path) and not os.path.isdir(path):
            return False, f"Путь существует, но это не папка: {path}"
        if not os.path.isdir(path):
            os.makedirs(path, exist_ok=True)
        test_file = os.path.join(path, ".gamepanel_write_test")
        with open(test_file, "w", encoding="utf-8") as f:
            f.write("ok")
        os.remove(test_file)
        return True, None
    except PermissionError:
        return False, f"Нет прав на запись: {path}"
    except OSError as e:
        return False, f"Ошибка доступа к {path}: {e}"
    except Exception as e:
        return False, f"Ошибка с путём {path}: {e}"


MANIFEST_DIRS = [
    r"C:\ProgramData\Epic\EpicGamesLauncher\Data\Manifests",
    os.path.join(os.environ.get("PROGRAMDATA", r"C:\ProgramData"),
                 "Epic", "EpicGamesLauncher", "Data", "Manifests"),
    os.path.join(os.environ.get("LOCALAPPDATA", ""),
                 "EpicGamesLauncher", "Saved", "Manifests"),
    os.path.join(os.environ.get("LOCALAPPDATA", ""), "legendary", "manifests"),
    os.path.join(os.environ.get("APPDATA", ""), "legendary", "manifests"),
    os.path.join(os.environ.get("HOME", ""), ".config", "legendary", "manifests"),
    os.path.join(os.environ.get("APPDATA", ""), "heroic", "legendaryConfig",
                 "legendary", "manifests"),
    os.path.join(os.environ.get("HOME", ""), ".config", "heroic",
                 "legendaryConfig", "legendary", "manifests"),
]


def find_manifest_dir():
    for d in MANIFEST_DIRS:
        try:
            if d and os.path.isdir(d) and glob.glob(os.path.join(d, "*.item")):
                return d
        except OSError:
            continue
    return None


def all_manifest_dirs():
    out = []
    for d in MANIFEST_DIRS:
        try:
            if d and os.path.isdir(d) and glob.glob(os.path.join(d, "*.item")):
                out.append(d)
        except OSError:
            continue
    return out


def manifest_dirs_checked():
    return [d for d in MANIFEST_DIRS if d]


def _looks_like_hash(s: str) -> bool:
    if len(s) < 24:
        return False
    try:
        int(s, 16)
        return True
    except ValueError:
        return False


def _pick_title(g: dict) -> str:
    for k in ("app_title", "title", "DisplayName", "name"):
        v = (g.get(k) or "").strip()
        if v and not _looks_like_hash(v):
            return v
    return (g.get("app_name") or g.get("AppName") or "").strip()


def is_hex(s):
    if not s or len(s) < 24:
        return False
    try:
        int(s, 16)
        return True
    except ValueError:
        return False


def is_non_game(app_name):
    if not app_name:
        return False
    for prefix in _NON_GAME_PREFIXES:
        if app_name.startswith(prefix):
            return True
    return False


def make_epic_slug(title):
    """Генерирует слаг из названия (используется только как fallback, если API ничего не дал)."""
    if not title:
        return ""
    s = title.lower()
    s = re.sub(r'[^a-z0-9]+', '-', s)
    return s.strip('-')


def normalize_epic_slug(raw):
    """Приводит slug продукта Epic к чистому виду.

    Library API и манифесты иногда возвращают slug в разных форматах:
      • "fortnite"                                   → "fortnite"
      • "fortnite/home"                              → "fortnite"
      • "/p/death-stranding"                         → "death-stranding"
      • "https://store.epicgames.com/p/fortnite/home" → "fortnite"
      • "https://store.epicgames.com/en-US/p/fortnite?x=1" → "fortnite"

    Результат всегда — одиночный slug без ведущих/замыкающих слэшей,
    query и fragment. Возвращает "" для пустого входа.
    """
    if not raw:
        return ""
    s = str(raw).strip()
    if not s:
        return ""

    # Полный URL — вытаскиваем хвост после "/p/".
    if "://" in s or s.startswith("store.epicgames.com"):
        if "/p/" in s:
            s = s.split("/p/", 1)[1]
        else:
            s = s.split("/", 3)[-1]

    # Отрезаем query и fragment.
    s = s.split("?", 1)[0].split("#", 1)[0]

    # Отрезаем префикс "/p/" на случай "p/slug/...".
    if s.startswith("p/"):
        s = s[2:]

    # Берём первый сегмент — это и есть slug продукта.
    s = s.strip("/").split("/", 1)[0]
    return s.strip()


def build_epic_target(namespace, app_name, catalog_id):
    """Epic Launcher URI: namespace%3AcatalogItemId%3AappName."""
    namespace = (namespace or "").strip()
    app_name = (app_name or "").strip()
    catalog_id = (catalog_id or "").strip()
    if not (namespace and app_name and catalog_id):
        return ""
    return f"{namespace}%3A{catalog_id}%3A{app_name}"


def build_epic_install_url(data, interactive=True):
    app_name = str(data.get("appid") or "").strip()
    namespace = str(data.get("namespace") or "").strip()
    catalog_id = str(data.get("catalog_item_id") or "").strip()

    if is_non_game(app_name) or data.get("is_dlc"):
        return ""

    suffix = "" if interactive else "&silent=true"

    target = build_epic_target(namespace, app_name, catalog_id)
    if target:
        return f"com.epicgames.launcher://apps/{target}?action=install{suffix}"

    if app_name and not is_hex(app_name):
        return f"com.epicgames.launcher://apps/{app_name}?action=install{suffix}"

    return ""


def build_epic_launch_url(data):
    app_name = str(data.get("appid") or "").strip()
    namespace = str(data.get("namespace") or "").strip()
    catalog_id = str(data.get("catalog_item_id") or "").strip()

    if is_non_game(app_name) or data.get("is_dlc"):
        return ""

    target = build_epic_target(namespace, app_name, catalog_id)
    if target:
        return f"com.epicgames.launcher://apps/{target}?action=launch&silent=true"

    if app_name and not is_hex(app_name):
        return f"com.epicgames.launcher://apps/{app_name}?action=launch&silent=true"

    return ""


def _read_one_manifest(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        return None
    except OSError:
        return None


def read_epic_manifests():
    dirs = all_manifest_dirs()
    if not dirs:
        return {}, "Манифесты Epic не найдены (Epic Launcher не устанавливал игр)."

    out = {}
    for manifest_dir in dirs:
        try:
            items = glob.glob(os.path.join(manifest_dir, "*.item"))
        except OSError:
            continue
        for path in items:
            data = _read_one_manifest(path)
            if not isinstance(data, dict):
                continue
            display = data.get("DisplayName") or data.get("AppName") or ""
            if not display:
                continue
            install_loc = data.get("InstallLocation") or ""
            launch_exe = data.get("LaunchExecutable") or ""
            app_name = data.get("AppName") or ""
            namespace = data.get("CatalogNamespace") or ""
            catalog_id = data.get("CatalogItemId") or ""

            main_game_app_name = data.get("MainGameAppName") or ""
            is_dlc = bool(main_game_app_name)

            exe_path = ""
            try:
                if install_loc and launch_exe:
                    candidate = os.path.normpath(os.path.join(install_loc, launch_exe))
                    if os.path.exists(candidate):
                        exe_path = candidate
                if not exe_path and install_loc and os.path.isdir(install_loc):
                    from scanner import find_best_exe
                    exe_path = find_best_exe(install_loc) or ""
            except Exception:
                pass
            installed = bool(exe_path)

            # Нормализуем slug — манифест может отдать "slug/home" или "/p/slug".
            slug = normalize_epic_slug(
                data.get("ProductSlug") or data.get("productSlug") or ""
            )

            entry = {
                "name": display,
                "appid": app_name,
                "namespace": namespace,
                "catalog_item_id": catalog_id,
                "slug": slug,
                "path": exe_path,
                "is_installed": installed,
                "is_epic_owned": True,
                "install_location": install_loc,
                "source": "epic",
                "is_dlc": is_dlc,
            }
            entry["launch_url"] = build_epic_launch_url(entry)
            entry["install_url"] = build_epic_install_url(entry, interactive=False)
            out[display] = entry
    return out, None


def fetch_epic_games(prefer_legendary: bool = True, enrich_info: bool = False):
    return read_epic_manifests()