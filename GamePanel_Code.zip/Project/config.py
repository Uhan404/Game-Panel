# language: Python 3.10+, file: config.py
# Конфиг, темы, состояние, нормализация ключей, слияние записей.

import os
import re
import json
import shutil
from datetime import datetime

from logger import get_logger

log = get_logger()

CONFIG_FILE = "app_config.json"
LIBRARY_FILE = "library_data.json"
CACHE_DIR = os.path.join(os.getcwd(), "custom_icons")
CACHE_MAX_BYTES = 20 * 1024 * 1024
CACHE_MAX_FILES = 500
os.makedirs(CACHE_DIR, exist_ok=True)

STEAM_API = "https://api.steampowered.com"
API_KEY_PAGE = "https://steamcommunity.com/dev/apikey"

DEFAULT_EPIC_INSTALL_PATH = r"C:\Games"

THEMES = {
    "dark": {
        "bg": "#0b0e14", "sidebar": "#121621", "card": "#1a1f2c",
        "text": "#f0f2f5", "text_muted": "#8a94a6", "accent": "#00d26a",
        "btn": "#242b3d", "btn_hover": "#2f384f",
        "badge_installed": "#10b981", "badge_steam": "#6366f1",
        "badge_epic": "#0074e4", "danger": "#ef4444",
    },
    "light": {
        "bg": "#f3f4f6", "sidebar": "#ffffff", "card": "#ffffff",
        "text": "#0f172a", "text_muted": "#64748b", "accent": "#059669",
        "btn": "#e2e8f0", "btn_hover": "#cbd5e1",
        "badge_installed": "#059669", "badge_steam": "#4f46e5",
        "badge_epic": "#0074e4", "danger": "#dc2626",
    },
}

DEFAULT_APP_CONFIG = {
    "steam_id": "",
    "steam_api_key": "",
    "epic_install_path": DEFAULT_EPIC_INSTALL_PATH,
    "price_country": "US",   # регион для сравнения цен (US → USD, DE → EUR и т.д.)
}

DEFAULT_STATE = {
    "theme": "dark",
    "library": {},
    "icon_cache": {},
    "app_config": dict(DEFAULT_APP_CONFIG),
    "widgets_to_theme": [],
    "refreshing": False,
    "filter": "all",
}

state = dict(DEFAULT_STATE)
state["library"] = {}
state["icon_cache"] = {}
state["app_config"] = dict(DEFAULT_APP_CONFIG)
state["widgets_to_theme"] = []

# --- Нормализация имён игр ---

_NORM_STRIP = re.compile(r"[^a-z0-9а-я]+", re.IGNORECASE)

_ALIASES = {
    "bloonstd6": "bloonstowerdefense6",
    "bloonstowerdefense6": "bloonstowerdefense6",
    "7daystodie": "7daystodie",
    "7daystod": "7daystodie",
    "counterstrikeglobaloffensive": "counterstrike2",
    "csgo": "counterstrike2",
    "counterstrike2": "counterstrike2",
}

def normalize_name(name):
    if not name:
        return ""
    s = name.lower()
    roman = {
        " viii": "8", " vii": "7", " vi": "6", " ix": "9", " iv": "4",
        " iii": "3", " ii": "2", " x": "10", " v": "5", " i": "1",
    }
    for k, v in roman.items():
        if s.endswith(k):
            s = s[:-len(k)] + " " + v
            break
    s = _NORM_STRIP.sub("", s)
    return _ALIASES.get(s, s)

def safe_filename(name):
    if not name:
        return "unnamed"
    s = re.sub(r'[<>:"/\\|?*\x00-\x1F]', "-", name)
    s = s.rstrip(" .")
    reserved = {"CON", "PRN", "AUX", "NUL"} | \
               {f"COM{i}" for i in range(1, 10)} | \
               {f"LPT{i}" for i in range(1, 10)}
    if s.upper() in reserved:
        s = "_" + s
    return s or "unnamed"

def _store_flags(data):
    return (bool(data.get("is_steam_owned", False)),
            bool(data.get("is_epic_owned", False)),
            bool(data.get("is_microsoft_owned", False)))

def _stores_conflict(a, b):
    a_s, a_e, a_m = _store_flags(a)
    b_s, b_e, b_m = _store_flags(b)

    if not (a_s or a_e or a_m) or not (b_s or b_e or b_m):
        return False

    if a_s and (b_e or b_m): return True
    if a_e and (b_s or b_m): return True
    if a_m and (b_s or b_e): return True

    return False

def merge_game_record(target, source):
    if not isinstance(target, dict) or not isinstance(source, dict):
        return target

    for k, v in source.items():
        if k == "is_installed":
            if v is True:
                target[k] = True
            continue
            
        if k in ("is_steam_owned", "is_epic_owned", "is_microsoft_owned", "is_dlc"):
            target[k] = bool(target.get(k)) or bool(v)
        elif k == "path":
            v_str = str(v).strip() if v else ""
            t_str = str(target.get(k) or "").strip()
            if v_str and (not t_str or not os.path.exists(t_str)):
                target[k] = v_str
        elif k in ("namespace", "catalog_item_id", "install_location",
                   "install_url", "launch_url", "slug", "pfn"):
            if not target.get(k) and v:
                target[k] = v
        elif k == "appid":
            cur = str(target.get(k) or "")
            new = str(v or "")
            if new.isdigit() and not cur.isdigit():
                target[k] = v
            elif not cur:
                target[k] = v
    return target

def conflict_suffix(data):
    if data.get("is_epic_owned"): return " (Epic)"
    if data.get("is_steam_owned"): return " (Steam)"
    if data.get("is_microsoft_owned"): return " (Microsoft)"
    return ""

def dedup_library():
    lib = state.get("library", {})
    if not lib: return
    merged = {}

    for title, data in lib.items():
        if not isinstance(data, dict):
            merged[title] = data
            continue

        base_title = (title.replace(" (Steam)", "").replace(" (Epic)", "").replace(" (Microsoft)", ""))
        nk = normalize_name(base_title)
        appid = str(data.get("appid", "")).strip()

        found_merge = False
        for m_title, m_data in list(merged.items()):
            m_appid = str(m_data.get("appid", "")).strip()
            if appid and m_appid and appid == m_appid:
                merged[m_title] = merge_game_record(m_data, data)
                found_merge = True
                break

            m_base = (m_title.replace(" (Steam)", "").replace(" (Epic)", "").replace(" (Microsoft)", ""))
            if normalize_name(m_base) == nk:
                if not _stores_conflict(m_data, data):
                    merged[m_title] = merge_game_record(m_data, data)
                    found_merge = True
                    break

        if not found_merge:
            if title in merged:
                merged[title] = merge_game_record(merged[title], data)
            else:
                merged[title] = data

    if len(merged) != len(lib):
        log.info(f"Дедуп библиотеки: {len(lib)} → {len(merged)}.")
        state["library"] = merged

# --- Файловые операции ---

def _backup_corrupt(path):
    if not os.path.exists(path): return
    try:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = f"{path}.corrupt_{ts}"
        shutil.move(path, backup)
        log.warning(f"Битый файл перемещён в {backup}")
    except Exception as e:
        log.error(f"Не удалось сделать бэкап {path}: {e}")

def _atomic_write_json(path, data):
    tmp = f"{path}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
        return True
    except Exception as e:
        log.error(f"Ошибка записи {path}: {e}")
        try:
            if os.path.exists(tmp): os.remove(tmp)
        except Exception: pass
        return False

def _read_json(path, default):
    if not os.path.exists(path):
        return dict(default) if isinstance(default, dict) else default
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError(f"Ожидался объект, получен {type(data).__name__}")
        return data
    except json.JSONDecodeError as e:
        log.error(f"Повреждён JSON в {path}: {e}")
        _backup_corrupt(path)
        return dict(default) if isinstance(default, dict) else default
    except PermissionError as e:
        log.error(f"Нет доступа к {path}: {e}")
        return dict(default) if isinstance(default, dict) else default
    except Exception as e:
        log.error(f"Ошибка чтения {path}: {e}")
        _backup_corrupt(path)
        return dict(default) if isinstance(default, dict) else default

def _validate_app_config(cfg):
    if not isinstance(cfg, dict):
        return dict(DEFAULT_APP_CONFIG)
    out = dict(DEFAULT_APP_CONFIG)
    for k in ("steam_id", "steam_api_key"):
        v = cfg.get(k, "")
        out[k] = str(v).strip() if v is not None else ""
    p = cfg.get("epic_install_path", DEFAULT_EPIC_INSTALL_PATH)
    out["epic_install_path"] = str(p).strip() if p else DEFAULT_EPIC_INSTALL_PATH
    pc = str(cfg.get("price_country") or "US").strip().upper()
    out["price_country"] = pc if re.fullmatch(r"[A-Z]{2}", pc) else "US"
    return out

def load_config():
    data = _read_json(CONFIG_FILE, DEFAULT_APP_CONFIG)
    state["app_config"] = _validate_app_config(data)
    log.info("Конфиг загружен.")

def save_config():
    if not _atomic_write_json(CONFIG_FILE, state["app_config"]):
        log.error("Не удалось сохранить конфиг.")

def load_library():
    data = _read_json(LIBRARY_FILE, {})
    clean = {}
    for k, v in data.items():
        if isinstance(v, dict) and isinstance(k, str):
            clean[k] = v
        else:
            log.warning(f"Пропущена битая запись библиотеки: {k}")
    state["library"] = clean
    dedup_library()
    log.info(f"Библиотека загружена: {len(state['library'])} игр.")

def save_library():
    dedup_library()
    if not _atomic_write_json(LIBRARY_FILE, state["library"]):
        log.error("Не удалось сохранить библиотеку.")

def delete_from_library(title):
    if title in state["library"]:
        del state["library"][title]
        save_library()
        log.info(f"Удалено из библиотеки: {title}")

def cleanup_cache():
    try:
        if not os.path.isdir(CACHE_DIR):
            os.makedirs(CACHE_DIR, exist_ok=True)
            return
        files = []
        total = 0
        for name in os.listdir(CACHE_DIR):
            path = os.path.join(CACHE_DIR, name)
            try:
                st = os.stat(path)
                files.append((path, st.st_size, st.st_mtime))
                total += st.st_size
            except OSError: continue
        if len(files) > CACHE_MAX_FILES or total > CACHE_MAX_BYTES:
            files.sort(key=lambda x: x[2])
            while files and (len(files) > CACHE_MAX_FILES or total > CACHE_MAX_BYTES):
                path, size, _ = files.pop(0)
                try:
                    os.remove(path)
                    total -= size
                except OSError as e:
                    log.warning(f"Не удалось удалить {path}: {e}")
            log.info(f"Кэш очищен, осталось {len(files)} файлов.")
    except Exception as e:
        log.error(f"Ошибка очистки кэша: {e}")