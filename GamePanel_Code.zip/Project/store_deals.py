# -*- coding: utf-8 -*-
"""Главная страница магазина: скидки Steam / Epic / Microsoft Store и бесплатные игры Epic.

Всё запрашивается для выбранного региона (app_config["price_country"]).
Каждый источник независим: если один не ответил, остальные всё равно показываются,
а ошибка попадает в data["errors"].
"""

import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

from logger import get_logger
from price_check import (
    STORE_EPIC, STORE_MS, STORE_STEAM,
    _epic_request, _epic_slug, _http_json, _offer, _ms_pick_price,
    epic_gql, epic_offer, format_money, ms_fetch_products, ms_is_game, ms_links, ms_title,
)

log = get_logger()

DEALS_PER_STORE = 9
MAX_FREE_CARDS = 4

_STEAM_FEATURED = "https://store.steampowered.com/api/featuredcategories"
_EPIC_FREE_URL = "https://store-site-backend-static.ak.epicgames.com/freeGamesPromotions"
_MS_RECO_DEALS = ("https://reco-public.rec.mp.microsoft.com/channels/Reco/v8.0/"
                  "lists/computed/Deals")

# Игры по самой высокой цене со скидкой — это то, что сайт Epic показывает в разделе «Скидки».
_EPIC_SALE_ARGS = (', category: "games/edition/base", onSale: true, allowCountries: $country'
                   ', sortBy: "currentPrice", sortDir: "DESC"')
_EPIC_SALE_ARGS_FALLBACK = ', category: "games/edition/base", onSale: true, allowCountries: $country'


# ----------------------------------------------------------------------------
# Утилиты
# ----------------------------------------------------------------------------

def _parse_iso(value):
    """'2026-11-13T16:00:00.000Z' → локальное datetime (или None)."""
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return dt.astimezone() if dt.tzinfo else dt
    except ValueError:
        return None


def _fmt_dt(dt):
    return dt.strftime("%d.%m %H:%M") if dt else ""


def top_deals(offers, limit=DEALS_PER_STORE):
    """Только реально со скидкой; сверху — самая большая скидка, при равенстве — дороже."""
    discounted = [o for o in offers if o.get("discount")]
    discounted.sort(key=lambda o: (-o["discount"], -(o.get("original") or 0.0), o["title"].lower()))
    return discounted[:limit]


# ----------------------------------------------------------------------------
# Epic: бесплатные игры
# ----------------------------------------------------------------------------

def _epic_window(groups):
    """Плоский список окон акций из promotionalOffers / upcomingPromotionalOffers."""
    out = []
    for grp in groups or []:
        out.extend((grp or {}).get("promotionalOffers") or [])
    return out


def fetch_epic_free(country):
    """Бесплатные сейчас и скоро игры Epic. Возвращает список словарей, 'now' — первыми."""
    url = _EPIC_FREE_URL + "?" + urllib.parse.urlencode(
        {"locale": "en-US", "country": country, "allowCountries": country})
    data = _http_json(url)
    elements = (((data.get("data") or {}).get("Catalog") or {}).get("searchStore") or {}).get("elements")
    if elements is None:
        raise RuntimeError("Epic: неожиданный ответ freeGamesPromotions")

    items = []
    for el in elements:
        title = el.get("title")
        promos = el.get("promotions") or {}
        now = _epic_window(promos.get("promotionalOffers"))
        soon = _epic_window(promos.get("upcomingPromotionalOffers"))
        if not title or not (now or soon):
            continue

        tp = ((el.get("price") or {}).get("totalPrice")) or {}
        decimals = (tp.get("currencyInfo") or {}).get("decimals", 2)
        div = 10 ** int(decimals if decimals is not None else 2)
        cur = tp.get("currencyCode") or "USD"
        original = (tp.get("originalPrice") or 0) / div

        if now and tp.get("discountPrice") == 0:
            status, win = "now", now[0]
        else:
            # В «upcoming» бесплатной считается акция со скидкой 100% (Epic кодирует это как 0 % к оплате).
            free_soon = [w for w in soon
                         if ((w.get("discountSetting") or {}).get("discountPercentage")) == 0]
            if not free_soon:
                continue
            status, win = "soon", free_soon[0]

        slug = _epic_slug(el)
        link = (f"https://store.epicgames.com/en-US/p/{slug}" if slug else
                "https://store.epicgames.com/en-US/free-games")
        items.append({
            "store": STORE_EPIC,
            "title": title,
            "status": status,                      # now | soon
            "start_text": _fmt_dt(_parse_iso(win.get("startDate"))),
            "end_text": _fmt_dt(_parse_iso(win.get("endDate"))),
            "original_text": format_money(original, cur) if original else "",
            "url": link,
            "native_uri": f"com.epicgames.launcher://store/product/{slug}" if slug else "",
        })

    items.sort(key=lambda i: (i["status"] != "now", i["title"].lower()))
    return items[:MAX_FREE_CARDS]


# ----------------------------------------------------------------------------
# Скидки
# ----------------------------------------------------------------------------

def fetch_steam_deals(country):
    url = _STEAM_FEATURED + "?" + urllib.parse.urlencode({"cc": country.lower(), "l": "english"})
    items = ((_http_json(url).get("specials") or {}).get("items")) or []
    offers = []
    for it in items:
        appid, name = it.get("id"), it.get("name")
        pct = it.get("discount_percent") or 0
        if not appid or not name or not pct or it.get("final_price") is None:
            continue
        cur = it.get("currency") or "USD"
        final = it["final_price"] / 100.0
        original = (it.get("original_price") or it["final_price"]) / 100.0
        offers.append(_offer(STORE_STEAM, name, final, original, cur,
                             f"https://store.steampowered.com/app/{appid}/",
                             f"steam://store/{appid}", str(appid)))
    return top_deals(offers)


def fetch_epic_deals(country):
    variables = {"keywords": "", "country": country.upper(), "locale": "en-US", "count": 40}
    elements, err = _epic_request(epic_gql(_EPIC_SALE_ARGS), variables)
    if elements is None:                      # схема не приняла sortBy — пробуем без сортировки
        elements, err = _epic_request(epic_gql(_EPIC_SALE_ARGS_FALLBACK), variables)
    if elements is None:
        raise RuntimeError(f"Epic недоступен: {err}")
    offers = []
    for el in elements:
        o = epic_offer(el)
        if o and o["price"] and o["discount"]:        # бесплатные раздачи показываются отдельной строкой
            offers.append(o)
    return top_deals(offers)


def fetch_microsoft_deals(country):
    url = _MS_RECO_DEALS + "?" + urllib.parse.urlencode({
        "market": country.upper(), "language": "en-US", "itemTypes": "Game",
        "deviceFamily": "Windows.Desktop", "count": 30,
    })
    ids = [it.get("Id") for it in (_http_json(url).get("Items") or []) if it.get("Id")]
    products = ms_fetch_products(ids, country)
    offers = []
    for pid in ids:
        p = products.get(pid)
        if not ms_is_game(p):
            continue
        picked = _ms_pick_price(p)
        if not picked:
            continue
        final, original, cur = picked
        link, native = ms_links(pid)
        offers.append(_offer(STORE_MS, ms_title(p), final, original, cur, link, native, pid))
    return top_deals(offers)


# ----------------------------------------------------------------------------
# Всё сразу
# ----------------------------------------------------------------------------

def fetch_home(country):
    """Возвращает {"free": [...], "deals": {store: [...]}, "errors": {key: текст}}."""
    country = (country or "US").strip().upper()
    tasks = {
        "free": fetch_epic_free,
        STORE_STEAM: fetch_steam_deals,
        STORE_EPIC: fetch_epic_deals,
        STORE_MS: fetch_microsoft_deals,
    }
    data = {"free": [], "deals": {STORE_STEAM: [], STORE_EPIC: [], STORE_MS: []}, "errors": {}}

    def run(item):
        key, fn = item
        try:
            return key, fn(country), None
        except Exception as exc:
            log.warning("Магазин, главная (%s, %s): %s", key, country, exc)
            return key, [], str(exc) or exc.__class__.__name__

    with ThreadPoolExecutor(max_workers=4) as pool:
        for key, found, err in pool.map(run, tasks.items()):
            if key == "free":
                data["free"] = found
            else:
                data["deals"][key] = found
            if err:
                data["errors"][key] = err
    return data
