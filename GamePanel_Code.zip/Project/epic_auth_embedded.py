# language: Python 3.10+, file: epic_auth_embedded.py
# Авторизация Epic через встроенный legendary.exe + прямой Epic Library API.

import os
import sys
import json
import shutil
import tempfile
import subprocess
import urllib.request
import urllib.error
import urllib.parse
import webbrowser
import tkinter as tk
from tkinter import messagebox
from collections import defaultdict

from logger import get_logger
from epic_games import (build_epic_install_url, build_epic_launch_url,
                        is_hex, is_non_game, normalize_epic_slug)

log = get_logger()

LEGENDARY_CONFIG_DIRS = [
    os.path.join(os.path.expanduser("~"), ".config", "legendary"),
    os.path.join(os.environ.get("LOCALAPPDATA", ""), "legendary"),
]

RUNTIME_DIR = os.path.join(tempfile.gettempdir(), "GamePanel")

LIBRARY_URL = ("https://library-service.live.use1a.on.epicgames.com"
               "/library/api/public/items?includeMetadata=true")


# ============================================================
# Разрешение slug продукта Epic
# ============================================================

def _extract_slug_from_search_result(item: dict) -> str:
    """Достаёт slug продукта из элемента, который вернул epic_store.search_epic."""
    if not isinstance(item, dict):
        return ""
    product = item.get("product") or {}
    if not isinstance(product, dict):
        return ""

    catalog_ns = product.get("catalogNs") or {}
    if isinstance(catalog_ns, dict):
        mappings = catalog_ns.get("mappings") or []
        if isinstance(mappings, list):
            for m in mappings:
                if isinstance(m, dict) and m.get("pageSlug"):
                    slug = normalize_epic_slug(m["pageSlug"])
                    if slug:
                        return slug

    for key in ("urlSlug", "slug", "productSlug"):
        slug = normalize_epic_slug(product.get(key) or "")
        if slug:
            return slug
    return ""


def _resolve_epic_slug(title: str, slug_from_api: str) -> str:
    """Возвращает slug продукта: из Library API или через GraphQL Epic Store."""
    slug = normalize_epic_slug(slug_from_api or "")
    if slug:
        return slug

    if not title:
        return ""

    try:
        from epic_store import search_epic
    except Exception as e:
        log.debug("epic_store.search_epic недоступен: %s", e)
        return ""

    try:
        results = search_epic(title)
    except Exception as e:
        log.debug("search_epic('%s') failed: %s", title, e)
        return ""

    if not isinstance(results, list) or not results:
        return ""

    exact = next(
        (r for r in results
         if isinstance(r, dict)
         and str(r.get("product", {}).get("title", "")).strip().lower() == title.strip().lower()),
        None,
    )
    candidates = ([exact] if exact else []) + [r for r in results if r is not exact]

    for item in candidates:
        slug = _extract_slug_from_search_result(item)
        if slug:
            log.info("Epic: slug для «%s» получен через GraphQL: %s", title, slug)
            return slug

    log.warning("Epic: не удалось получить slug для «%s»", title)
    return ""


# ============================================================
# Открытие URI лаунчера Epic
# ============================================================

def open_epic_launcher_uri(uri: str) -> bool:
    """Открывает URI в Epic Games Launcher через cmd /c start (самый надёжный способ)."""
    if not uri or os.name != "nt":
        return False

    try:
        res = subprocess.run(
            ["cmd", "/c", "start", "", uri],
            capture_output=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            timeout=10,
        )
        if res.returncode == 0:
            return True
        stderr = (res.stderr or b"").decode("utf-8", errors="ignore").strip()
        if stderr:
            log.info("start URI '%s' код %s: %s", uri, res.returncode, stderr[:200])
    except Exception as exc:
        log.info("start URI '%s' ошибка: %s", uri, exc)

    try:
        os.startfile(uri)
        return True
    except OSError as exc:
        log.info("ShellExecute URI '%s' ошибка: %s", uri, exc)
    except Exception as exc:
        log.info("ShellExecute URI '%s' исключение: %s", uri, exc)

    return False


# ============================================================
# Инфраструктура legendary
# ============================================================

def _get_clean_env():
    env = os.environ.copy()
    for key in ("PYTHONHOME", "PYTHONPATH", "PYTHONEXECUTABLE", "PYTHONSTARTUP"):
        env.pop(key, None)
    if hasattr(sys, "_MEIPASS"):
        meipass = os.path.normcase(sys._MEIPASS)
        parts = env.get("PATH", "").split(os.pathsep)
        env["PATH"] = os.pathsep.join(
            p for p in parts if p and os.path.normcase(p) != meipass
        )
    return env


def _find_embedded_legendary():
    if hasattr(sys, "_MEIPASS"):
        candidate = os.path.join(sys._MEIPASS, "legendary.exe")
        if os.path.isfile(candidate): return candidate
    here = os.path.dirname(os.path.abspath(__file__))
    candidate = os.path.join(here, "legendary.exe")
    if os.path.isfile(candidate): return candidate
    path_exe = shutil.which("legendary")
    if path_exe: return path_exe
    return None


def _legendary_works(exe_path, timeout=10):
    try:
        res = subprocess.run([exe_path, "--version"], capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="ignore", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), env=_get_clean_env())
        return res.returncode == 0
    except Exception: return False


def extract_embedded_legendary():
    src = _find_embedded_legendary()
    if not src:
        return None, "Встроенный legendary.exe не найден."
    try:
        os.makedirs(RUNTIME_DIR, exist_ok=True)
    except OSError as e:
        return None, f"Не создать {RUNTIME_DIR}: {e}"

    dst = os.path.join(RUNTIME_DIR, "legendary.exe")
    try:
        if os.path.isfile(dst) and os.path.getsize(dst) == os.path.getsize(src):
            if _legendary_works(dst): return dst, None
    except OSError: pass
    try:
        shutil.copy2(src, dst)
    except Exception as e:
        return None, f"Не распаковать legendary.exe: {e}"

    if not _legendary_works(dst):
        return None, "legendary.exe скопирован, но не запускается (антивирус?)."
    return dst, None


def legendary_config_dir():
    for d in LEGENDARY_CONFIG_DIRS:
        if d and os.path.isdir(d): return d
    return LEGENDARY_CONFIG_DIRS[0]


def is_logged_in():
    user = _load_user_json()
    if user:
        name = user.get("displayName") or user.get("account_id")
        if name: return True, name
    return False, None


def _load_user_json():
    try:
        cfg = legendary_config_dir()
        user_file = os.path.join(cfg, "user.json")
        if os.path.isfile(user_file):
            with open(user_file, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as e:
        log.warning(f"_load_user_json: {e}")
    return None


def logout():
    try:
        cfg = legendary_config_dir()
        user_file = os.path.join(cfg, "user.json")
        if os.path.isfile(user_file): os.remove(user_file)
        return True, "Логин сброшен."
    except Exception as e: return False, f"Ошибка: {e}"


def _run_legendary(args, timeout=60):
    exe_path, err = extract_embedded_legendary()
    if not exe_path: return "", err or "legendary не найден", -1
    full_args = [exe_path, "--no-update-check"] + args
    try:
        res = subprocess.run(full_args, capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="ignore", creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), env=_get_clean_env())
        return res.stdout or "", res.stderr or "", res.returncode
    except subprocess.TimeoutExpired: return "", "legendary не ответил", -1
    except Exception as e: return "", f"Ошибка запуска: {e}", -1


def _http_get_json(url, headers):
    req = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode("utf-8", errors="ignore"))


def _try_refresh_epic_token():
    log.info("Epic Library API 401, обновляю токен...")
    _, err_out, rc = _run_legendary(["list", "--json"], timeout=90)
    if rc != 0:
        return False, (err_out or "").strip().split("\n")[-1][:200] or f"код {rc}"
    return True, None


def fetch_epic_library():
    user = _load_user_json()
    if not user: return None, "Epic не привязан."
    old_token = user.get("access_token")
    if not old_token: return None, "В user.json нет access_token."

    headers = {"Authorization": f"bearer {old_token}", "Accept": "application/json", "User-Agent": "GamePanel/1.0"}
    data = None
    try:
        data = _http_get_json(LIBRARY_URL, headers)
    except urllib.error.HTTPError as e:
        if e.code == 401:
            ok, err = _try_refresh_epic_token()
            if not ok: return None, f"Epic: не удалось обновить токен ({err}). Войди заново."
            user = _load_user_json()
            new_token = (user or {}).get("access_token")
            if not new_token or new_token == old_token: return None, "Epic: legendary не обновил токен."
            headers["Authorization"] = f"bearer {new_token}"
            try: data = _http_get_json(LIBRARY_URL, headers)
            except Exception as e2: return None, f"Ошибка после обновления токена: {e2}"
        else:
            return None, f"HTTP {e.code} от Epic Library API."

    if not data: return None, "Пустой ответ от Epic Library API."
    records = (data.get("records") or data.get("response", {}).get("records") or [])
    if not records: return None, "Библиотека Epic пуста."

    out = {}
    namespace_groups = defaultdict(list)

    for rec in records:
        ns = rec.get("namespace") or ""
        cid = rec.get("catalogItemId") or rec.get("id") or ""
        if ns and cid:
            namespace_groups[ns].append(rec)
        else:
            app_name = rec.get("appName") or rec.get("productId") or cid
            title = rec.get("sandboxName") or rec.get("productName") or app_name
            if not is_non_game(app_name):
                slug = _resolve_epic_slug(
                    title, rec.get("productSlug") or rec.get("urlSlug") or ""
                )
                out[title] = {
                    "name": title, "appid": app_name, "namespace": ns, "catalog_item_id": cid,
                    "slug": slug,
                    "is_epic_owned": True, "source": "epic", "is_dlc": rec.get("isDLC", False),
                }

    for ns, recs in namespace_groups.items():
        for i in range(0, len(recs), 20):
            chunk = recs[i:i+20]
            ids = ",".join((r.get("catalogItemId") or r.get("id")) for r in chunk)
            cat_url = (f"https://catalog-public-service-prod06.ol.epicgames.com"
                       f"/catalog/api/shared/namespace/{ns}/bulk/items"
                       f"?id={ids}&includeDLCDetails=true"
                       f"&includeMainGameDetails=true&country=US&locale=en")
            try:
                cat_data = _http_get_json(cat_url, headers)
            except Exception as e:
                log.debug(f"Catalog bulk error for {ns}: {e}")
                cat_data = {}

            for rec in chunk:
                cid = rec.get("catalogItemId") or rec.get("id") or ""
                item = cat_data.get(cid) if isinstance(cat_data, dict) else None

                title = rec.get("sandboxName") or rec.get("productName") or rec.get("appName") or cid
                slug = rec.get("productSlug") or rec.get("urlSlug") or ""
                app_name = rec.get("appName") or rec.get("productId") or cid
                is_dlc = rec.get("isDLC", False)

                if isinstance(item, dict):
                    title = item.get("title") or title
                    slug = item.get("urlSlug") or item.get("productSlug") or slug
                    if item.get("mainGameItem") or "digitalextra" in (item.get("categories") or []) or "addons" in (item.get("categories") or []):
                        is_dlc = True

                    release_info = item.get("releaseInfo") or []
                    if isinstance(release_info, list):
                        for ri in release_info:
                            if isinstance(ri, dict) and ri.get("appId"):
                                app_name = ri["appId"]
                                break

                if is_non_game(app_name) or (is_dlc and title.endswith(" Content")):
                    continue

                slug = _resolve_epic_slug(title, slug)

                entry = {
                    "name": title, "appid": app_name, "namespace": ns, "catalog_item_id": cid,
                    "slug": slug, "is_epic_owned": True, "source": "epic", "is_dlc": is_dlc,
                }
                entry["launch_url"] = build_epic_launch_url(entry)
                entry["install_url"] = build_epic_install_url(entry, interactive=False)
                out[title] = entry

    log.info(f"Epic Library API: получено {len(out)} игр.")
    return out, None


def run_legendary_auth(parent, on_success=None):
    exe_path, err = extract_embedded_legendary()
    if not exe_path:
        messagebox.showerror("Epic", err)
        return

    cfg = legendary_config_dir()
    user_file = os.path.join(cfg, "user.json")
    if os.path.exists(user_file):
        try: os.remove(user_file)
        except Exception: pass

    webbrowser.open("https://legendary.gl/epiclogin")
    dlg = tk.Toplevel(parent)
    dlg.title("Вход в Epic Games")
    dlg.geometry("550x320")
    dlg.resizable(False, False)
    dlg.transient(parent)
    dlg.grab_set()

    try:
        from config import THEMES, state
        c = THEMES.get(state.get("theme"), THEMES["dark"])
    except Exception:
        c = {"bg": "#0b0e14", "card": "#1a1f2c", "text": "#f0f2f5", "text_muted": "#8a94a6", "accent": "#00d26a", "btn": "#242b3d", "danger": "#ef4444"}

    dlg.configure(bg=c["bg"])
    tk.Label(dlg, text="Вход в Epic Games", bg=c["bg"], fg=c["text"], font=("Segoe UI", 14, "bold")).pack(pady=(15, 10))
    text_instructions = ("1. В браузере войдите в аккаунт Epic.\n2. Скопируйте значение поля \"authorizationCode\".\n3. Вставьте этот код в поле ниже и нажмите «Войти».\n⚠ Код действует 5 минут.")
    tk.Label(dlg, text=text_instructions, bg=c["bg"], fg=c["text_muted"], font=("Segoe UI", 9), justify="left").pack(padx=20, pady=(0, 10), anchor="w")

    code_var = tk.StringVar()
    entry = tk.Entry(dlg, textvariable=code_var, font=("Consolas", 10), bg=c["card"], fg=c["text"], insertbackground=c["text"], relief="flat", bd=6)
    entry.pack(fill="x", padx=20, pady=(0, 10))
    entry.focus_set()

    def paste_text(event=None):
        try: entry.insert(tk.INSERT, dlg.clipboard_get())
        except Exception: pass
        return "break"

    menu = tk.Menu(entry, tearoff=0)
    menu.add_command(label="Вставить", command=paste_text)
    menu.add_command(label="Копировать", command=lambda: entry.event_generate("<<Copy>>"))
    menu.add_command(label="Вырезать", command=lambda: entry.event_generate("<<Cut>>"))
    menu.add_separator()
    menu.add_command(label="Очистить", command=lambda: entry.delete(0, tk.END))
    entry.bind("<Button-3>", lambda e: menu.tk_popup(e.x_root, e.y_root))
    entry.bind("<Control-v>", paste_text)
    entry.bind("<Control-V>", paste_text)
    entry.bind("<Shift-Insert>", paste_text)

    status_lbl = tk.Label(dlg, text="", bg=c["bg"], fg=c["danger"], font=("Segoe UI", 9), wraplength=500)
    status_lbl.pack(pady=(0, 5))

    def submit():
        code = code_var.get().strip()
        if not code:
            status_lbl.config(text="Код не может быть пустым.")
            return
        status_lbl.config(text="Авторизация...", fg=c["accent"])
        dlg.update()
        try:
            startupinfo = None
            if os.name == 'nt':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE
            res = subprocess.run([exe_path, "--no-update-check", "auth", "--code", code],
                capture_output=True, text=True, timeout=30, startupinfo=startupinfo, env=_get_clean_env())
            ok, name = is_logged_in()
            if ok:
                dlg.destroy()
                messagebox.showinfo("Epic", f"Вход выполнен: {name}")
                if on_success: on_success()
            else:
                err_out = (res.stderr or res.stdout or "").strip().split("\n")[-1][:150]
                status_lbl.config(text=f"Ошибка: {err_out}")
        except Exception as e:
            status_lbl.config(text=f"Ошибка запуска: {e}")

    btn_frame = tk.Frame(dlg, bg=c["bg"])
    btn_frame.pack(fill="x", padx=20, pady=(5, 15))
    tk.Button(btn_frame, text="Войти", bg=c["accent"], fg="#ffffff", borderwidth=0, cursor="hand2", font=("Segoe UI", 10, "bold"), command=submit).pack(side="right", ipady=4, ipadx=15)
    tk.Button(btn_frame, text="Отмена", bg=c["btn"], fg=c["text"], borderwidth=0, cursor="hand2", font=("Segoe UI", 10), command=dlg.destroy).pack(side="right", padx=(0, 10), ipady=4, ipadx=15)