# language: Python 3.10+, file: microsoft_store.py, target: Windows 10/11

import os
import re
import json
import shutil
import subprocess
import pathlib
import xml.etree.ElementTree as ET

from logger import get_logger

log = get_logger()

_CREATE_NO_WINDOW = 0x08000000
_PS_TIMEOUT = 60
_WINGET_TIMEOUT = 1800

_CACHE_DIR = pathlib.Path(os.path.expanduser("~")) / ".store_installer"
_CACHE_FILE = _CACHE_DIR / "product_ids.json"

_KNOWN_GAME_PACKAGES = {
    "microsoft.minecraftuwp": "Minecraft for Windows",
    "microsoft.minecraftlauncher": "Minecraft Launcher",
    "microsoft.seaofthieves": "Sea of Thieves",
    "microsoft.forzahorizon5": "Forza Horizon 5",
    "microsoft.sunrisebasegame": "Forza Horizon 4",
    "microsoft.forzamotorsport": "Forza Motorsport",
    "microsoft.haloinfinite": "Halo Infinite",
    "microsoft.hellblade2": "Hellblade II",
    "microsoft.ageraremastered": "Age of Empires",
    "microsoft.flight_simulator": "Microsoft Flight Simulator",
    "microsoft.flight_simulator_2024": "Microsoft Flight Simulator 2024",
    "microsoft.starfield": "Starfield",
    "bethesdasoftworks.starfield": "Starfield",
    "bethesda.softworks.fallout76": "Fallout 76",
    "microsoft.dishonored2": "Dishonored 2",
    "microsoft.grounded": "Grounded",
    "microsoft.rossettastone": "Gears of War 4",
    "microsoft.gearsofwarultimate": "Gears of War: Ultimate Edition",
    "microsoft.gearsofwar4": "Gears of War 4",
    "microsoft.stateofdecay2": "State of Decay 2",
    "microsoft.crackdown3": "Crackdown 3",
    "microsoft.killerinstinct": "Killer Instinct",
    "microsoft.astroneer": "ASTRONEER",
    "microsoft.tunche": "TUNIC",
}

# Жёсткий чёрный список системных пакетов
_SYSTEM_BLACKLIST = [
    "microsoft.windows", "microsoft.xbox", "microsoft.store", 
    "microsoft.settings", "microsoft.calculator", "microsoft.paint", 
    "microsoft.photos", "microsoft.camera", "microsoft.cortana", 
    "microsoft.gethelp", "microsoft.feedback", "microsoft.people", 
    "microsoft.skypeapp", "microsoft.office", "microsoft.onedrive", 
    "microsoft.zune", "microsoft.groove", "microsoft.bing", 
    "microsoft.windowscommunicationsapps", "microsoft.mspaint",
    "quixel", "unreal", "fab", "epicgames",
    "microsoft.aad", "microsoft.account", "microsoft.experience",
    "microsoft.vclibs", "microsoft.net", "microsoft.ui",
    "microsoft.services", "microsoft.winget", "microsoft.desktop",
    "microsoft.oneconnect", "microsoft.ecapp", "microsoft.lockapp",
    "microsoft.windowsdefender", "microsoft.search", "microsoft.photostudio"
]

_packages_cache = None
_product_cache = None

def _powershell_available() -> bool:
    for exe in ("powershell", "pwsh"):
        try:
            r = subprocess.run([exe, "-NoProfile", "-Command", "$PSVersionTable.PSVersion.Major"],
                capture_output=True, text=True, timeout=10, creationflags=_CREATE_NO_WINDOW)
            if r.returncode == 0 and r.stdout.strip().isdigit(): return True
        except (OSError, subprocess.TimeoutExpired): continue
    return False

def _run_powershell(script: str, timeout: int = _PS_TIMEOUT):
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True, text=True, timeout=timeout, encoding="utf-8", errors="ignore", creationflags=_CREATE_NO_WINDOW)
    except subprocess.TimeoutExpired:
        log.error(f"PowerShell: таймаут {timeout}с.")
        return None
    except OSError as e:
        log.error(f"PowerShell: не запустить --- {e}")
        return None

    if r.returncode != 0:
        log.warning(f"PowerShell код {r.returncode}: {r.stderr[:300]}")
        return None
    return r.stdout

def _run_cmd(cmd: list[str], timeout: int) -> tuple[int, str, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="ignore", creationflags=_CREATE_NO_WINDOW)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except (OSError, subprocess.TimeoutExpired) as e:
        return -1, "", str(e)

_PS_LIST = r"""
$ErrorActionPreference = 'SilentlyContinue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Get-AppxPackage -PackageTypeFilter Main,Bundle | Where-Object {
    !$_.IsFramework -and !$_.IsResourcePackage -and $_.InstallLocation
} | ForEach-Object {
    $p = $_
    $m = $null
    try { $m = Get-AppxPackageManifest -Package $p.PackageFullName } catch {}
    $display = ''
    $publisher = ''
    $appId = ''
    if ($m -and $m.Package.Properties.DisplayName) { $display = $m.Package.Properties.DisplayName }
    if ($m -and $m.Package.Properties.PublisherDisplayName) { $publisher = $m.Package.Properties.PublisherDisplayName }
    if ($m -and $m.Package.Applications -and $m.Package.Applications.Application) { $appId = $m.Package.Applications.Application[0].Id }
    [PSCustomObject]@{
        Name = $p.Name
        PackageFamilyName = $p.PackageFamilyName
        PackageFullName = $p.PackageFullName
        InstallLocation = $p.InstallLocation
        DisplayName = $display
        PublisherDisplayName = $publisher
        AppId = $appId
    }
} | ConvertTo-Json -Compress -Depth 3
"""

def _get_packages_json() -> list[dict]:
    global _packages_cache
    if _packages_cache is not None: return _packages_cache

    raw = _run_powershell(_PS_LIST)
    if not raw or not raw.strip():
        log.info("Microsoft Store: Get-AppxPackage вернул пусто.")
        _packages_cache = []
        return _packages_cache

    try:
        data = json.loads(raw.lstrip('\ufeff'))
    except json.JSONDecodeError as e:
        log.error(f"Microsoft Store: JSON не разобран --- {e}. Начало: {raw[:200]}")
        _packages_cache = []
        return _packages_cache

    if isinstance(data, dict): data = [data]
    if not isinstance(data, list): data = []

    log.info(f"Microsoft Store: прочитано пакетов --- {len(data)}")
    _packages_cache = data
    return _packages_cache

def refresh_package_cache():
    global _packages_cache
    _packages_cache = None

def _resolve_path(path: str) -> str:
    if not path or not os.path.isdir(path): return path
    try:
        real = os.path.realpath(path)
        return real if real and real != path else path
    except OSError:
        return path

def _read_app_id_from_manifest(install_location: str) -> str:
    if not install_location: return ""
    manifest = os.path.join(install_location, "AppxManifest.xml")
    if not os.path.isfile(manifest): return ""
    try:
        tree = ET.parse(manifest)
    except (ET.ParseError, OSError):
        return ""
    for el in tree.getroot().iter():
        if el.tag.endswith("}Application") or el.tag == "Application":
            app_id = el.get("Id")
            if app_id: return app_id
    return ""

def _find_uwp_exe(install_location: str) -> str:
    if not install_location or not os.path.isdir(install_location): return ""
    best, best_score = "", -1
    try:
        for root, dirs, files in os.walk(install_location):
            dirs[:] = [d for d in dirs if d.lower() not in ("resources", "assets", "vfs", "localcache")]
            for f in files:
                if not f.lower().endswith(".exe"): continue
                full = os.path.join(root, f)
                try: size = os.path.getsize(full)
                except OSError: continue
                if size < 100 * 1024: continue
                try: depth = len(os.path.relpath(full, install_location).split(os.sep))
                except ValueError: depth = 5
                score = size // (1024 * 1024) - depth * 10
                if score > best_score:
                    best_score, best = score, full
    except OSError:
        return ""
    return best

def _build_entry(pkg: dict) -> dict:
    install_loc = pkg.get("InstallLocation") or ""
    real_loc = _resolve_path(install_loc)
    pfn = pkg.get("PackageFamilyName") or ""
    app_id = pkg.get("AppId") or ""
    if not app_id: app_id = _read_app_id_from_manifest(real_loc)

    launch_url = ""
    if pfn and app_id: launch_url = f"shell:AppsFolder\\{pfn}!{app_id}"
    elif pfn: launch_url = f"shell:AppsFolder\\{pfn}"

    display = (pkg.get("DisplayName") or "").strip()
    if not display or display.startswith("ms-resource:"):
        display = (pkg.get("Name") or "").strip() or "Unknown"
    if "." in display and " " not in display: display = display.replace(".", " ")

    icon_path = ""
    if real_loc and os.path.isdir(real_loc):
        for relative in ("Assets/StoreLogo.png", "Assets/Square150x150Logo.png",
                         "Assets/Square44x44Logo.png", "StoreLogo.png",
                         "Square150x150Logo.png", "Square44x44Logo.png"):
            candidate = os.path.join(real_loc, relative)
            if os.path.isfile(candidate):
                icon_path = candidate
                break

    return {
        "name": display, "appid": pfn, "package_family_name": pfn,
        "icon_path": icon_path,
        "package_full_name": pkg.get("PackageFullName") or "",
        "app_id": app_id, "install_location": real_loc, "install_path": real_loc,
        "path": "", "is_installed": True, "is_microsoft_owned": True,
        "source": "microsoft", "launch_url": launch_url,
        "publisher": pkg.get("PublisherDisplayName") or "",
    }

def read_microsoft_store_games(known_titles=None, add_known_games: bool = True):
    if os.name != "nt": return {}, "Microsoft Store поддерживается только на Windows."
    packages = _get_packages_json()
    if not packages: return {}, "Windows не вернул установленные AppX/MSIX-пакеты."

    try:
        from config import normalize_name
    except ImportError:
        return {}, "Не удалось импортировать config.normalize_name."

    blacklist_norm = {normalize_name(x) for x in _SYSTEM_BLACKLIST}
    known_pkg = {normalize_name(k) for k in _KNOWN_GAME_PACKAGES}
    known_game_keys = {k for k in known_pkg if len(k) >= 6}
    
    non_game_words = ["experience", "broker", "account", "compatibility", "vclibs", "net.", "ui.xaml", "services.store"]

    out = {}
    skipped_no_launch = 0
    skipped_blacklist = 0

    for pkg in packages:
        entry = _build_entry(pkg)
        if not entry["launch_url"]:
            skipped_no_launch += 1
            continue

        pkg_norm = normalize_name(entry.get("package_family_name", "").split("_")[0])
        name_norm = normalize_name(entry.get("name", ""))
        
        # Фильтр по GUID-названиям
        if re.match(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', entry["name"].lower()):
            skipped_blacklist += 1
            continue

        # Отсекаем системный мусор по черному списку
        if any(pkg_norm == b or pkg_norm.startswith(b) for b in blacklist_norm):
            skipped_blacklist += 1
            continue
            
        # Отсекаем системный мусор по ключевым словам
        if any(w in name_norm for w in non_game_words):
            skipped_blacklist += 1
            continue

        # Если начинается с "microsoft.", пропускаем, если это не известная игра
        if name_norm.startswith("microsoft"):
            is_game = pkg_norm in known_pkg or any(k in pkg_norm for k in known_game_keys)
            if not is_game:
                skipped_blacklist += 1
                continue

        entry["path"] = _find_uwp_exe(entry["install_location"])
        out[entry["name"]] = entry

    log.info(f"Microsoft Store: возвращаю {len(out)} установленных пакетов (без launch_url: {skipped_no_launch}, blacklist: {skipped_blacklist})")
    return out, None

def launch_game(entry: dict):
    url = (entry or {}).get("launch_url") or ""
    if not url: return False, "Нет launch_url --- игра не из Microsoft Store?"
    if os.name != "nt": return False, "Только Windows."
    try:
        os.startfile(url)
        return True, None
    except OSError as e:
        return False, f"Не удалось запустить: {e}"

def winget_available() -> bool:
    return shutil.which("winget") is not None

def search_store(query: str) -> list[dict]:
    query = (query or "").strip()
    if not query or not winget_available(): return []
    cmd = ["winget", "search", "--source", "msstore", "--query", query, "--accept-source-agreements", "--disable-interactivity"]
    code, out, err = _run_cmd(cmd, timeout=90)
    if code != 0 or not out:
        log.warning("Microsoft Store search failed (%s): %s", code, err[:300])
        return []

    lines = [line.rstrip() for line in out.splitlines() if line.strip()]
    header_index = next((i for i, line in enumerate(lines) if line.lower().startswith("name") and "id" in line.lower()), None)
    if header_index is None or header_index + 1 >= len(lines): return []
    header = lines[header_index]
    id_pos = header.lower().find("id", 1)
    if id_pos < 0: return []

    results = []
    for line in lines[header_index + 1:]:
        if set(line.strip()) <= {"-"}: continue
        name = line[:id_pos].strip()
        remainder = line[id_pos:]
        product_id = remainder.split()[0] if remainder.split() else ""
        if not name or not product_id or product_id.lower() in {"id", "msstore"}: continue
        if not product_id.isalnum() or len(product_id) < 8: continue
        results.append({
            "id": product_id, "product_id": product_id, "name": name,
            "source": "Microsoft Store", "install_url": f"ms-windows-store://pdp/?ProductId={product_id}",
        })
    return results

def install_from_store(product_id: str, silent: bool = False) -> tuple[bool, str]:
    product_id = (product_id or "").strip()
    if not product_id or not product_id.isalnum():
        return False, "Некорректный Product ID Microsoft Store."
    if not winget_available():
        return False, "winget не найден. Обнови App Installer из Microsoft Store."
    cmd = ["winget", "install", "--source", "msstore", "--id", product_id, "--exact", "--accept-package-agreements", "--accept-source-agreements", "--disable-interactivity"]
    if silent: cmd.append("--silent")
    code, out, err = _run_cmd(cmd, timeout=_WINGET_TIMEOUT)
    ok = code == 0
    details = out or err or ("Команда выполнена." if ok else f"Код завершения: {code}")
    return ok, details

def install_by_name(name: str) -> tuple[bool, str]:
    results = search_store(name)
    if not results:
        return False, "Игра не найдена в каталоге Microsoft Store через winget."
    if len(results) > 1:
        return False, "Найдено несколько совпадений. Открой поиск Microsoft Store и выбери точную игру."
    return install_from_store(results[0]["product_id"])

def open_store_page(product_id: str) -> bool:
    try:
        subprocess.Popen(["cmd", "/c", "start", "", f"ms-windows-store://pdp/?productid={product_id}"], creationflags=_CREATE_NO_WINDOW)
        return True
    except OSError:
        return False