# language: Python 3.10+, file: steam_api.py
# Steam Web API: резолв SteamID, список игр.

import json
import time
import urllib.request
import urllib.parse
import urllib.error

from config import STEAM_API
from logger import get_logger

log = get_logger()

RETRIES = 3
BACKOFF = 1.5

def http_get(url, timeout=15):
    last_exc = None
    for attempt in range(1, RETRIES + 1):
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "GamePanel/1.0",
                "Accept": "application/json, */*",
            })
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read().decode("utf-8", errors="ignore")
        except urllib.error.HTTPError as e:
            if e.code < 500 and e.code != 429:
                raise
            last_exc = e
        except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
            last_exc = e
        except Exception as e:
            last_exc = e
        if attempt < RETRIES:
            time.sleep(BACKOFF ** attempt)
    raise last_exc if last_exc else RuntimeError("HTTP error")

def resolve_steam_id(raw):
    raw = (raw or "").strip().rstrip("/")
    if not raw:
        return None
    if "steamcommunity.com" in raw:
        if "/profiles/" in raw:
            return raw.split("/profiles/")[-1].split("/")[0].split("?")[0] or None
        if "/id/" in raw:
            return _resolve_vanity(raw.split("/id/")[-1].split("/")[0].split("?")[0])
    if raw.isdigit() and len(raw) == 17:
        return raw
    return _resolve_vanity(raw)

def _resolve_vanity(vanity):
    if not vanity:
        return None
    try:
        url = (f"{STEAM_API}/ISteamUser/ResolveVanityURL/v1/"
               f"?vanityurl={urllib.parse.quote(vanity)}")
        data = json.loads(http_get(url))
        resp = data.get("response", {})
        if resp.get("success") == 1:
            return resp.get("steamid")
    except Exception as e:
        log.warning(f"ResolveVanityURL '{vanity}': {e}")
    return None

def fetch_steam_games(steam_id_raw, api_key):
    if not api_key:
        return None, "Не указан Steam API-ключ."
    sid = resolve_steam_id(steam_id_raw)
    if not sid:
        return None, "Не удалось определить SteamID64."

    url = (f"{STEAM_API}/IPlayerService/GetOwnedGames/v1/"
           f"?key={api_key}&steamid={sid}"
           f"&include_appinfo=1&include_played_free_games=1&format=json")
    try:
        data = json.loads(http_get(url))
    except urllib.error.HTTPError as e:
        if e.code == 401:
            return None, "Неверный API-ключ Steam (401)."
        if e.code == 403:
            return None, "Доступ запрещён (403). Проверь приватность профиля."
        if e.code == 429:
            return None, "Слишком много запросов к Steam (429). Подожди минуту."
        return None, f"HTTP {e.code} от Steam Web API."
    except Exception as e:
        log.error(f"fetch_steam_games: {e}")
        return None, f"Ошибка запроса: {e}"

    resp = data.get("response", {})
    if "games" not in resp:
        if resp.get("game_count") == 0:
            return None, "У аккаунта нет игр в Steam."
        return None, ("Steam не вернул список игр. Скорее всего закрыт "
                      "«Доступ к игровой детализации» в приватности.")

    out = {}
    for g in resp["games"]:
        appid = str(g.get("appid", ""))
        name = g.get("name") or f"App {appid}"
        if not appid:
            continue
            
        # Отсекаем сервера и SDK
        if "Dedicated Server" in name or "SDK" in name or "Beta" in name:
            continue
            
        out[name] = {
            "name": name, "appid": appid,
            "path": f"steam://run/{appid}",
            "install_url": f"steam://install/{appid}",
            "is_installed": False, "is_steam_owned": True,
            "playtime_min": g.get("playtime_forever", 0),
        }
    return out, None