# -*- coding: utf-8 -*-
"""Открытие страницы игры в соответствующем магазине.

Epic Games:
  • URI страницы продукта в лаунчере: com.epicgames.launcher://store/product/<slug>
  • Slug разрешается через epic_slug.resolve_epic_slug (Catalog API + GraphQL).
  • Если лаунчер не установлен — открывается веб-страница.

Steam:  steam://store/<appid>
MS:     ms-windows-store://pdp/?PFN=<pfn>
"""

import os
import urllib.parse
import webbrowser

from logger import get_logger

log = get_logger()


def _open_native(uri):
    """Передаёт URI зарегистрированному обработчику протокола (Windows ShellExecute)."""
    if os.name != "nt" or not uri:
        return False
    try:
        os.startfile(uri)
        return True
    except OSError as exc:
        log.info("URI '%s' не обработан: %s", uri, exc)
        return False
    except Exception as exc:
        log.info("URI '%s' ошибка: %s", uri, exc)
        return False


def open_store_page(record):
    record = record or {}
    name = str(record.get("name") or "").strip()
    appid = str(record.get("appid") or "").strip()

    # ---------------------------- Epic Games ----------------------------
    if record.get("is_epic_owned"):
        from epic_slug import resolve_epic_slug
        slug = resolve_epic_slug(
            name,
            record.get("slug") or "",
            record.get("namespace") or "",
            record.get("catalog_item_id") or "",
        )
        if slug:
            uri = f"com.epicgames.launcher://store/product/{slug}"
            log.info("Epic launcher URI: %s", uri)
            if _open_native(uri):
                return True
            # Лаунчер не установлен или протокол не зарегистрирован — открываем веб.
            return bool(webbrowser.open(f"https://store.epicgames.com/p/{slug}"))

        log.warning("Epic: не удалось определить slug для «%s»", name)
        return bool(webbrowser.open(
            "https://store.epicgames.com/browse?q=" + urllib.parse.quote_plus(name)
        ))

    # ------------------------------ Steam -------------------------------
    if record.get("is_steam_owned") and appid.isdigit():
        if _open_native(f"steam://store/{appid}"):
            return True
        return bool(webbrowser.open(f"https://store.steampowered.com/app/{appid}/"))

    # -------------------------- Microsoft Store -------------------------
    if record.get("is_microsoft_owned"):
        pfn = str(record.get("package_family_name") or record.get("pfn") or "").strip()
        if pfn:
            uri = "ms-windows-store://pdp/?PFN=" + urllib.parse.quote(pfn, safe="._-")
        else:
            uri = "ms-windows-store://search/?query=" + urllib.parse.quote_plus(name)
        if _open_native(uri):
            return True
        return bool(webbrowser.open(uri))

    # -------------------------- Неизвестный магазин ---------------------
    if name:
        return bool(webbrowser.open(
            "https://www.google.com/search?q=" + urllib.parse.quote_plus(name + " game store")
        ))
    return False


def open_price_offer(offer):
    """Открывает страницу предложения из price_check (родное приложение → веб)."""
    offer = offer or {}
    native = offer.get("native_uri") or ""
    url = offer.get("url") or ""
    if native and _open_native(native):
        return True
    if url:
        return bool(webbrowser.open(url))
    return False
