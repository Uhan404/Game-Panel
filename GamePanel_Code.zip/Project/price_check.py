# -*- coding: utf-8 -*-
"""Поиск цен на игру в Steam, Epic Games Store и Microsoft Store.

Используется, когда игры нет в библиотеке: ищем её во всех трёх магазинах
и отдаём единый список предложений, отсортированный от меньшей цены к большей.

Все три магазина опрашиваются в одном регионе (app_config["price_country"],
по умолчанию US → USD), иначе цены в разных валютах нельзя честно сравнивать.

Только стандартная библиотека (urllib) — новых зависимостей для PyInstaller нет.
"""

import json
import re
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

from logger import get_logger

log = get_logger()

DEFAULT_COUNTRY = "US"
MAX_PER_STORE = 8
TIMEOUT = 12

STORE_STEAM = "steam"
STORE_EPIC = "epic"
STORE_MS = "microsoft"
STORE_LABELS = {STORE_STEAM: "Steam", STORE_EPIC: "Epic", STORE_MS: "Microsoft"}

# Популярные регионы для выпадающего списка (код ISO 3166-1 alpha-2, название).
REGIONS = [
    ("US", "США"), ("GB", "Великобритания"), ("DE", "Германия"), ("FR", "Франция"),
    ("ES", "Испания"), ("IT", "Италия"), ("NL", "Нидерланды"), ("PL", "Польша"),
    ("CZ", "Чехия"), ("SE", "Швеция"), ("TR", "Турция"), ("UA", "Украина"),
    ("KZ", "Казахстан"), ("BY", "Беларусь"), ("RU", "Россия"), ("GE", "Грузия"),
    ("AM", "Армения"), ("AZ", "Азербайджан"), ("UZ", "Узбекистан"), ("CA", "Канада"),
    ("MX", "Мексика"), ("BR", "Бразилия"), ("AR", "Аргентина"), ("JP", "Япония"),
    ("KR", "Южная Корея"), ("IN", "Индия"), ("AU", "Австралия"), ("AE", "ОАЭ"),
]
OTHER_REGION = "Другой регион…"
REGION_NAMES = dict(REGIONS)


def region_choices():
    """Строки для выпадающего списка: «US — США» … и «Другой регион…» в конце."""
    return [f"{code} — {name}" for code, name in REGIONS] + [OTHER_REGION]


def region_label(code):
    code = (code or "").upper()
    return f"{code} — {REGION_NAMES[code]}" if code in REGION_NAMES else OTHER_REGION


def valid_region_code(code):
    return bool(re.fullmatch(r"[A-Za-z]{2}", (code or "").strip()))


def norm_title(text):
    """Название без регистра, знаков и пробелов — для точного сравнения («Hades™» == «hades»)."""
    return re.sub(r"[^0-9a-zа-яё]+", "", (text or "").lower())


def exact_unavailable(query, unavailable):
    """Недоступные в регионе предложения, чьё название ПОЛНОСТЬЮ совпадает с запросом."""
    q = norm_title(query)
    return [o for o in unavailable if q and norm_title(o["title"]) == q]


_USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
               "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")

# Валюта → символ для красивого вывода. Остальные печатаются кодом (например "PLN 99.99").
_SYMBOLS = {"USD": "$", "EUR": "€", "GBP": "£", "RUB": "₽", "UAH": "₴",
            "JPY": "¥", "KZT": "₸", "TRY": "₺", "BRL": "R$", "INR": "₹"}

_MS_SUGGEST_URL = "https://www.microsoft.com/services/api/v3/suggest"
_MS_CLIENT_ID = "7F27B536-CF6B-4C65-8638-A0F8CBDFCA65"
_MS_CATALOG_URL = "https://displaycatalog.mp.microsoft.com/v7.0/products"

_EPIC_GRAPHQL_ENDPOINTS = (
    "https://store.epicgames.com/graphql",
    "https://launcher.store.epicgames.com/graphql",
)

_EPIC_QUERY = """
query searchStoreQuery($keywords: String!, $country: String!, $locale: String!, $count: Int!) {
  Catalog {
    searchStore(keywords: $keywords, country: $country, locale: $locale, count: $count%ARGS%) {
      elements {
        title
        id
        namespace
        urlSlug
        productSlug
        offerType
        price(country: $country) {
          totalPrice {
            discountPrice
            originalPrice
            currencyCode
            currencyInfo { decimals }
          }
        }
        catalogNs { mappings(pageType: "productHome") { pageSlug pageType } }
        offerMappings { pageSlug pageType }
      }
    }
  }
}
"""

_EPIC_CATEGORY = ', category: "games/edition/base|bundles/games"'
# allowCountries — тот же фильтр, что использует сам сайт: оставляет только то,
# что можно купить в указанной стране. Разница с выдачей без фильтра = недоступные игры.
_EPIC_ALLOW = ', allowCountries: $country'


# ----------------------------------------------------------------------------
# Утилиты
# ----------------------------------------------------------------------------

def _http_json(url, payload=None, headers=None, timeout=TIMEOUT):
    """GET (или POST, если передан payload) и разбор JSON. Бросает исключение при ошибке."""
    hdrs = {"User-Agent": _USER_AGENT, "Accept": "application/json, */*"}
    if headers:
        hdrs.update(headers)
    data = None
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        hdrs["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=hdrs,
                                 method="POST" if data is not None else "GET")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8", errors="ignore"))


def format_money(amount, currency):
    if amount is None:
        return ""
    if currency in ("JPY", "KZT", "KRW", "CLP", "VND", "IDR", "HUF"):
        num = f"{amount:,.0f}".replace(",", " ")
    else:
        num = f"{amount:,.2f}".replace(",", " ")
    sym = _SYMBOLS.get(currency)
    if sym in ("$", "€", "£", "¥", "R$"):
        return f"{sym}{num}"
    if sym:
        return f"{num} {sym}"
    return f"{currency} {num}".strip()


def _offer(store, title, final, original, currency, url, native_uri="", store_id="", note=""):
    """Единый формат предложения. final=None → цена неизвестна."""
    discount = 0
    if final is not None and original and original > final > -1:
        discount = int(round((1 - final / original) * 100))

    if final is None:
        text = note or "Цена не указана"
    elif final == 0:
        text = "Бесплатно"
    else:
        text = format_money(final, currency)

    return {
        "store": store,
        "store_label": STORE_LABELS[store],
        "title": title,
        "price": final,                 # float | None — по нему сортируем
        "original": original if discount else None,
        "discount": discount,
        "currency": currency,
        "price_text": text,
        "original_text": format_money(original, currency) if discount else "",
        "url": url,                     # веб-ссылка (запасной вариант)
        "native_uri": native_uri,       # steam://..., ms-windows-store://...
        "store_id": store_id,
    }


def _tokens(text):
    return [t for t in re.split(r"[^0-9a-zа-яё]+", (text or "").lower()) if t]


def _is_relevant(query_tokens, title):
    low = (title or "").lower()
    return all(t in low for t in query_tokens)


# ----------------------------------------------------------------------------
# Steam
# ----------------------------------------------------------------------------

def _steam_no_price_status(appid, country):
    """Для позиций без цены: free / soon / unavailable (нет в регионе) / unknown."""
    try:
        url = ("https://store.steampowered.com/api/appdetails?"
               + urllib.parse.urlencode({"appids": appid, "cc": country.lower(),
                                         "l": "english", "filters": "basic,release_date"}))
        data = _http_json(url).get(str(appid), {})
        if data.get("success") is False:
            return "unavailable"
        info = data.get("data") or {}
        if info.get("is_free"):
            return "free"
        if (info.get("release_date") or {}).get("coming_soon"):
            return "soon"
    except Exception as exc:
        log.debug("Steam appdetails %s: %s", appid, exc)
    return "unknown"


def search_steam(query, country=DEFAULT_COUNTRY):
    """Возвращает (offers, unavailable)."""
    url = ("https://store.steampowered.com/api/storesearch/?"
           + urllib.parse.urlencode({"term": query, "l": "english", "cc": country.lower()}))
    items = (_http_json(url).get("items") or [])[:MAX_PER_STORE]

    offers, unavailable, unpriced = [], [], []
    for it in items:
        appid = it.get("id")
        name = it.get("name")
        if not appid or not name:
            continue
        link = f"https://store.steampowered.com/app/{appid}/"
        native = f"steam://store/{appid}"
        price = it.get("price")
        if isinstance(price, dict) and price.get("final") is not None:
            cur = price.get("currency") or "USD"
            final = price["final"] / 100.0
            initial = (price.get("initial") or price["final"]) / 100.0
            offers.append(_offer(STORE_STEAM, name, final, initial, cur, link, native, str(appid)))
        else:
            unpriced.append((appid, name, link, native))

    # Для игр без цены уточняем статус (F2P / скоро / недоступна в регионе) — до 5 запросов параллельно.
    if unpriced:
        unpriced = unpriced[:5]
        with ThreadPoolExecutor(max_workers=5) as pool:
            statuses = list(pool.map(lambda x: _steam_no_price_status(x[0], country), unpriced))
        for (appid, name, link, native), status in zip(unpriced, statuses):
            if status == "unavailable":
                unavailable.append(_offer(STORE_STEAM, name, None, None, "USD", link, native,
                                          str(appid), note="Недоступна в регионе"))
            elif status == "free":
                offers.append(_offer(STORE_STEAM, name, 0.0, None, "USD", link, native, str(appid)))
            elif status == "soon":
                offers.append(_offer(STORE_STEAM, name, None, None, "USD", link, native,
                                     str(appid), note="Скоро выйдет"))
            else:
                offers.append(_offer(STORE_STEAM, name, None, None, "USD", link, native, str(appid)))
    return offers, unavailable


# ----------------------------------------------------------------------------
# Epic Games Store
# ----------------------------------------------------------------------------

def _epic_slug(el):
    for key in ("catalogNs", "offerMappings"):
        block = el.get(key)
        mappings = block.get("mappings") if isinstance(block, dict) else block
        for m in mappings or []:
            slug = (m or {}).get("pageSlug")
            if slug:
                return slug.split("/", 1)[0]
    for key in ("productSlug", "urlSlug"):
        slug = el.get(key)
        if slug and "/" not in slug.strip("/"):
            return slug.strip("/")
        if slug:
            return slug.strip("/").split("/", 1)[0]
    return ""


def _epic_request(query_text, variables):
    """Возвращает (elements, error). elements=None — запрос не удался (error объясняет почему)."""
    last_err = None
    for endpoint in _EPIC_GRAPHQL_ENDPOINTS:
        try:
            data = _http_json(endpoint, payload={"query": query_text, "variables": variables},
                              headers={"Origin": "https://store.epicgames.com",
                                       "Referer": "https://store.epicgames.com/"})
            store = ((data.get("data") or {}).get("Catalog") or {}).get("searchStore")
            if store is not None:
                return store.get("elements") or [], None
            last_err = f"GraphQL: {data.get('errors')}"
        except Exception as exc:
            last_err = exc
    log.debug("Epic request: %s", last_err)
    return None, last_err


def epic_gql(args=""):
    return _EPIC_QUERY.replace("%ARGS%", args)


def epic_offer(el, note=""):
    """Элемент searchStore → единый формат предложения (или None)."""
    title = el.get("title")
    if not title:
        return None
    slug = _epic_slug(el)
    link = (f"https://store.epicgames.com/en-US/p/{slug}" if slug else
            "https://store.epicgames.com/en-US/browse?q=" + urllib.parse.quote_plus(title))
    native = f"com.epicgames.launcher://store/product/{slug}" if slug else ""
    tp = ((el.get("price") or {}).get("totalPrice")) or {}
    cur = tp.get("currencyCode") or "USD"
    decimals = (tp.get("currencyInfo") or {}).get("decimals", 2)
    div = 10 ** int(decimals if decimals is not None else 2)
    if tp.get("discountPrice") is None:
        return _offer(STORE_EPIC, title, None, None, cur, link, native, el.get("id", ""), note=note)
    final = tp["discountPrice"] / div
    original = (tp.get("originalPrice") or tp["discountPrice"]) / div
    return _offer(STORE_EPIC, title, final, original, cur, link, native, el.get("id", ""), note=note)


def search_epic(query, country=DEFAULT_COUNTRY):
    """Возвращает (offers, unavailable). Бросает RuntimeError, если Epic недоступен."""
    variables = {"keywords": query, "country": country.upper(),
                 "locale": "en-US", "count": MAX_PER_STORE * 2}

    # 1) Всё, что нашлось, без ограничения по стране. Сначала с фильтром категории
    #    (только базовые игры и наборы), при отказе схемы — без него.
    category = _EPIC_CATEGORY
    everything, err = _epic_request(epic_gql(category), variables)
    if everything is None:
        category = ""
        everything, err = _epic_request(epic_gql(category), variables)
    if everything is None:
        raise RuntimeError(f"Epic недоступен: {err}")

    # 2) То же, но только доступное для покупки в этой стране.
    allowed, _err2 = _epic_request(epic_gql(category + _EPIC_ALLOW), variables)
    if allowed is None:
        log.info("Epic: фильтр allowCountries не сработал (%s) — недоступные игры не определяются", _err2)
        allowed = everything

    allowed_ids = {el.get("id") for el in allowed}
    offers, unavailable = [], []
    for el in allowed:
        o = epic_offer(el)
        if o and len(offers) < MAX_PER_STORE:
            offers.append(o)
    for el in everything:
        if el.get("id") not in allowed_ids:
            o = epic_offer(el, note="Недоступна в регионе")
            if o:
                o["price"], o["price_text"] = None, "Недоступна в регионе"
                unavailable.append(o)
    return offers, unavailable


# ----------------------------------------------------------------------------
# Microsoft Store
# ----------------------------------------------------------------------------

_MS_ID_RE = re.compile(r"(?<![A-Z0-9])([A-Z0-9]{12})(?![A-Z0-9])")


def _ms_find_ids(query):
    """Подсказки Microsoft Store → ID продуктов. Всегда en-US: это самый полный каталог,
    а доступность в нужном регионе проверяется отдельно по displaycatalog."""
    url = _MS_SUGGEST_URL + "?" + urllib.parse.urlencode({
        "market": "en-US",
        "clientId": _MS_CLIENT_ID,
        "sources": "DCatAll-Products",
        "filter": "+ClientType:StoreWeb",
        "counts": "10",
        "query": query,
    })
    data = _http_json(url)
    ids = []
    for rs in data.get("ResultSets") or []:
        for sug in rs.get("Suggests") or []:
            pid = ""
            for meta in sug.get("Metas") or []:
                if (meta or {}).get("Key") == "BigCatalogId":
                    pid = meta.get("Value") or ""
            if not pid:
                m = _MS_ID_RE.findall((sug.get("Url") or "").upper())
                pid = m[-1] if m else ""
            if pid and pid not in ids:
                ids.append(pid)
    return ids[:10]


def ms_fetch_products(ids, market):
    """displaycatalog → {ProductId: product} для указанного рынка."""
    if not ids:
        return {}
    url = _MS_CATALOG_URL + "?" + urllib.parse.urlencode({
        "bigIds": ",".join(ids),
        "market": market.upper(),
        "languages": "en-us",
        "MS-CV": "DGU1mcuYo0WMMp+F.1",
    })
    return {p.get("ProductId"): p for p in (_http_json(url).get("Products") or [])}


def _ms_pick_price(product):
    """Достаёт (final, original, currency) из DisplaySkuAvailabilities."""
    best = None
    for sku_av in (product or {}).get("DisplaySkuAvailabilities") or []:
        sku_type = ((sku_av.get("Sku") or {}).get("SkuType") or "").lower()
        if sku_type and sku_type != "full":     # пропускаем trial и т.п.
            continue
        for av in sku_av.get("Availabilities") or []:
            actions = av.get("Actions") or []
            if actions and "Purchase" not in actions:
                continue
            price = (av.get("OrderManagementData") or {}).get("Price") or {}
            if price.get("ListPrice") is None:
                continue
            cand = (float(price["ListPrice"]),
                    float(price.get("MSRP") or price["ListPrice"]),
                    price.get("CurrencyCode") or "USD")
            if best is None or cand[0] < best[0]:
                best = cand
    return best


def ms_is_game(product):
    return bool(product) and (product.get("ProductType") or "").lower() == "game"


def ms_title(product):
    return ((product.get("LocalizedProperties") or [{}])[0]).get("ProductTitle") or ""


def ms_links(pid):
    return (f"https://apps.microsoft.com/detail/{pid}",
            f"ms-windows-store://pdp/?ProductId={pid}")


def search_microsoft(query, country=DEFAULT_COUNTRY):
    """Возвращает (offers, unavailable).

    Игра считается недоступной, если в опорном регионе (US, а для US — GB) у неё есть
    цена, а в выбранном регионе покупки нет."""
    ids = _ms_find_ids(query)
    if not ids:
        return [], []
    here = ms_fetch_products(ids, country)
    ref_market = "GB" if country.upper() == "US" else "US"
    try:
        ref = ms_fetch_products(ids, ref_market)
    except Exception as exc:
        log.debug("MS опорный рынок %s: %s", ref_market, exc)
        ref = {}

    offers, unavailable = [], []
    for pid in ids:                                   # сохраняем порядок релевантности
        ph, pr = here.get(pid), ref.get(pid)
        if not (ms_is_game(ph) or ms_is_game(pr)):    # отсекаем приложения и DLC
            continue
        link, native = ms_links(pid)
        picked = _ms_pick_price(ph) if ms_is_game(ph) else None
        if picked:
            final, original, cur = picked
            offers.append(_offer(STORE_MS, ms_title(ph), final, original, cur, link, native, pid))
        elif ms_is_game(pr) and _ms_pick_price(pr):
            unavailable.append(_offer(STORE_MS, ms_title(pr), None, None, "USD", link, native,
                                      pid, note="Недоступна в регионе"))
        elif ms_is_game(ph):
            offers.append(_offer(STORE_MS, ms_title(ph), None, None, "USD", link, native, pid))
        if len(offers) >= MAX_PER_STORE:
            break
    return offers, unavailable


# ----------------------------------------------------------------------------
# Общий поиск
# ----------------------------------------------------------------------------

def sort_offers(offers):
    """Цена по возрастанию; бесплатные — первыми; без цены — в конце."""
    return sorted(offers, key=lambda o: (o["price"] is None,
                                         o["price"] if o["price"] is not None else 0.0,
                                         o["title"].lower()))


def search_all_prices(query, country=DEFAULT_COUNTRY):
    """Опрашивает три магазина параллельно.

    Возвращает словарь:
      offers      — доступные в регионе предложения, от меньшей цены к большей;
      unavailable — найденные, но недоступные в регионе (в список не попадают);
      errors      — {store: текст ошибки} для магазинов, которые не ответили.
    """
    query = (query or "").strip()
    country = (country or DEFAULT_COUNTRY).strip().upper() or DEFAULT_COUNTRY
    result = {"offers": [], "unavailable": [], "errors": {}}
    if not query:
        return result

    searchers = {STORE_STEAM: search_steam, STORE_EPIC: search_epic, STORE_MS: search_microsoft}
    offers, unavailable = [], []

    def run(item):
        store, fn = item
        try:
            found, missing = fn(query, country)
            return store, found, missing, None
        except Exception as exc:
            log.warning("Поиск цен (%s) для «%s»: %s", store, query, exc)
            return store, [], [], str(exc) or exc.__class__.__name__

    with ThreadPoolExecutor(max_workers=3) as pool:
        for store, found, missing, err in pool.map(run, searchers.items()):
            offers.extend(found)
            unavailable.extend(missing)
            if err:
                result["errors"][store] = err

    # Убираем явно нерелевантное (все слова запроса должны быть в названии).
    # Если фильтр вычистил всё — показываем как есть: лучше шум, чем пустота.
    toks = _tokens(query)
    relevant = [o for o in offers if _is_relevant(toks, o["title"])]
    offers = relevant or offers

    def dedupe(items):
        seen, unique = set(), []
        for o in items:
            key = (o["store"], o["title"].lower())
            if key not in seen:
                seen.add(key)
                unique.append(o)
        return unique

    result["offers"] = sort_offers(dedupe(offers))
    result["unavailable"] = dedupe(unavailable)
    return result
