# language: Python 3.10+, file: epic_slug.py
# Разрешение рабочего slug'а продукта Epic Games Store.
#
# Два независимых способа (по убыванию точности):
#   1. Catalog API — запрос catalogOffer по namespace + catalog_id.
#      Даёт точный pageSlug для конкретного предложения.
#   2. GraphQL-поиск по названию — резерв, если catalog lookup не сработал
#      (например, у игры отсутствует namespace или это DLC).
#
# Оба запроса идут через актуальные эндпоинты:
#   • launcher.store.epicgames.com/graphql
#   • store.epicgames.com/graphql
# (graphql.epicgames.com/graphql отключён и возвращает 404/410).

import json
import urllib.request

from logger import get_logger

log = get_logger()

_GRAPHQL_ENDPOINTS = (
    "https://launcher.store.epicgames.com/graphql",
    "https://store.epicgames.com/graphql",
)

_USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
               "AppleWebKit/537.36 (KHTML, like Gecko) "
               "Chrome/124.0.0.0 Safari/537.36")

# Фрагменты, которых не должно быть в slug'е страницы продукта.
# Если найдены — значит, GraphQL вернул DLC, bundle или edition вместо базовой игры.
_BAD_SLUG_TOKENS = (
    "dlc", "addon", "bundle", "pack", "edition", "upgrade",
    "sale", "cash", "content", "pass", "supporter",
    "editor", "skin", "map", "directors-cut",
)

_CATALOG_QUERY = (
    "query catalogQuery($namespace: String!, $id: String!) {"
    "  Catalog {"
    "    catalogOffer(namespace: $namespace, id: $id) {"
    "      catalogNs { mappings { pageSlug } }"
    "    }"
    "  }"
    "}"
)

_SEARCH_QUERY = (
    "query searchStoreQuery($keywords: String!, $country: String!, $locale: String!) {"
    "  Catalog {"
    "    searchStore(keywords: $keywords, country: $country, locale: $locale, count: 50) {"
    "      elements {"
    "        title"
    "        catalogNs { mappings { pageSlug } }"
    "      }"
    "    }"
    "  }"
    "}"
)


def _post_graphql(endpoint, query, variables):
    body = json.dumps({"query": query, "variables": variables}).encode("utf-8")
    req = urllib.request.Request(
        endpoint,
        data=body,
        headers={
            "Content-Type": "application/json",
            "User-Agent": _USER_AGENT,
            "Origin": "https://store.epicgames.com",
            "Referer": "https://store.epicgames.com/",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=12) as resp:
        return json.loads(resp.read().decode("utf-8", errors="ignore"))


def clean_slug(raw):
    """Приводит slug к чистому виду.

    Поддерживает все встречающиеся форматы:
      "fortnite"                                        → "fortnite"
      "fortnite/home"                                   → "fortnite"
      "/p/death-stranding"                              → "death-stranding"
      "https://store.epicgames.com/p/fortnite/home"     → "fortnite"
      "https://store.epicgames.com/en-US/p/fortnite?x=1" → "fortnite"
    """
    if not raw:
        return ""
    s = str(raw).strip()
    if not s:
        return ""

    if "/p/" in s:
        s = s.split("/p/", 1)[1]
    elif "://" in s:
        # Полный URL без /p/ — берём всё после хоста
        s = s.split("/", 3)[-1]

    s = s.split("?", 1)[0].split("#", 1)[0]

    if s.startswith("p/"):
        s = s[2:]

    s = s.strip("/").split("/", 1)[0]
    return s.strip()


def _is_good_slug(slug):
    if not slug:
        return False
    low = slug.lower()
    return not any(bad in low for bad in _BAD_SLUG_TOKENS)


def _pick_slug(mappings):
    """Выбирает лучший pageSlug из списка mappings.

    Предпочитает «чистые» (без dlc/bundle/edition), из них — самый короткий.
    Если все плохие — возвращает самый короткий из них.
    """
    if not isinstance(mappings, list):
        return ""
    candidates = []
    for m in mappings:
        if isinstance(m, dict):
            s = clean_slug(m.get("pageSlug"))
            if s:
                candidates.append(s)
    if not candidates:
        return ""
    clean = [s for s in candidates if _is_good_slug(s)]
    return min(clean or candidates, key=len)


def _slug_via_catalog(namespace, catalog_id):
    """Запрос catalogOffer по namespace + catalog_id — самый точный способ."""
    if not namespace or not catalog_id:
        return ""
    variables = {"namespace": namespace, "id": catalog_id}
    for endpoint in _GRAPHQL_ENDPOINTS:
        try:
            data = _post_graphql(endpoint, _CATALOG_QUERY, variables)
        except Exception as e:
            log.debug("catalog %s: %s", endpoint, e)
            continue
        offer = (data.get("data") or {}).get("Catalog", {}).get("catalogOffer") or {}
        if not isinstance(offer, dict):
            continue
        catalog_ns = offer.get("catalogNs") or {}
        slug = _pick_slug(catalog_ns.get("mappings"))
        if slug:
            log.info("Epic slug via catalog: %s", slug)
            return slug
    return ""


def _slug_via_search(title):
    """Fallback: поиск в магазине по названию."""
    if not title:
        return ""
    variables = {"keywords": title.strip(), "country": "US", "locale": "en-US"}
    for endpoint in _GRAPHQL_ENDPOINTS:
        try:
            data = _post_graphql(endpoint, _SEARCH_QUERY, variables)
        except Exception as e:
            log.debug("search %s: %s", endpoint, e)
            continue
        elements = (data.get("data") or {}).get("Catalog", {}).get("searchStore", {}).get("elements") or []
        if not isinstance(elements, list) or not elements:
            continue

        # Приоритет 1: точное совпадение по названию.
        for el in elements:
            if not isinstance(el, dict):
                continue
            if str(el.get("title") or "").strip().lower() == title.strip().lower():
                slug = _pick_slug((el.get("catalogNs") or {}).get("mappings"))
                if slug:
                    log.info("Epic slug via search (exact): %s", slug)
                    return slug

        # Приоритет 2: собираем все slug'и из всех результатов.
        # Это спасает от случаев, когда первый результат — Director's Cut / Deluxe Edition,
        # а базовая игра находится ниже в списке.
        all_candidates = []
        for el in elements:
            if not isinstance(el, dict):
                continue
            mappings = (el.get("catalogNs") or {}).get("mappings") or []
            for m in mappings:
                if isinstance(m, dict):
                    s = clean_slug(m.get("pageSlug"))
                    if s:
                        all_candidates.append(s)

        # Сначала ищем «чистый» slug (без dlc, edition, directors-cut и т.д.)
        clean_candidates = [s for s in all_candidates if _is_good_slug(s)]
        if clean_candidates:
            best = min(clean_candidates, key=len)
            log.info("Epic slug via search (clean): %s", best)
            return best

        # Если чистых нет — берём самый короткий из имеющихся.
        if all_candidates:
            best = min(all_candidates, key=len)
            log.info("Epic slug via search (fallback): %s", best)
            return best

    return ""


def resolve_epic_slug(title, slug_from_api="", namespace="", catalog_id=""):
    """Возвращает рабочий slug для лаунчер-URI страницы продукта.

    Порядок:
      1. Slug из Library API — если он есть и не мусорный, используем без сети.
      2. Catalog lookup по namespace + catalog_id — основной путь для игр без slug.
      3. GraphQL-поиск по названию — для случаев, когда namespace/catalog_id нет.
      4. Slug из API в последнюю очередь — если все остальные методы не сработали.
    """
    candidate = clean_slug(slug_from_api)
    if candidate and _is_good_slug(candidate):
        return candidate

    slug = _slug_via_catalog(namespace, catalog_id)
    if slug:
        return slug

    slug = _slug_via_search(title)
    if slug:
        return slug

    # Если API дал мусорный slug, а других источников нет — используем его,
    # чтобы лаунчер открыл хоть какую-то страницу.
    return candidate