# -*- coding: utf-8 -*-
"""GamePanel UI — тёмный игровой лаунчер в духе современных PC-магазинов."""
import math
import os
import time
import webbrowser
import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from config import state, save_config, save_library, normalize_name, delete_from_library
from logger import get_logger
import price_check as pc
import store_deals

log = get_logger()

BG = "#101218"
SIDEBAR = "#151922"
PANEL = "#1b202b"
PANEL_HOVER = "#252c39"
TEXT = "#f4f6fb"
MUTED = "#929bad"
ACCENT = "#75e0b2"
ACCENT_DARK = "#2b9d78"
BLUE = "#6d91ff"
BORDER = "#2a3140"
WARN = "#f0b45a"
WARN_BG = "#2b2218"
STORE_CACHE_TTL = 600        # секунд: кэш результатов поиска и главной страницы магазина
FAILED_CACHE_TTL = 30        # секунд: «всё упало» кэшируем ненадолго, потом пробуем снова


class ScrollArea:
    """Прокручиваемая область для небольших списков (вкладка «Магазин»).

    Без повторных подгонок положения: scrollregion обновляется только по размеру
    содержимого, а ограничение прокрутки делает сам Canvas (confine)."""

    def __init__(self, parent, bg):
        self.frame = tk.Frame(parent, bg=bg)
        self.canvas = tk.Canvas(self.frame, bg=bg, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(self.frame, orient="vertical", command=self.canvas.yview)
        self.inner = tk.Frame(self.canvas, bg=bg)
        self._win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", self._on_inner)
        self.canvas.bind("<Configure>", self._on_canvas)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

    def _on_inner(self, event):
        self.canvas.configure(scrollregion=(0, 0, event.width, event.height))

    def _on_canvas(self, event):
        self.canvas.itemconfigure(self._win, width=event.width)

    def clear(self):
        for child in self.inner.winfo_children():
            child.destroy()
        self.canvas.yview_moveto(0)


def _merge(target, source):
    from config import merge_game_record
    for title, record in (source or {}).items():
        if not isinstance(record, dict):
            continue
        key = title
        if key in target:
            merge_game_record(target[key], record)
        else:
            same_title_other_store = any(
                normalize_name(k.replace(" (Steam)", "").replace(" (Epic)", "").replace(" (Microsoft)", ""))
                == normalize_name(title)
                and (v.get("is_steam_owned") or v.get("is_epic_owned"))
                for k, v in target.items() if isinstance(v, dict)
            )
            if same_title_other_store and record.get("is_microsoft_owned"):
                key = title + " (Microsoft)"
            target[key] = dict(record)


def _scan_sources(source="all"):
    """Сканирует все библиотеки или только выбранный магазин."""
    if source not in ("all", "steam", "epic", "microsoft"):
        raise ValueError(f"Неизвестный источник: {source}")
    from epic_games import read_epic_manifests
    from epic_auth_embedded import fetch_epic_library, is_logged_in
    from scanner import read_steam_manifests
    from config import dedup_library

    library = {k: dict(v) for k, v in state.get("library", {}).items() if isinstance(v, dict)}
    for rec in library.values():
        if source == "all":
            rec["is_installed"] = False
            for store in ("steam", "epic", "microsoft"):
                rec[f"{store}_installed"] = False
        elif rec.get(f"is_{source}_owned"):
            rec[f"{source}_installed"] = False
            rec["is_installed"] = any(rec.get(f"{store}_installed") for store in ("steam", "epic", "microsoft"))

    # 1. Epic локальный
    if source in ("all", "epic"):
      try:
          epic, error = read_epic_manifests()
          if epic:
              _merge(library, epic)
              for title, scanned in epic.items():
                  if scanned.get("is_installed") and title in library:
                      library[title]["epic_installed"] = True
          elif error: log.info("Epic scan: %s", error)
      except Exception: log.exception("Epic manifest scan failed")

    # 2. Steam локальный
    if source in ("all", "steam"):
      manifests = {}
      try:
          manifests = read_steam_manifests()
          by_appid = {str(v.get("appid", "")): v for v in library.values()}
          for appid, data in manifests.items():
              path = data.get("path")
              name = data.get("name")
              if appid in by_appid:
                  rec = by_appid[appid]
                  rec["path"] = path
                  rec["is_installed"] = True
                  rec["is_steam_owned"] = True
                  rec["steam_installed"] = True
              elif name:
                  library[name] = {
                      "name": name, "appid": appid, "path": path,
                      "is_installed": True, "steam_installed": True, "is_steam_owned": True,
                      "install_url": f"steam://install/{appid}"
                  }
      except Exception: log.exception("Steam manifest scan failed")

      # 3. Steam Online (API)
      cfg = state.get("app_config", {})
      if cfg.get("steam_id") and cfg.get("steam_api_key"):
          try:
              from steam_api import fetch_steam_games
              games, error = fetch_steam_games(cfg["steam_id"], cfg["steam_api_key"])
              if games:
                  _merge(library, games)
                  by_appid = {str(v.get("appid", "")): v for v in library.values()}
                  for appid, data in manifests.items():
                      if str(appid) in by_appid:
                          by_appid[str(appid)]["path"] = data.get("path")
                          by_appid[str(appid)]["is_installed"] = True
                          by_appid[str(appid)]["steam_installed"] = True
              elif error: log.warning("Steam API: %s", error)
          except Exception: log.exception("Steam API scan failed")

    # 4. Epic Online (Library API)
    if source in ("all", "epic"):
      try:
          ok, name = is_logged_in()
          if ok:
              lib_games, lib_err = fetch_epic_library()
              if lib_games: _merge(library, lib_games)
              elif lib_err: log.info("Epic Library: %s", lib_err)
      except Exception: log.exception("Epic Library scan failed")

    # 5. Microsoft Store
    if source in ("all", "microsoft"):
      try:
          import microsoft_store
          microsoft_store.refresh_package_cache()
          games, error = microsoft_store.read_microsoft_store_games(
              known_titles=list(library.keys()), add_known_games=True
          )
          if games:
              _merge(library, games)
              for title, scanned in games.items():
                  if scanned.get("is_installed") and title in library:
                      library[title]["microsoft_installed"] = True
          elif error: log.info("Microsoft scan: %s", error)
      except Exception: log.exception("Microsoft Store scan failed")

      # 6. XboxGames folders
      try:
          from scanner import get_all_drives, find_best_exe
          for drive in get_all_drives():
              xbox_root = os.path.join(drive, "XboxGames")
              if not os.path.isdir(xbox_root): continue
              try: folders = os.listdir(xbox_root)
              except OSError: continue
              for folder in folders:
                  game_dir = os.path.join(xbox_root, folder)
                  if not os.path.isdir(game_dir): continue
                  exe_path = find_best_exe(game_dir)
                  if not exe_path: continue
                  match = next((v for k, v in library.items()
                                if normalize_name(k.replace(" (Microsoft)", "")) == normalize_name(folder)), None)
                  if match:
                      match["path"] = exe_path
                      match["install_location"] = game_dir
                      match["is_installed"] = True
                      match["is_microsoft_owned"] = True
                      match["microsoft_installed"] = True
                      match["source"] = "microsoft"
                  else:
                      library[folder] = {
                          "name": folder, "appid": "", "path": exe_path,
                          "install_location": game_dir, "is_installed": True, "microsoft_installed": True,
                          "is_microsoft_owned": True, "source": "microsoft",
                      }
      except Exception: log.exception("XboxGames folder scan failed")

    state["library"] = library
    dedup_library()
    save_library()
    return len(state["library"])


class GamePanelApp:
    def __init__(self, root):
        self.root = root
        self.root.title("GamePanel")
        self.root.geometry("1360x860")
        self.root.minsize(1050, 680)
        self.root.configure(bg=BG)
        self.filter = "all"
        self.search_var = tk.StringVar()
        
        self._search_after_id = None
        self.search_var.trace_add("write", self._on_search_change)
        
        self._scanning = False
        self.view = "library"            # library | store

        # --- виртуализированная сетка библиотеки ---
        self._games = []
        self._cards = {}                 # индекс игры -> (card, id окна на canvas)
        self._cols = 1
        self._slot_w = 0
        self._slot_h = 0
        self._card_h = 0
        self._last_canvas_w = 0
        self._layout_after_id = None
        self._sync_pending = False
        self._empty_frame = None
        self._empty_win = None

        # --- вкладка «Магазин» ---
        self.store_query = tk.StringVar()
        self._store_after_id = None
        self._price_cache = {}           # (запрос, регион) -> (result, ts)
        self._price_inflight = set()
        self._home_cache = {}            # регион -> (ts, data)
        self._home_inflight = set()
        self.store_query.trace_add("write", self._on_store_query_change)
        self._build_style()
        self._build_shell()
        self.render_games()
        
        self.root.bind_all("<MouseWheel>", self._on_mousewheel)
        self.root.bind_all("<Button-4>", lambda e: self._on_mousewheel(e))
        self.root.bind_all("<Button-5>", lambda e: self._on_mousewheel(e))
        self.root.bind_all("<KeyPress>", self._global_keypress)

    def _global_keypress(self, event=None):
        # Перехват Ctrl+V по физическому keycode (86 = V)
        if event and (event.state & 0x4) and event.keycode == 86:
            widget = self.root.focus_get()
            if widget and widget.winfo_class() in ("Entry", "TEntry", "Text"):
                try:
                    text = self.root.clipboard_get()
                    try:
                        widget.delete("sel.first", "sel.last")
                    except tk.TclError:
                        pass
                    widget.insert("insert", text)
                    return "break"
                except tk.TclError:
                    return "break"
        return None

    def _on_search_change(self, *args):
        if getattr(self, "_search_after_id", None):
            self.root.after_cancel(self._search_after_id)
        self._search_after_id = self.root.after(300, self.render_games)

    def _build_style(self):
        style = ttk.Style()
        try: style.theme_use("clam")
        except tk.TclError: pass
        style.configure("Vertical.TScrollbar", background=PANEL, troughcolor=BG, bordercolor=BG, arrowcolor=MUTED)
        style.configure("TEntry", fieldbackground=PANEL, foreground=TEXT, insertcolor=TEXT, bordercolor=BORDER, padding=10)
        style.configure("TCombobox", fieldbackground=PANEL, background=PANEL_HOVER, foreground=TEXT,
                        arrowcolor=TEXT, bordercolor=BORDER, lightcolor=PANEL, darkcolor=PANEL, padding=6)
        style.map("TCombobox", fieldbackground=[("readonly", PANEL)], foreground=[("readonly", TEXT)],
                  selectbackground=[("readonly", PANEL)], selectforeground=[("readonly", TEXT)])
        self.root.option_add("*TCombobox*Listbox.background", PANEL)
        self.root.option_add("*TCombobox*Listbox.foreground", TEXT)
        self.root.option_add("*TCombobox*Listbox.selectBackground", ACCENT_DARK)
        self.root.option_add("*TCombobox*Listbox.selectForeground", "#07130f")

    def _label(self, parent, text, size=10, color=TEXT, bold=False, **kw):
        bg = kw.pop("bg", parent.cget("bg"))
        return tk.Label(parent, text=text, bg=bg, fg=color, font=("Segoe UI", size, "bold" if bold else "normal"), **kw)

    def _button(self, parent, text, command, primary=False):
        bg = ACCENT_DARK if primary else PANEL_HOVER
        fg = "#07130f" if primary else TEXT
        return tk.Button(parent, text=text, command=command, bg=bg, fg=fg,
                         activebackground=ACCENT if primary else "#343d4d",
                         activeforeground=fg, relief="flat", bd=0, cursor="hand2",
                         font=("Segoe UI", 9, "bold"), padx=14, pady=9,
                         highlightthickness=0)

    def _bind_entry_clipboard(self, entry, parent):
        # Контекстное меню (ПКМ)
        def paste(e=None):
            try: entry.insert(tk.INSERT, parent.clipboard_get())
            except Exception: pass
            return "break"
        def copy(e=None):
            try:
                parent.clipboard_clear()
                parent.clipboard_append(entry.selection_get())
            except Exception: pass
            return "break"
        def cut(e=None):
            try:
                parent.clipboard_clear()
                parent.clipboard_append(entry.selection_get())
                entry.delete("sel.first", "sel.last")
            except Exception: pass
            return "break"
        def select_all(e=None):
            try:
                entry.select_range(0, tk.END)
                entry.icursor(tk.END)
            except Exception: pass
            return "break"
        
        menu = tk.Menu(entry, tearoff=0)
        menu.add_command(label="Вставить", command=paste)
        menu.add_command(label="Копировать", command=copy)
        menu.add_command(label="Вырезать", command=cut)
        menu.add_command(label="Выделить всё", command=select_all)
        entry.bind("<Button-3>", lambda e: menu.tk_popup(e.x_root, e.y_root))

    def _build_shell(self):
        shell = tk.Frame(self.root, bg=BG)
        shell.pack(fill="both", expand=True)

        side = tk.Frame(shell, bg=SIDEBAR, width=226)
        side.pack(side="left", fill="y")
        side.pack_propagate(False)

        brand = tk.Frame(side, bg=SIDEBAR)
        brand.pack(fill="x", padx=22, pady=(27, 34))
        self._label(brand, "GAME", 12, ACCENT, True).pack(anchor="w")
        self._label(brand, "PANEL", 23, TEXT, True).pack(anchor="w")
        self._label(brand, "YOUR LIBRARY, ONE PLACE", 7, MUTED, True).pack(anchor="w", pady=(5, 0))

        self._label(side, "БИБЛИОТЕКА", 8, MUTED, True).pack(anchor="w", padx=22, pady=(0, 12))
        self.nav_buttons = {}
        nav = [("all", "◈  Все игры"), ("installed", "▣  Установленные"),
               ("steam", "●  Steam"), ("epic", "◆  Epic Games"),
               ("microsoft", "⊞  Microsoft / Xbox")]
        for key, caption in nav:
            btn = tk.Button(side, text=caption, anchor="w",
                            command=lambda k=key: self.set_filter(k),
                            bg=SIDEBAR, fg=TEXT, activebackground=PANEL_HOVER,
                            activeforeground=ACCENT, relief="flat", bd=0,
                            cursor="hand2", font=("Segoe UI", 10), padx=18, pady=12)
            btn.pack(fill="x", padx=10, pady=2)
            self.nav_buttons[key] = btn

        tk.Frame(side, bg=BORDER, height=1).pack(fill="x", padx=20, pady=(18, 14))
        self._label(side, "МАГАЗИНЫ", 8, MUTED, True).pack(anchor="w", padx=22, pady=(0, 10))
        store_btn = tk.Button(side, text="🛒  Цены и скидки", anchor="w", command=self.show_store,
                              bg=SIDEBAR, fg=TEXT, activebackground=PANEL_HOVER,
                              activeforeground=ACCENT, relief="flat", bd=0,
                              cursor="hand2", font=("Segoe UI", 10), padx=18, pady=12)
        store_btn.pack(fill="x", padx=10, pady=2)
        self.nav_buttons["store"] = store_btn

        tk.Frame(side, bg=BORDER, height=1).pack(fill="x", padx=20, pady=22)
        self._label(side, "ИНСТРУМЕНТЫ", 8, MUTED, True).pack(anchor="w", padx=22, pady=(0, 10))
        
        # Оставили только библиотеку и настройки, сканирование перенесено в настройки
        self._button(side, "⊞  Библиотека Microsoft Store", self.open_microsoft_library).pack(fill="x", padx=16, pady=(8, 3))
        self._button(side, "⚙  Аккаунты и синхронизация", self.open_settings).pack(fill="x", padx=16, pady=5)
        
        self._label(side, "GAMEPANEL  •  DESKTOP", 8, "#626d80", True).pack(side="bottom", pady=20)

        content = tk.Frame(shell, bg=BG)
        content.pack(side="left", fill="both", expand=True)
        self.library_view = tk.Frame(content, bg=BG)
        self.library_view.pack(fill="both", expand=True)
        lib = self.library_view
        top = tk.Frame(lib, bg=BG)
        top.pack(fill="x", padx=34, pady=(26, 18))
        self._label(top, "МОЯ КОЛЛЕКЦИЯ", 9, ACCENT, True).pack(anchor="w")
        title_row = tk.Frame(top, bg=BG)
        title_row.pack(fill="x", pady=(5, 14))
        self._label(title_row, "Игровая библиотека", 23, TEXT, True).pack(side="left")
        
        search_entry = tk.Entry(title_row, textvariable=self.search_var, width=31, bg=PANEL, fg=TEXT, insertbackground=TEXT, relief="flat", font=("Segoe UI", 10), bd=2)
        search_entry.pack(side="right", ipady=4)
        self._bind_entry_clipboard(search_entry, self.root)
        
        self._label(top, "Ищите игры, фильтруйте по магазинам и запускайте в один клик.", 9, MUTED).pack(anchor="w")

        hero = tk.Frame(lib, bg="#202a37", height=168)
        hero.pack(fill="x", padx=34, pady=(0, 22))
        hero.pack_propagate(False)
        inner = tk.Frame(hero, bg="#202a37")
        inner.pack(fill="both", expand=True, padx=26, pady=20)
        self._label(inner, "ВАША КОЛЛЕКЦИЯ — БЕЗ ГРАНИЦ", 8, ACCENT, True).pack(anchor="w")
        self._label(inner, "Все игры в одном месте", 20, TEXT, True).pack(anchor="w", pady=(8, 3))
        self._label(inner, "Steam  •  Epic Games  •  Microsoft Store / Xbox", 9, "#b7c1d1").pack(anchor="w")

        bar = tk.Frame(lib, bg=BG)
        bar.pack(fill="x", padx=34, pady=(0, 12))
        self.section_title = self._label(bar, "Все игры", 14, TEXT, True)
        self.section_title.pack(side="left")
        self.count_label = self._label(bar, "0 игр", 9, MUTED)
        self.count_label.pack(side="right")
        self.status = self._label(lib, "", 9, MUTED)
        self.status.pack(anchor="w", padx=34, pady=(0, 6))

        wrap = tk.Frame(lib, bg=BG)
        wrap.pack(fill="both", expand=True, padx=34, pady=(0, 22))

        # Виртуализация: на canvas живут только карточки в зоне видимости (+1 ряд запаса).
        self.canvas = tk.Canvas(wrap, bg=BG, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(wrap, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self._on_yscroll)
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        self.store_view = tk.Frame(content, bg=BG)   # показывается по кнопке «Цены и скидки»
        self._build_store_view(self.store_view)

    # ------------------------------------------------------------------
    # Прокрутка и переключение вкладок
    # ------------------------------------------------------------------
    def _wheel_canvas(self):
        return self.canvas if self.view == "library" else self.store_scroll.canvas

    def _scroll_canvas_pixels(self, pixels):
        canvas = self._wheel_canvas()
        try:
            region = canvas.cget("scrollregion")
            if not region:
                return
            _x1, y1, _x2, y2 = map(float, canvas.tk.splitlist(region))
            total = max(1.0, y2 - y1)
            if total <= canvas.winfo_height():
                return
            first, _last = canvas.yview()
            canvas.yview_moveto(max(0.0, min(1.0, first + pixels / total)))
        except (tk.TclError, ValueError):
            pass

    def _on_mousewheel(self, event):
        if isinstance(event.widget, (tk.Listbox, tk.Text)):
            return
        for w in self.root.winfo_children():
            if isinstance(w, tk.Toplevel) and w.winfo_exists():
                return

        delta = getattr(event, "delta", 0)
        if delta:
            self._scroll_canvas_pixels(-float(delta) * 1.2)
        elif event.num == 4:
            self._scroll_canvas_pixels(-48)
        elif event.num == 5:
            self._scroll_canvas_pixels(48)
        return "break"

    def _highlight_nav(self, active):
        for key, btn in self.nav_buttons.items():
            btn.configure(fg=ACCENT if key == active else TEXT, bg="#202a37" if key == active else SIDEBAR)

    def _show_library(self):
        if self.view == "library":
            return
        self.view = "library"
        self.store_view.pack_forget()
        self.library_view.pack(fill="both", expand=True)

    def show_store(self, query=None):
        if self.view != "store":
            self.view = "store"
            self.library_view.pack_forget()
            self.store_view.pack(fill="both", expand=True)
        self._highlight_nav("store")
        if query is not None:
            self.store_query.set(query)
        self._render_store()

    def set_filter(self, value):
        self._show_library()
        self.filter = value
        labels = {"all": "Все игры", "installed": "Установленные",
                  "steam": "Steam", "epic": "Epic Games", "microsoft": "Microsoft / Xbox"}
        self.section_title.config(text=labels.get(value, "Игры"))
        self._highlight_nav(value)
        self.render_games()

    def _visible_games(self):
        query = self.search_var.get().strip().lower()
        result = []
        for name, rec in state.get("library", {}).items():
            if not isinstance(rec, dict) or (query and query not in name.lower()): continue
            installed_any = any(rec.get(f"{store}_installed") for store in ("steam", "epic", "microsoft")) or rec.get("is_installed")
            if self.filter == "installed" and not installed_any: continue
            if self.filter == "steam" and not rec.get("is_steam_owned"): continue
            if self.filter == "epic" and not rec.get("is_epic_owned"): continue
            if self.filter == "microsoft" and not rec.get("is_microsoft_owned"): continue
            result.append((name, rec))
        result.sort(key=lambda x: (not bool(x[1].get("is_installed")), x[0].lower()))
        return result

    # ------------------------------------------------------------------
    # Библиотека: виртуализированная сетка карточек
    # ------------------------------------------------------------------
    CARD_PADX = 6
    CARD_PADY = 7

    def _library_has_match(self, query):
        """True, если игра с таким названием есть в библиотеке (в любом магазине, без учёта фильтра)."""
        q = query.lower()
        qn = normalize_name(query)
        for name in state.get("library", {}):
            if q in name.lower() or (qn and qn in normalize_name(name)):
                return True
        return False

    def _on_yscroll(self, first, last):
        self.scrollbar.set(first, last)
        self._schedule_sync()

    def _schedule_sync(self):
        if self._sync_pending:
            return
        self._sync_pending = True
        try:
            self.root.after_idle(self._sync_cards)
        except tk.TclError:
            self._sync_pending = False

    def _on_canvas_configure(self, event):
        if event.width != self._last_canvas_w:
            self._schedule_relayout()
        else:
            self._schedule_sync()

    def _schedule_relayout(self):
        if self._layout_after_id:
            try: self.root.after_cancel(self._layout_after_id)
            except tk.TclError: pass
        self._layout_after_id = self.root.after(80, self._relayout)

    def _destroy_card(self, card, win_id):
        try: self.canvas.delete(win_id)
        except tk.TclError: pass
        try: card.destroy()
        except tk.TclError: pass

    def _clear_cards(self):
        for card, win_id in self._cards.values():
            self._destroy_card(card, win_id)
        self._cards = {}
        if self._empty_frame is not None:
            self._destroy_card(self._empty_frame, self._empty_win)
            self._empty_frame = None
            self._empty_win = None

    def render_games(self):
        """Пересчитывает список игр и перерисовывает видимую часть сетки."""
        if not hasattr(self, "canvas"): return
        self._games = self._visible_games()
        self.count_label.config(text=f"{len(self._games)} игр")
        if self._layout_after_id:
            try: self.root.after_cancel(self._layout_after_id)
            except tk.TclError: pass
            self._layout_after_id = None
        self._clear_cards()
        self.canvas.yview_moveto(0)
        if self.canvas.winfo_width() <= 1:
            return          # окно ещё не показано — отрисуем по первому <Configure>
        self._relayout()

    def _relayout(self):
        self._layout_after_id = None
        if not hasattr(self, "canvas"): return
        w = max(self.canvas.winfo_width(), 1)
        self._last_canvas_w = w
        self._clear_cards()
        if not self._games:
            self._slot_h = 0
            self._show_empty(w)
            return
        cols = max(1, min(4, w // 280))
        self._cols = cols
        self._slot_w = w / cols
        self._slot_h = self._measure_card_h() + 2 * self.CARD_PADY
        rows = math.ceil(len(self._games) / cols)
        self.canvas.configure(scrollregion=(0, 0, w, rows * self._slot_h))
        self._sync_cards()

    def _show_empty(self, width):
        query = self.search_var.get().strip()
        frame = tk.Frame(self.canvas, bg=PANEL, padx=24, pady=26)
        if len(query) >= 2 and not self._library_has_match(query):
            self._label(frame, f"«{query}» нет в вашей библиотеке", 15, TEXT, True, bg=PANEL).pack(anchor="w")
            self._label(frame, "Можно посмотреть цены на эту игру в Steam, Epic Games и Microsoft Store.",
                        9, MUTED, bg=PANEL).pack(anchor="w", pady=(7, 14))
            self._button(frame, f"Искать «{query}» в магазинах  →",
                         lambda q=query: self.show_store(q), primary=True).pack(anchor="w")
        elif query:
            self._label(frame, "В этом разделе ничего не найдено", 15, TEXT, True, bg=PANEL).pack(anchor="w")
            self._label(frame, "Попробуйте раздел «Все игры».", 9, MUTED, bg=PANEL).pack(anchor="w", pady=(7, 0))
        else:
            self._label(frame, "Здесь пока пусто", 15, TEXT, True, bg=PANEL).pack(anchor="w")
            self._label(frame, "Нажмите «Аккаунты и синхронизация», чтобы найти установленные игры.",
                        9, MUTED, bg=PANEL).pack(anchor="w", pady=(7, 0))
        self._empty_frame = frame
        self._empty_win = self.canvas.create_window(0, 0, window=frame, anchor="nw", width=width)
        self.canvas.configure(scrollregion=(0, 0, width, 1))

    def _measure_card_h(self):
        """Высота карточки одинакова у всех (заголовок — ровно 2 строки, обложка — фикс.),
        поэтому меряем один раз на пробной карточке."""
        if self._card_h:
            return self._card_h
        probe = self._build_card(self.canvas, "Probe", {}, wrap=200, probe=True)
        try:
            probe.update_idletasks()
            height = probe.winfo_reqheight()
        finally:
            probe.destroy()
        self._card_h = max(int(height), 120)
        return self._card_h

    def _sync_cards(self):
        """Создаёт карточки видимых рядов (+1 ряд сверху и снизу) и убирает остальные."""
        self._sync_pending = False
        if not self._games or not self._slot_h:
            return
        try:
            top = float(self.canvas.canvasy(0))
            height = max(self.canvas.winfo_height(), 1)
        except (tk.TclError, ValueError):
            return
        cols, n = self._cols, len(self._games)
        rows = math.ceil(n / cols)
        first_row = max(0, int(top // self._slot_h) - 1)
        last_row = min(rows - 1, int((top + height) // self._slot_h) + 1)
        wanted = set(range(first_row * cols, min(n, (last_row + 1) * cols)))

        for idx in [i for i in self._cards if i not in wanted]:
            card, win_id = self._cards.pop(idx)
            self._destroy_card(card, win_id)
        for idx in sorted(wanted):
            if idx not in self._cards:
                self._create_card(idx)

    def _create_card(self, idx):
        name, rec = self._games[idx]
        row, col = divmod(idx, self._cols)
        card_w = max(120, int(self._slot_w) - 2 * self.CARD_PADX)
        card = self._build_card(self.canvas, name, rec, wrap=max(100, card_w - 28))
        win_id = self.canvas.create_window(
            int(col * self._slot_w) + self.CARD_PADX, row * self._slot_h + self.CARD_PADY,
            window=card, anchor="nw", width=card_w, height=self._card_h)
        self._cards[idx] = (card, win_id)

    def _build_card(self, parent, name, rec, wrap=210, probe=False):
        try:
            from icons import ICON_SIZE
        except Exception:
            ICON_SIZE = (160, 75)

        card = tk.Frame(parent, bg=PANEL, highlightthickness=1, highlightbackground=BORDER, padx=12, pady=12)

        # Обложка в рамке фиксированной высоты: размер карточки не зависит от того,
        # успела ли загрузиться картинка.
        cover_box = tk.Frame(card, bg="#222a38", height=ICON_SIZE[1])
        cover_box.pack(fill="x", pady=(0, 11))
        cover_box.pack_propagate(False)
        cover = tk.Label(cover_box, bg="#222a38")
        cover.place(relx=0.5, rely=0.5, anchor="center")
        cover.game_title = name
        if not probe:
            try:
                from icons import load_game_icon
                photo = load_game_icon(
                    name, rec.get("path", ""), rec.get("appid"), label=cover,
                    root=self.root, is_epic=bool(rec.get("is_epic_owned")),
                    namespace=rec.get("namespace"), catalog_item_id=rec.get("catalog_item_id"), slug=rec.get("slug"),
                    icon_path=rec.get("icon_path")
                )
                if photo: cover.image = photo
            except Exception:
                log.exception("Не удалось загрузить обложку %s", name)

        shown = name if len(name) <= 52 else name[:51].rstrip() + "…"
        self._label(card, shown, 10, TEXT, True, bg=PANEL, wraplength=wrap, justify="left",
                    anchor="nw", height=2).pack(fill="x")
        badge_row = tk.Frame(card, bg=PANEL)
        badge_row.pack(fill="x", pady=(8, 11))
        badges = []
        if rec.get("is_steam_owned"): badges.append(("STEAM", BLUE))
        if rec.get("is_epic_owned"): badges.append(("EPIC", "#b4bac8"))
        if rec.get("is_microsoft_owned"): badges.append(("MICROSOFT", "#70a8ff"))
        store_keys = {"STEAM": "steam", "EPIC": "epic", "MICROSOFT": "microsoft"}
        for caption, color in badges:
            if self.filter == store_keys.get(caption):
                pill_bg = {"STEAM": "#25365a", "EPIC": "#26384d", "MICROSOFT": "#24394f"}[caption]
                color = "#ffffff" if caption == "EPIC" else color
                tk.Label(
                    badge_row, text=caption, bg=pill_bg, fg=color,
                    font=("Segoe UI", 9 if caption == "EPIC" else 7, "bold"), padx=9 if caption == "EPIC" else 6, pady=3,
                    relief="flat", bd=0
                ).pack(side="left", padx=(0, 8))
            else:
                self._label(badge_row, caption, 7, color, True, bg=PANEL).pack(side="left", padx=(0, 8))
        active_store = self.filter if self.filter in ("steam", "epic", "microsoft") else None
        is_installed_here = rec.get(f"{active_store}_installed") if active_store else (any(rec.get(f"{store}_installed") for store in ("steam", "epic", "microsoft")) or rec.get("is_installed"))
        self._label(badge_row, "УСТАНОВЛЕНА" if is_installed_here else "В БИБЛИОТЕКЕ", 7, ACCENT if is_installed_here else MUTED, True, bg=PANEL).pack(side="right")

        btn = self._button(card, "▶  Запустить" if is_installed_here else "Установить",
                           lambda r=rec, n=name: self.open_game(n, r),
                           primary=bool(is_installed_here))
        btn.pack(fill="x")

        if not probe:
            for w in (card, cover_box, cover, btn):
                w.bind("<Button-3>", lambda e, n=name, r=rec, l=cover: self._show_pcm(e, n, r, l))
        return card

    # ------------------------------------------------------------------
    # Вкладка «Магазин»: регион
    # ------------------------------------------------------------------
    def _price_country(self):
        return (state.get("app_config", {}).get("price_country") or "US").upper()

    def _build_store_view(self, parent):
        top = tk.Frame(parent, bg=BG)
        top.pack(fill="x", padx=34, pady=(26, 10))
        self._label(top, "ЦЕНЫ И СКИДКИ", 9, ACCENT, True).pack(anchor="w")
        title_row = tk.Frame(top, bg=BG)
        title_row.pack(fill="x", pady=(5, 10))
        self._label(title_row, "Магазин", 23, TEXT, True).pack(side="left")
        entry = tk.Entry(title_row, textvariable=self.store_query, width=31, bg=PANEL, fg=TEXT,
                         insertbackground=TEXT, relief="flat", font=("Segoe UI", 10), bd=2)
        entry.pack(side="right", ipady=4)
        self._bind_entry_clipboard(entry, self.root)
        self._label(top, "Найдите игру в Steam, Epic Games и Microsoft Store — цены от меньшей к большей. "
                         "Без запроса — скидки и бесплатные игры.", 9, MUTED).pack(anchor="w")

        row = tk.Frame(parent, bg=BG)
        row.pack(fill="x", padx=34, pady=(0, 12))
        self._label(row, "Регион:", 9, MUTED).pack(side="left", padx=(0, 8))
        self.region_var = tk.StringVar()
        self.region_combo = ttk.Combobox(row, textvariable=self.region_var, values=pc.region_choices(),
                                         state="readonly", width=24, font=("Segoe UI", 10))
        self.region_combo.pack(side="left")
        self.region_combo.bind("<<ComboboxSelected>>", self._on_region_selected)

        # Ручной ввод — показывается, когда выбран пункт «Другой регион…»
        self.region_manual_var = tk.StringVar()
        self.region_manual_label = self._label(row, "Код страны:", 9, MUTED)
        self.region_manual = tk.Entry(row, textvariable=self.region_manual_var, width=5, bg=PANEL, fg=TEXT,
                                      insertbackground=TEXT, relief="flat", font=("Segoe UI", 10), bd=2)
        self.region_apply = self._button(row, "Применить", self._apply_manual_region)
        self.region_manual.bind("<Return>", lambda e: self._apply_manual_region())
        self._bind_entry_clipboard(self.region_manual, self.root)

        self._button(row, "⟳  Обновить", self._refresh_store).pack(side="right")
        self._sync_region_widgets()

        self.store_scroll = ScrollArea(parent, BG)
        self.store_scroll.frame.pack(fill="both", expand=True, padx=34, pady=(0, 22))

    def _show_manual_region(self, show):
        for w in (self.region_manual_label, self.region_manual, self.region_apply):
            w.pack_forget()
        if show:
            self.region_manual_label.pack(side="left", padx=(14, 6))
            self.region_manual.pack(side="left", ipady=4)
            self.region_apply.pack(side="left", padx=(8, 0))

    def _sync_region_widgets(self):
        code = self._price_country()
        self.region_var.set(pc.region_label(code))
        if code in pc.REGION_NAMES:
            self._show_manual_region(False)
        else:
            self.region_manual_var.set(code)
            self._show_manual_region(True)

    def _on_region_selected(self, event=None):
        choice = self.region_var.get()
        if choice == pc.OTHER_REGION:
            self._show_manual_region(True)
            self.region_manual.focus_set()
            return
        self._show_manual_region(False)
        self._set_region(choice[:2])

    def _apply_manual_region(self):
        code = self.region_manual_var.get().strip().upper()
        if not pc.valid_region_code(code):
            messagebox.showwarning("Регион", "Введите двухбуквенный код страны (ISO 3166-1), "
                                             "например PL, DE или JP.")
            return
        self._set_region(code)
        self._sync_region_widgets()      # код есть в списке → переключит выпадающий список

    def _set_region(self, code):
        cfg = state.setdefault("app_config", {})
        if str(cfg.get("price_country", "")).upper() == code:
            return
        cfg["price_country"] = code
        save_config()
        self._render_store()

    def _refresh_store(self):
        country = self._price_country()
        self._home_cache.pop(country, None)
        self._price_cache.pop(self._current_store_key(), None)
        self._render_store()

    # ------------------------------------------------------------------
    # Вкладка «Магазин»: отрисовка
    # ------------------------------------------------------------------
    def _current_store_key(self):
        return (self.store_query.get().strip().lower(), self._price_country())

    def _on_store_query_change(self, *args):
        if getattr(self, "_store_after_id", None):
            try: self.root.after_cancel(self._store_after_id)
            except tk.TclError: pass
        self._store_after_id = self.root.after(600, self._render_store)

    def _render_store(self):
        if not hasattr(self, "store_scroll"): return
        if self._store_after_id:
            try: self.root.after_cancel(self._store_after_id)
            except tk.TclError: pass
            self._store_after_id = None
        area = self.store_scroll
        area.clear()
        country = self._price_country()
        query = self.store_query.get().strip()
        if len(query) >= 2:
            self._render_store_results(area.inner, query, country)
        else:
            self._render_store_home(area.inner, country)

    def _store_width(self):
        w = self.store_scroll.canvas.winfo_width()
        return w if w > 100 else max(600, self.root.winfo_width() - 300)

    def _section_title(self, parent, text, sub=""):
        row = tk.Frame(parent, bg=BG)
        row.pack(fill="x", pady=(16, 8))
        self._label(row, text, 9, ACCENT, True).pack(side="left")
        if sub:
            self._label(row, f"   {sub}", 9, MUTED).pack(side="left")

    def _note(self, parent, text, color=MUTED, pady=(4, 0)):
        self._label(parent, text, 9, color, wraplength=max(300, self._store_width() - 40),
                    justify="left").pack(anchor="w", pady=pady)

    def _open_offer(self, offer):
        from ui_actions_helper import open_price_offer
        try:
            if not open_price_offer(offer):
                self.root.after(0, lambda: messagebox.showinfo("GamePanel", "Не удалось открыть страницу игры."))
        except Exception:
            log.exception("Не удалось открыть предложение %s", offer.get("title"))

    def _open_button(self, parent, offer, text="Открыть", primary=False):
        return self._button(parent, text, lambda o=offer: threading.Thread(
            target=self._open_offer, args=(o,), daemon=True).start(), primary=primary)

    # ---- результаты поиска ----
    def _library_title_set(self):
        return {normalize_name(k.replace(" (Steam)", "").replace(" (Epic)", "").replace(" (Microsoft)", ""))
                for k in state.get("library", {})}

    def _render_store_results(self, parent, query, country):
        key = (query.lower(), country)
        entry = self._price_cache.get(key)
        if entry:
            result, ts = entry
            age = time.time() - ts
            all_failed = len(result["errors"]) >= 3
            if age > STORE_CACHE_TTL or (all_failed and age > FAILED_CACHE_TTL):
                entry = None
                self._price_cache.pop(key, None)

        head = tk.Frame(parent, bg=PANEL, padx=22, pady=18, highlightthickness=1, highlightbackground=BORDER)
        head.pack(fill="x", pady=(0, 8))
        self._label(head, f"Результаты по запросу «{query}»", 13, TEXT, True, bg=PANEL).pack(anchor="w")

        if entry is None:
            self._label(head, "Ищем цены в Steam, Epic Games и Microsoft Store…", 9, MUTED, bg=PANEL)\
                .pack(anchor="w", pady=(6, 0))
            self._fetch_prices(query, country)
            return

        result = entry[0]
        offers, unavailable, errors = result["offers"], result["unavailable"], result["errors"]
        currencies = sorted({o["currency"] for o in offers if o["price"]})
        region_note = f"регион {country}" + (f", {', '.join(currencies)}" if currencies else "")
        self._label(head, f"Цены от меньшей к большей  •  {region_note}", 9, MUTED, bg=PANEL)\
            .pack(anchor="w", pady=(4, 0))

        if len(currencies) > 1:
            self._note(parent, f"Магазины отдают цены в разных валютах ({', '.join(currencies)}): "
                               "сортировка по числу может не совпадать с реальной стоимостью.", WARN, pady=(0, 6))

        # Запрос полностью совпал с названием игры, недоступной в регионе — говорим об этом прямо.
        exact = pc.exact_unavailable(query, unavailable)
        if exact:
            stores = ", ".join(sorted({o["store_label"] for o in exact}))
            sold_elsewhere = any(pc.norm_title(o["title"]) == pc.norm_title(query) for o in offers)
            banner = tk.Frame(parent, bg=WARN_BG, padx=18, pady=14, highlightthickness=1, highlightbackground=WARN)
            banner.pack(fill="x", pady=(0, 8))
            self._label(banner, f"«{exact[0]['title']}» недоступна в регионе {country}", 11, WARN, True,
                        bg=WARN_BG).pack(anchor="w")
            hint = f"Нет в продаже: {stores}."
            hint += (" В других магазинах игра доступна — см. ниже." if sold_elsewhere else
                     " Выберите другой регион в списке выше, чтобы увидеть цены.")
            self._label(banner, hint, 9, "#d9c7a6", bg=WARN_BG, wraplength=max(300, self._store_width() - 60),
                        justify="left").pack(anchor="w", pady=(4, 0))

        if not offers:
            if not exact:
                self._note(parent, "Ничего не найдено. Проверьте название или попробуйте другой запрос.",
                           TEXT, pady=(10, 0))
        else:
            in_lib = self._library_title_set()
            first_priced = next((i for i, o in enumerate(offers) if o["price"] is not None), None)
            for i, offer in enumerate(offers):
                self._offer_row(parent, offer, best=(i == first_priced),
                                in_library=normalize_name(offer["title"]) in in_lib)

        if unavailable:
            self._note(parent, f"Скрыто игр, недоступных в регионе {country}: {len(unavailable)}.")
        if errors:
            names = {"steam": "Steam", "epic": "Epic", "microsoft": "Microsoft"}
            failed = ", ".join(names.get(k, k) for k in errors)
            self._note(parent, f"Не удалось получить данные: {failed}. Подробности в game_panel.log.")

    def _offer_row(self, parent, offer, best=False, in_library=False):
        store_color = {"steam": BLUE, "epic": "#d5dae6", "microsoft": "#70a8ff"}
        row = tk.Frame(parent, bg=PANEL, padx=18, pady=12, highlightthickness=1,
                       highlightbackground=ACCENT_DARK if best else BORDER)
        row.pack(fill="x", pady=4)

        self._label(row, offer["store_label"].upper(), 8, store_color.get(offer["store"], MUTED), True,
                    bg=PANEL, width=11, anchor="w").pack(side="left")

        # Сначала фиксированные элементы справа, потом растягиваемый заголовок —
        # иначе в узком окне кнопка и цена уезжают за край.
        self._open_button(row, offer).pack(side="right")

        price_box = tk.Frame(row, bg=PANEL)
        price_box.pack(side="right", padx=(0, 16))
        price_color = ACCENT if offer["price"] == 0 else (TEXT if offer["price"] is not None else MUTED)
        self._label(price_box, offer["price_text"], 12, price_color, True, bg=PANEL).pack(anchor="e")
        if offer["discount"]:
            self._label(price_box, f"{offer['original_text']}  -{offer['discount']}%", 8, MUTED, bg=PANEL)\
                .pack(anchor="e")

        title_box = tk.Frame(row, bg=PANEL)
        title_box.pack(side="left", fill="x", expand=True, padx=(4, 12))
        self._label(title_box, offer["title"], 10, TEXT, True, bg=PANEL, anchor="w", justify="left",
                    wraplength=420).pack(anchor="w")
        if best:
            self._label(title_box, "САМАЯ НИЗКАЯ ЦЕНА", 7, ACCENT, True, bg=PANEL).pack(anchor="w", pady=(2, 0))
        if in_library:
            self._label(title_box, "УЖЕ В ВАШЕЙ БИБЛИОТЕКЕ", 7, MUTED, True, bg=PANEL).pack(anchor="w", pady=(2, 0))

    def _fetch_prices(self, query, country):
        key = (query.lower(), country)
        if key in self._price_inflight:
            return
        self._price_inflight.add(key)

        def worker():
            try:
                result = pc.search_all_prices(query, country)
            except Exception as exc:
                log.exception("Поиск цен провален")
                msg = str(exc) or exc.__class__.__name__
                result = {"offers": [], "unavailable": [],
                          "errors": {"steam": msg, "epic": msg, "microsoft": msg}}
            self.root.after(0, lambda: self._prices_done(key, result))
        threading.Thread(target=worker, daemon=True).start()

    def _prices_done(self, key, result):
        self._price_inflight.discard(key)
        self._price_cache[key] = (result, time.time())
        # Пока шёл запрос, пользователь мог сменить запрос/регион/вкладку — тогда просто кэшируем.
        if self.view == "store" and self._current_store_key() == key:
            self._render_store()

    # ---- главная: бесплатные игры Epic и скидки ----
    def _render_store_home(self, parent, country):
        entry = self._home_cache.get(country)
        if entry is None:
            box = tk.Frame(parent, bg=PANEL, padx=22, pady=18, highlightthickness=1, highlightbackground=BORDER)
            box.pack(fill="x", pady=(8, 0))
            self._label(box, "Загружаем скидки и бесплатные игры…", 11, TEXT, True, bg=PANEL).pack(anchor="w")
            self._label(box, f"Регион: {country}", 9, MUTED, bg=PANEL).pack(anchor="w", pady=(4, 0))
            self._fetch_home(country)
            return
        ts, data = entry
        age = time.time() - ts
        if age > STORE_CACHE_TTL or (len(data["errors"]) >= 4 and age > FAILED_CACHE_TTL):
            self._fetch_home(country)        # тихое обновление, пока показываем прежние данные
        self._draw_home(parent, country, data)

    def _fetch_home(self, country):
        if country in self._home_inflight:
            return
        self._home_inflight.add(country)

        def worker():
            try:
                data = store_deals.fetch_home(country)
            except Exception as exc:
                log.exception("Главная магазина провалена")
                msg = str(exc) or exc.__class__.__name__
                data = {"free": [], "deals": {"steam": [], "epic": [], "microsoft": []},
                        "errors": {k: msg for k in ("free", "steam", "epic", "microsoft")}}
            self.root.after(0, lambda: self._home_done(country, data))
        threading.Thread(target=worker, daemon=True).start()

    def _home_done(self, country, data):
        self._home_inflight.discard(country)
        self._home_cache[country] = (time.time(), data)
        if self.view == "store" and country == self._price_country() and len(self.store_query.get().strip()) < 2:
            self._render_store()

    def _draw_home(self, parent, country, data):
        errors = data.get("errors", {})

        # Отдельная строка: бесплатные игры Epic
        self._section_title(parent, "БЕСПЛАТНО В EPIC GAMES STORE", "забирайте, пока раздача идёт")
        free_row = tk.Frame(parent, bg=BG)
        free_row.pack(fill="x")
        if data.get("free"):
            for item in data["free"]:
                self._free_card(free_row, item)
        elif "free" in errors:
            self._note(free_row, f"Не удалось загрузить раздачи: {errors['free'][:140]}")
        else:
            self._note(free_row, "Сейчас бесплатных раздач нет.")

        # Скидки по магазинам выбранного региона
        cols = max(1, min(3, self._store_width() // 330))
        for store, caption in (("steam", "STEAM"), ("epic", "EPIC GAMES"), ("microsoft", "MICROSOFT STORE")):
            self._section_title(parent, f"СКИДКИ В {caption}", f"регион {country}")
            deals = data.get("deals", {}).get(store) or []
            if deals:
                grid = tk.Frame(parent, bg=BG)
                grid.pack(fill="x")
                for c in range(cols):
                    grid.grid_columnconfigure(c, weight=1, uniform=f"deals_{store}")
                for i, offer in enumerate(deals):
                    self._deal_card(grid, offer).grid(row=i // cols, column=i % cols,
                                                      sticky="nsew", padx=5, pady=5)
            elif store in errors:
                self._note(parent, f"Не удалось загрузить скидки: {errors[store][:140]}")
            else:
                self._note(parent, "Скидок не найдено.")
        tk.Frame(parent, bg=BG, height=12).pack()

    def _free_card(self, parent, item):
        now = item["status"] == "now"
        card = tk.Frame(parent, bg=PANEL, padx=16, pady=14, highlightthickness=1,
                        highlightbackground=ACCENT_DARK if now else BORDER)
        card.pack(side="left", padx=(0, 12), anchor="n")
        self._label(card, "БЕСПЛАТНО СЕЙЧАС" if now else "СКОРО БЕСПЛАТНО", 7, ACCENT if now else BLUE, True,
                    bg=PANEL).pack(anchor="w")
        self._label(card, item["title"], 11, TEXT, True, bg=PANEL, wraplength=230, justify="left",
                    anchor="w").pack(anchor="w", pady=(6, 4))
        if now and item.get("end_text"):
            when = f"до {item['end_text']}"
        elif not now and item.get("start_text"):
            when = f"с {item['start_text']}"
        else:
            when = ""
        if when:
            self._label(card, when, 9, MUTED, bg=PANEL).pack(anchor="w")
        if item.get("original_text"):
            self._label(card, f"Обычная цена: {item['original_text']}", 8, MUTED, bg=PANEL).pack(anchor="w")
        self._open_button(card, item, "Забрать" if now else "Открыть", primary=now).pack(fill="x", pady=(10, 0))

    def _deal_card(self, parent, offer):
        card = tk.Frame(parent, bg=PANEL, padx=14, pady=12, highlightthickness=1, highlightbackground=BORDER)
        self._label(card, offer["title"], 10, TEXT, True, bg=PANEL, wraplength=250, justify="left",
                    anchor="w").pack(anchor="w")
        price_row = tk.Frame(card, bg=PANEL)
        price_row.pack(fill="x", pady=(8, 8))
        tk.Label(price_row, text=f"-{offer['discount']}%", bg=ACCENT_DARK, fg="#07130f",
                 font=("Segoe UI", 9, "bold"), padx=6, pady=2).pack(side="left")
        box = tk.Frame(price_row, bg=PANEL)
        box.pack(side="left", padx=10)
        self._label(box, offer["price_text"], 12, ACCENT, True, bg=PANEL).pack(anchor="w")
        if offer.get("original_text"):
            self._label(box, offer["original_text"], 8, MUTED, bg=PANEL).pack(anchor="w")
        self._open_button(card, offer).pack(fill="x")
        return card

    def _show_pcm(self, event, name, rec, cover_label):
        from ui_actions_helper import open_store_page
        menu = tk.Menu(self.root, tearoff=0)
        exe = rec.get("path") if rec.get("is_installed") else None
        
        if exe and os.path.exists(exe):
            from scanner import open_game_location
            menu.add_command(label="Открыть папку с игрой", command=lambda: open_game_location(exe))
            menu.add_separator()

        if rec.get("is_steam_owned") or rec.get("is_epic_owned") or rec.get("is_microsoft_owned"):
            menu.add_command(label="Открыть в магазине", command=lambda: threading.Thread(target=open_store_page, args=(rec,), daemon=True).start())

        menu.add_separator()
        
        if rec.get("is_epic_owned"):
            menu.add_command(label="Обновить обложку из Epic", command=lambda: self._update_cover(name, rec, cover_label, "Epic"))
        if rec.get("is_steam_owned") or not (rec.get("is_steam_owned") or rec.get("is_epic_owned") or rec.get("is_microsoft_owned")):
            menu.add_command(label="Обновить обложку из Steam", command=lambda: self._update_cover(name, rec, cover_label, "Steam"))
            
        menu.add_command(label="Выбрать свою обложку", command=lambda: self._pick_local_cover(name, cover_label))
        
        if not rec.get("is_installed") and (rec.get("is_steam_owned") or rec.get("is_epic_owned") or rec.get("is_microsoft_owned")):
            menu.add_separator()
            menu.add_command(label="Установить", command=lambda: self.open_game(name, rec))

        menu.add_separator()
        menu.add_command(label="Удалить из библиотеки", command=lambda: self._delete_game(name))

        try: menu.tk_popup(event.x_root, event.y_root)
        except tk.TclError: pass

    def _update_cover(self, name, rec, label, source):
        from icons import fetch_steam_cover, fetch_epic_cover
        def worker():
            if source == "Epic":
                img = fetch_epic_cover(name, rec.get("namespace"), rec.get("catalog_item_id"))
            else:
                img = fetch_steam_cover(name, rec.get("appid"))
            if not img: return
            def apply():
                if not label.winfo_exists(): return
                try:
                    from PIL import ImageTk
                    photo = ImageTk.PhotoImage(img)
                    label.config(image=photo)
                    label.image = photo
                except Exception: pass
            self.root.after(0, apply)
        threading.Thread(target=worker, daemon=True).start()

    def _pick_local_cover(self, name, label):
        from config import CACHE_DIR, safe_filename
        from icons import ICON_SIZE, _pad_cover
        from PIL import Image, ImageTk
        path = filedialog.askopenfilename(title="Обложка", filetypes=[("Изображения", "*.png *.jpg *.jpeg *.ico *.bmp")])
        if not path: return
        try:
            img = Image.open(path)
            img = _pad_cover(img, ICON_SIZE)
            safe = safe_filename(name)
            os.makedirs(CACHE_DIR, exist_ok=True)
            img.save(os.path.join(CACHE_DIR, f"{safe}_v11.png"))
            photo = ImageTk.PhotoImage(img)
            label.config(image=photo)
            label.image = photo
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    def _delete_game(self, name):
        if messagebox.askyesno("Удаление", f"Удалить игру «{name}» из библиотеки?"):
            delete_from_library(name)
            self.render_games()

    def open_game(self, name, rec):
        try:
            preferred = self.filter if self.filter in ("steam", "epic", "microsoft") else ""
            installed_here = rec.get(f"{preferred}_installed") if preferred else (rec.get("is_installed") or any(rec.get(f"{store}_installed") for store in ("steam", "epic", "microsoft")))
            if installed_here:
                preferred = self.filter if self.filter in ("steam", "epic", "microsoft") else ""
                order = ([preferred] if preferred else []) + [
                    store for store in ("steam", "epic", "microsoft") if store != preferred
                ]
                launched = False
                for store in order:
                    if store == "microsoft" and rec.get("is_microsoft_owned"):
                        from microsoft_store import launch_game
                        ok, err = launch_game(rec)
                        if not ok:
                            messagebox.showerror("Microsoft Store", err or "Не удалось запустить игру")
                        launched = bool(ok)
                        break
                    if store == "epic" and rec.get("is_epic_owned") and rec.get("launch_url"):
                        webbrowser.open(rec["launch_url"])
                        launched = True
                        break
                    if store == "steam" and rec.get("is_steam_owned") and str(rec.get("appid", "")).isdigit():
                        webbrowser.open(f"steam://run/{rec['appid']}")
                        launched = True
                        break
                if not launched:
                    if rec.get("path") and os.path.isfile(rec["path"]):
                        os.startfile(rec["path"])
                    else:
                        messagebox.showinfo("GamePanel", "Для этой игры не найден способ запуска.")
            elif preferred == "microsoft" and rec.get("is_microsoft_owned"):
                from microsoft_store import install_by_name
                ok, result = install_by_name(name)
                if not ok: messagebox.showwarning("Microsoft Store", result)
                else: messagebox.showinfo("Microsoft Store", "Команда установки передана winget.")
            elif preferred == "epic" and rec.get("is_epic_owned"):
                from ui_actions_helper import open_store_page
                if not open_store_page(rec):
                    messagebox.showinfo("GamePanel", "Не удалось открыть страницу игры в Epic.")
            elif preferred == "steam" and rec.get("is_steam_owned") and str(rec.get("appid", "")).isdigit():
                webbrowser.open(f"steam://install/{rec['appid']}")
            elif not preferred and rec.get("is_microsoft_owned"):
                from microsoft_store import install_by_name
                ok, result = install_by_name(name)
                if not ok: messagebox.showwarning("Microsoft Store", result)
                else: messagebox.showinfo("Microsoft Store", "Команда установки передана winget.")
            elif not preferred and rec.get("install_url"):
                webbrowser.open(rec["install_url"])
            elif not preferred and rec.get("is_steam_owned") and str(rec.get("appid", "")).isdigit():
                webbrowser.open(f"steam://install/{rec['appid']}")
            else:
                messagebox.showinfo("GamePanel", "Ссылка установки для этой игры не найдена.")
        except Exception as exc:
            log.exception("Game launch failed")
            messagebox.showerror("Не удалось запустить", str(exc))

    def scan(self, source="all"):
        if self._scanning: return
        self._scanning = True
        labels = {"all": "всех библиотек", "steam": "Steam", "epic": "Epic", "microsoft": "Microsoft Store / Xbox"}
        self.status.config(text=f"Сканирование: {labels.get(source, source)}…")
        def worker():
            try:
                result = (_scan_sources(source), None)
            except Exception as exc:
                log.exception("Library scan failed")
                result = (0, str(exc))
            self.root.after(0, lambda: self._scan_done(*result))
        threading.Thread(target=worker, daemon=True).start()

    def _scan_done(self, count, error):
        self._scanning = False
        if error:
            self.status.config(text="Сканирование завершилось с ошибкой")
            messagebox.showerror("Сканирование", error)
        else:
            self.status.config(text=f"Готово · записей в библиотеке: {count}")
            self.render_games()

    def open_microsoft_library(self):
        if os.name != "nt":
            messagebox.showinfo("Microsoft Store", "Доступно только в Windows 11.")
            return
        try:
            os.startfile("ms-windows-store://mylibrary")
        except OSError as exc:
            messagebox.showerror("Microsoft Store", f"Не удалось открыть библиотеку: {exc}")

    def open_settings(self):
        dlg = tk.Toplevel(self.root)
        dlg.title("Аккаунты и синхронизация")
        dlg.configure(bg=BG)
        dlg.geometry("600x650")
        dlg.resizable(False, False)
        dlg.transient(self.root)
        dlg.grab_set()

        body = tk.Frame(dlg, bg=BG, padx=26, pady=24)
        body.pack(fill="both", expand=True)

        self._label(body, "Аккаунты и синхронизация", 19, TEXT, True, bg=BG).pack(anchor="w")
        self._label(body, "Подключите магазины и обновите библиотеку", 9, MUTED, bg=BG).pack(anchor="w", pady=(4, 16))

        cfg = state.setdefault("app_config", {})

        # --- Steam ---
        self._label(body, "STEAM", 9, ACCENT, True, bg=BG).pack(anchor="w", pady=(8, 4))

        instr_frame = tk.Frame(body, bg=BG)
        instr_frame.pack(fill="x", pady=(0, 8))
        
        link_btn = tk.Button(
            instr_frame, text="Получить Steam Web API Key", 
            bg=BG, fg=BLUE, activebackground=BG, activeforeground=ACCENT, 
            relief="flat", bd=0, cursor="hand2", font=("Segoe UI", 9, "underline"), 
            command=lambda: webbrowser.open("https://steamcommunity.com/dev/apikey")
        )
        link_btn.pack(side="left")
        
        self._label(instr_frame, " (введите любой домен и скопируйте ключ)", 9, MUTED, bg=BG).pack(side="left")

        self._label(body, "SteamID64 или ссылка на профиль", 9, TEXT, True, bg=BG).pack(anchor="w", pady=(4, 2))
        steam_id_var = tk.StringVar(value=cfg.get("steam_id", ""))
        id_entry = tk.Entry(body, textvariable=steam_id_var, bg=PANEL, fg=TEXT, insertbackground=TEXT, relief="flat", font=("Segoe UI", 10), bd=0)
        id_entry.pack(fill="x", ipady=8, pady=(0, 8))
        self._bind_entry_clipboard(id_entry, dlg)

        self._label(body, "Steam Web API Key", 9, TEXT, True, bg=BG).pack(anchor="w", pady=(4, 2))
        api_key_var = tk.StringVar(value=cfg.get("steam_api_key", ""))
        key_entry = tk.Entry(body, textvariable=api_key_var, show="•", bg=PANEL, fg=TEXT, insertbackground=TEXT, relief="flat", font=("Segoe UI", 10), bd=0)
        key_entry.pack(fill="x", ipady=8, pady=(0, 8))
        self._bind_entry_clipboard(key_entry, dlg)

        # --- Epic ---
        self._label(body, "EPIC GAMES", 9, ACCENT, True, bg=BG).pack(anchor="w", pady=(16, 4))
        
        epic_frame = tk.Frame(body, bg=BG)
        epic_frame.pack(fill="x", pady=(0, 8))
        
        from epic_auth_embedded import is_logged_in, logout, run_legendary_auth
        ok, name = is_logged_in()
        
        epic_status_lbl = self._label(epic_frame, f"Статус: {name}" if ok else "Статус: не привязан", 9, ACCENT if ok else MUTED, bg=BG)
        epic_status_lbl.pack(side="left")
        
        def refresh_epic_status():
            ok, name = is_logged_in()
            epic_status_lbl.config(text=f"Статус: {name}" if ok else "Статус: не привязан", fg=ACCENT if ok else MUTED)
            epic_btn.config(text="Выйти" if ok else "Войти")
            
        def epic_action():
            ok, name = is_logged_in()
            if ok:
                if messagebox.askyesno("Epic", f"Выйти из аккаунта {name}?", parent=dlg):
                    logout()
                    refresh_epic_status()
            else:
                run_legendary_auth(dlg, on_success=lambda: (refresh_epic_status(), self.scan("epic")))
                
        epic_btn = self._button(epic_frame, "Выйти" if ok else "Войти", epic_action)
        epic_btn.pack(side="right")

        # --- Scanning ---
        self._label(body, "СКАНИРОВАНИЕ БИБЛИОТЕК", 9, ACCENT, True, bg=BG).pack(anchor="w", pady=(16, 4))
        
        scan_frame = tk.Frame(body, bg=BG)
        scan_frame.pack(fill="x", pady=(0, 20))
        
        def scan_and_close(source):
            dlg.destroy()
            self.scan(source)
            
        self._button(scan_frame, "Все", lambda: scan_and_close("all"), primary=True).pack(side="left", padx=(0, 8))
        self._button(scan_frame, "Steam", lambda: scan_and_close("steam")).pack(side="left", padx=(0, 8))
        self._button(scan_frame, "Epic", lambda: scan_and_close("epic")).pack(side="left", padx=(0, 8))
        self._button(scan_frame, "Microsoft", lambda: scan_and_close("microsoft")).pack(side="left")

        # --- Save ---
        btn_row = tk.Frame(body, bg=BG)
        btn_row.pack(fill="x", pady=(10, 0))
        
        def save():
            cfg["steam_id"] = steam_id_var.get().strip()
            cfg["steam_api_key"] = api_key_var.get().strip()
            save_config()
            dlg.destroy()
            messagebox.showinfo("Настройки", "Настройки сохранены.")
            
        self._button(btn_row, "Сохранить", save, primary=True).pack(side="right")


def build_window():
    root = tk.Tk()
    GamePanelApp(root)
    root.mainloop()