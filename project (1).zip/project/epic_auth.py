# language: Python 3.10+, file: epic_auth.py
# Резервная авторизация Epic через Legendary CLI (если OAuth не сработал).

import os
import subprocess
import shutil

from logger import get_logger

log = get_logger()


def login_via_subprocess_fallback():
    """Открывает окно cmd с legendary auth. Только для тех, у кого Legendary
    уже стоит в системе. Для остальных используется OAuth Device Flow."""
    exe = shutil.which("legendary")
    if not exe:
        for p in [
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs",
                         "Python", "Python311", "Scripts", "legendary.exe"),
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs",
                         "Python", "Python312", "Scripts", "legendary.exe"),
            os.path.join(os.environ.get("APPDATA", ""), "Python", "Scripts",
                         "legendary.exe"),
        ]:
            if os.path.isfile(p):
                exe = p
                break
    if not exe:
        return False, ("Legendary не установлен в системе.\n\n"
                       "Используй основной способ — «Войти в Epic».")
    try:
        subprocess.Popen(f'start "" cmd /k "{exe}" auth', shell=True)
        return True, "Открыто окно cmd для legendary auth."
    except Exception as e:
        return False, f"Не удалось запустить: {e}"