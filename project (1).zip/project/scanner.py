# language: Python 3.10+, file: scanner.py
# Поиск exe-файлов игр на локальных дисках + чтение Steam-манифестов.

import os
import re
import subprocess

from logger import get_logger

log = get_logger()

SKIP_DIRS = {
    "redist", "vcredist", "dxsetup", "_commonredist", "engine",
    "thirdparty", "editor", "crashreporter", "eac", "easyanticheat",
    "battleye", "prereqs", "tools", "__installer", "support", "docs",
}
BLACKLIST = [
    "unins", "setup", "update", "crash", "vcredist", "dxsetup",
    "redist", "install", "reporter", "subprocess", "cef", "browser",
    "overlay", "cleanup", "tools", "server", "config", "benchmark",
    "unitycrashhandler", "unreal", "prereq", "dotnet", "physx",
    "anticheat", "eac", "easyanticheat", "battleye", "editor",
    "srcds", "godot",
]
MIN_EXE_BYTES = 300 * 1024


def get_all_drives():
    out = []
    for c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        d = f"{c}:\\"
        try:
            if os.path.exists(d):
                out.append(d)
        except OSError:
            continue
    return out


def _is_safe_dir(path):
    try:
        return os.path.isdir(path) and os.access(path, os.R_OK)
    except OSError:
        return False


def find_best_exe(game_dir):
    if not game_dir or not _is_safe_dir(game_dir):
        return None

    folder = os.path.basename(os.path.normpath(game_dir))
    if folder.lower() in {"common", "downloading", "temp", "cache", "staging"}:
        return None

    candidates = []
    try:
        walker = os.walk(game_dir, onerror=lambda e: log.warning(
            f"os.walk: {e}"))
        for root_dir, dirs, files in walker:
            dirs[:] = [d for d in dirs if d.lower() not in SKIP_DIRS]
            for f in files:
                if not f.lower().endswith(".exe"):
                    continue
                full = os.path.join(root_dir, f)
                if any(b in f.lower() for b in BLACKLIST):
                    continue
                try:
                    size = os.path.getsize(full)
                except OSError as e:
                    log.debug(f"getsize '{full}': {e}")
                    continue
                except Exception as e:
                    log.warning(f"getsize неожиданно '{full}': {e}")
                    continue
                if size < MIN_EXE_BYTES:
                    continue

                score = 100
                ce = os.path.splitext(f)[0].lower()\
                    .replace(" ", "").replace("_", "").replace("-", "")
                cf = folder.lower()\
                    .replace(" ", "").replace("_", "").replace("-", "")
                if ce == cf:
                    score += 1000
                elif cf in ce or ce in cf:
                    score += 500
                try:
                    depth = len(os.path.relpath(full, game_dir).split(os.sep))
                except ValueError:
                    depth = 1
                score -= max(0, (depth - 1) * 20)
                score += min(size // (1024 * 1024), 200)
                candidates.append((score, full))
    except Exception as e:
        log.error(f"find_best_exe walk '{game_dir}': {e}")
        return None

    if not candidates:
        return None
    candidates.sort(key=lambda x: x[0], reverse=True)
    return candidates[0][1]


def get_store_paths(drives=None):
    drives = drives or get_all_drives()
    paths = []
    for d in drives:
        d = d.rstrip("\\")
        for p in [
            fr"{d}\Program Files (x86)\Steam\steamapps\common",
            fr"{d}\SteamLibrary\steamapps\common",
            fr"{d}\Program Files\Epic Games",
            fr"{d}\EpicGames",
            fr"{d}\XboxGames",
            fr"{d}\Program Files (x86)\GOG Galaxy\Games",
            fr"{d}\GOG Games",
            fr"{d}\Games",
        ]:
            try:
                if os.path.isdir(p) and os.access(p, os.R_OK):
                    paths.append(p)
            except OSError:
                continue
    return list(set(paths))


# --- Steam манифесты ---

_STEAM_LIBRARY_PATHS = [
    r"C:\Program Files (x86)\Steam",
    r"C:\Program Files\Steam",
    r"D:\Steam",
    r"D:\SteamLibrary",
    r"E:\Steam",
    r"E:\SteamLibrary",
    r"C:\SteamLibrary",
]

_ACF_PATTERN = re.compile(
    r'"appid"\s*"(?P<appid>\d+)".*?"installdir"\s*"(?P<dir>[^"]+)"',
    re.DOTALL | re.IGNORECASE,
)


def _libraryfolders_from_steam(steam_root):
    """Читает libraryfolders.vdf — все Steam-библиотеки."""
    out = []
    lf = os.path.join(steam_root, "steamapps", "libraryfolders.vdf")
    if not os.path.isfile(lf):
        return out
    try:
        with open(lf, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
        # Регуляркой достаём "path" "..."
        for m in re.finditer(r'"path"\s*"([^"]+)"', text):
            p = m.group(1).replace("\\\\", "\\")
            if p and os.path.isdir(p):
                out.append(p)
    except Exception as e:
        log.warning(f"libraryfolders.vdf: {e}")
    return out


def read_steam_manifests():
    """Возвращает {appid_str: installdir_abs_path}. Из .acf манифестов."""
    result = {}
    roots = set(_STEAM_LIBRARY_PATHS)

    # Найдём библиотеки через libraryfolders.vdf у каждого известного корня.
    for root in list(roots):
        if os.path.isdir(root):
            for lib in _libraryfolders_from_steam(root):
                roots.add(lib)

    # Дополнительно: сканируем известные папки по всем дискам.
    for d in get_all_drives():
        for sub in ["SteamLibrary", "Steam", "Games\\Steam"]:
            p = os.path.join(d, sub)
            if os.path.isdir(p):
                roots.add(p)

    for root in roots:
        sa = os.path.join(root, "steamapps")
        if not os.path.isdir(sa):
            continue
        try:
            for f in os.listdir(sa):
                if not f.lower().startswith("appmanifest_") or \
                        not f.lower().endswith(".acf"):
                    continue
                full = os.path.join(sa, f)
                try:
                    with open(full, "r", encoding="utf-8", errors="ignore") as fh:
                        text = fh.read()
                except OSError:
                    continue
                m = _ACF_PATTERN.search(text)
                if not m:
                    continue
                appid = m.group("appid").strip()
                installdir = m.group("dir").strip()
                install_path = os.path.normpath(os.path.join(sa, "common", installdir))
                if os.path.isdir(install_path):
                    result[appid] = install_path
        except OSError as e:
            log.warning(f"steamapps '{sa}': {e}")
            continue
    log.info(f"Steam-манифестов прочитано: {len(result)}")
    return result


def open_game_location(exe_path):
    if not exe_path or not os.path.exists(exe_path):
        log.info(f"Папка не открыта, exe отсутствует: {exe_path}")
        return False
    try:
        subprocess.Popen(f'explorer /select,"{os.path.normpath(exe_path)}"')
        return True
    except Exception as e:
        log.error(f"open_game_location '{exe_path}': {e}")
        return False