# language: Python 3.10+, file: ui/__init__.py
from ui.main_window import build_window

__all__ = ["build_window"]