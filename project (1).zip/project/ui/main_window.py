# language: Python 3.10+, file: ui/main_window.py
# Сборка главного окна.

import tkinter as tk
from config import THEMES, state, cleanup_cache
from ui import state as ui_state
from ui.theme import register_widget, apply_theme
from ui.sidebar import build_sidebar
from ui.filters import build_search_and_filters
from ui.library_view import build_library_view, refresh_library
from ui.scanner_view import build_scanner_view
from logger import get_logger

log = get_logger()


def _on_mousewheel(event):
    try:
        if ui_state.library_frame.winfo_ismapped():
            ui_state.lib_canvas.yview_scroll(
                int(-1 * (event.delta / 120)), "units")
        elif ui_state.scan_frame.winfo_ismapped():
            ui_state.listbox.yview_scroll(
                int(-1 * (event.delta / 120)), "units")
    except tk.TclError:
        pass


def build_window():
    try:
        cleanup_cache()
    except Exception:
        pass

    ui_state.root = tk.Tk()
    ui_state.root.title("Game Panel")
    ui_state.root.geometry("1060x800")
    ui_state.root.option_add("*Font", ("Segoe UI", 10))
    ui_state.root.bind_all("<MouseWheel>", _on_mousewheel)

    build_sidebar(ui_state.root)

    main_area = register_widget(tk.Frame(ui_state.root), "bg")
    main_area.pack(side="right", fill="both", expand=True)

    ui_state.title_label = register_widget(
        tk.Label(main_area, text="Моя Библиотека",
                 font=("Segoe UI", 18, "bold")), "text")
    ui_state.title_label.pack(anchor="w", padx=20, pady=(20, 10))

    build_search_and_filters(main_area)

    build_library_view(main_area)
    build_scanner_view(main_area)

    apply_theme()
    refresh_library()
    log.info("UI запущен.")
    ui_state.root.mainloop()