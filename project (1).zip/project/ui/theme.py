# language: Python 3.10+, file: ui/theme.py
# Применение тем и регистрация виджетов для перекрашивания.

import tkinter as tk
from config import THEMES, state
from ui import state as ui_state
from logger import get_logger

log = get_logger()


def register_widget(widget, w_type):
    state["widgets_to_theme"].append((widget, w_type))
    return widget


def apply_theme():
    c = THEMES.get(state.get("theme"), THEMES["dark"])
    try:
        ui_state.root.configure(bg=c["bg"])
    except tk.TclError:
        pass

    for w, t in list(state["widgets_to_theme"]):
        try:
            if not w.winfo_exists():
                continue
            if t == "bg":
                w.configure(bg=c["bg"])
            elif t == "sidebar":
                w.configure(bg=c["sidebar"])
            elif t == "card":
                w.configure(bg=c["card"])
            elif t == "text":
                w.configure(bg=c["bg"], fg=c["text"])
            elif t == "text_muted":
                w.configure(bg=c["bg"], fg=c["text_muted"])
            elif t == "sidebar_title":
                w.configure(bg=c["sidebar"], fg=c["accent"])
            elif t == "card_text":
                w.configure(bg=c["card"], fg=c["text"])
            elif t == "btn":
                w.configure(bg=c["btn"], fg=c["text"],
                            activebackground=c["btn_hover"],
                            activeforeground=c["text"])
            elif t == "btn_accent":
                w.configure(bg=c["accent"], fg="#ffffff",
                            activebackground="#047857",
                            activeforeground="#ffffff")
            elif t == "listbox":
                w.configure(bg=c["card"], fg=c["text"],
                            highlightbackground=c["btn"],
                            selectbackground=c["accent"])
        except tk.TclError:
            pass

    try:
        from ui.filters import update_filter_buttons
        update_filter_buttons()
    except Exception as e:
        log.debug(f"update_filter_buttons: {e}")


def toggle_theme():
    try:
        state["theme"] = "light" if state["theme"] == "dark" else "dark"
        ui_state.theme_btn.config(
            text="Тёмная тема" if state["theme"] == "light" else "Светлая тема")
        apply_theme()

        from ui.sidebar import update_steam_status, update_epic_status
        update_steam_status()
        update_epic_status()
    except Exception as e:
        log.error(f"toggle_theme: {e}")