# language: Python 3.10+, file: ui/actions.py
# Логика действий: sync, scan, run, merge, launch.

import os
import json
import time
import threading
import subprocess
import urllib.request
import urllib.error
import urllib.parse
import webbrowser
import tkinter as tk
from tkinter import messagebox, filedialog

from config import (state, save_library, save_config, normalize_name,
                    DEFAULT_EPIC_INSTALL_PATH)
from steam_api import fetch_steam_games
from epic_games import (fetch_epic_games, ensure_writable_dir,
                        build_epic_install_url, build_epic_launch_url,
                        is_non_game)
from scanner import (find_best_exe, get_all_drives, get_store_paths,
                     read_steam_manifests)
from ui import state as ui_state
from logger import get_logger

log = get_logger()

_BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
               "AppleWebKit/537.36 (KHTML, like Gecko) "
               "Chrome/124.0.0.0 Safari/537.36")


def _log_line(text, scroll=True):
    try:
        if ui_state.listbox is None or not ui_state.listbox.winfo_exists():
            return
        ui_state.listbox.insert(tk.END, text)
        if scroll:
            ui_state.listbox.yview(tk.END)
        ui_state.root.update_idletasks()
    except Exception:
        pass


def merge_into_library(name, data):
    lib = state["library"]
    nk = normalize_name(name)
    
    target_title = None
    for existing_title in lib:
        base_title = existing_title.replace(" (Steam)", "").replace(" (Epic)", "")
        if normalize_name(base_title) == nk:
            target_title = existing_title
            break

    if target_title is None:
        if name in lib:
            lib[name].update(data)
        else:
            lib[name] = data
        return name

    cur = lib[target_title]
    
    cur_is_steam = cur.get("is_steam_owned", False)
    cur_is_epic = cur.get("is_epic_owned", False)
    new_is_steam = data.get("is_steam_owned", False)
    new_is_epic = data.get("is_epic_owned", False)
    
    conflict = False
    if cur_is_steam and new_is_epic and not cur_is_epic: conflict = True
    if cur_is_epic and new_is_steam and not cur_is_steam: conflict = True
    
    if conflict:
        suffix = " (Epic)" if new_is_epic else " (Steam)"
        new_name = f"{name}{suffix}"
        if new_name in lib:
            for k, v in data.items():
                if k in ("is_steam_owned", "is_epic_owned", "is_installed", "is_dlc"):
                    lib[new_name][k] = bool(lib[new_name].get(k)) or bool(v)
                elif k == "path":
                    if v and (not lib[new_name].get(k) or not os.path.exists(lib[new_name].get(k))):
                        lib[new_name][k] = v
                elif k in ("namespace", "catalog_item_id", "install_location", "install_url", "launch_url", "slug"):
                    if not lib[new_name].get(k):
                        lib[new_name][k] = v
                elif k == "appid":
                    cs, vs = str(lib[new_name].get(k) or ""), str(v or "")
                    if vs.isdigit() and not cs.isdigit():
                        lib[new_name][k] = v
                    elif not cs:
                        lib[new_name][k] = v
        else:
            lib[new_name] = data
        return new_name

    for k, v in data.items():
        if k in ("is_steam_owned", "is_epic_owned", "is_installed", "is_dlc"):
            cur[k] = bool(cur.get(k)) or bool(v)
        elif k == "path":
            if v and (not cur.get(k) or not os.path.exists(cur.get(k))):
                cur[k] = v
        elif k in ("namespace", "catalog_item_id", "install_location",
                   "install_url", "launch_url", "slug"):
            if not cur.get(k):
                cur[k] = v
        elif k == "appid":
            cs, vs = str(cur.get(k) or ""), str(v or "")
            if vs.isdigit() and not cs.isdigit():
                cur[k] = v
            elif not cs:
                cur[k] = v
    return target_title


def _get_epic_slug_via_catalog(namespace, catalog_id):
    """Запрашивает urlSlug (pageSlug) через GraphQL catalogOffer (самый точный метод)."""
    if not namespace or not catalog_id:
        return ""

    query = """
    query catalogQuery($namespace: String!, $id: String!) {
      Catalog {
        catalogOffer(namespace: $namespace, id: $id) {
          catalogNs {
            mappings {
              pageSlug
            }
          }
        }
      }
    }
    """
    body = json.dumps({
        "query": query,
        "variables": {"namespace": namespace, "id": catalog_id}
    }).encode("utf-8")

    endpoint = "https://launcher.store.epicgames.com/graphql"
    try:
        req = urllib.request.Request(
            endpoint,
            data=body,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "GamePanel/1.0",  # ВАЖНО: UA как в icons.py
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=12) as r:
            data = json.loads(r.read().decode("utf-8", errors="ignore"))
            offer = (data.get("data", {}).get("Catalog", {})
                     .get("catalogOffer") or {})
            catalog_ns = offer.get("catalogNs") or {}
            mappings = catalog_ns.get("mappings") or []
            for m in mappings:
                if isinstance(m, dict) and m.get("pageSlug"):
                    slug = m["pageSlug"]
                    if slug and not (len(slug) == 32 and '-' not in slug):
                        log.info(f"CatalogOffer resolved slug: {catalog_id} -> {slug}")
                        return slug
    except urllib.error.HTTPError as e:
        log.debug(f"CatalogOffer HTTP {e.code} on {endpoint}")
    except Exception as e:
        log.debug(f"CatalogOffer error on {endpoint}: {e}")
    return ""


def _resolve_epic_slug_via_graphql(title):
    """Пытается получить urlSlug (pageSlug) через поиск в GraphQL API Epic Store."""
    query = """
    query searchStoreQuery($keywords: String!, $country: String!, $locale: String!) {
      Catalog {
        searchStore(keywords: $keywords, country: $country, locale: $locale, count: 50) {
          elements {
            title
            catalogNs {
              mappings {
                pageSlug
              }
            }
          }
        }
      }
    }
    """
    body = json.dumps({
        "query": query,
        "variables": {"keywords": title, "country": "US", "locale": "en-US"}
    }).encode("utf-8")

    # Слова, которые указывают на DLC или дополнения
    bad_keywords = ["dlc", "addon", "bundle", "pack", "edition", "upgrade", 
                    "sale", "cash", "mode", "content", "pass", "supporter", 
                    "editor", "map", "skin", "battle"]

    for endpoint in (
        "https://store.epicgames.com/graphql",
        "https://graphql.epicgames.com/graphql",
    ):
        req = urllib.request.Request(
            endpoint,
            data=body,
            headers={
                "Content-Type": "application/json",
                "User-Agent": _BROWSER_UA,
            },
            method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read().decode("utf-8", errors="ignore"))
                elements = (data.get("data", {}).get("Catalog", {})
                            .get("searchStore", {}).get("elements", []))
                
                # 1. Собираем все точные совпадения по названию
                exact_slugs = []
                for el in elements:
                    if not isinstance(el, dict):
                        continue
                    if el.get("title", "").lower() == title.lower():
                        catalog_ns = el.get("catalogNs") or {}
                        mappings = catalog_ns.get("mappings") or []
                        for m in mappings:
                            if isinstance(m, dict) and m.get("pageSlug"):
                                exact_slugs.append(m["pageSlug"])

                # 2. Фильтруем и выбираем самый короткий (это базовая игра)
                if exact_slugs:
                    # Оставляем только "хорошие" слаги
                    clean_slugs = [s for s in exact_slugs if not any(bad in s.lower() for bad in bad_keywords)]
                    if clean_slugs:
                        best = min(clean_slugs, key=len)
                        log.info(f"GraphQL (exact) resolved slug: {title} -> {best}")
                        return best
                    
                    # Если все плохие, берём просто самый короткий
                    best = min(exact_slugs, key=len)
                    log.info(f"GraphQL (exact-fallback) resolved slug: {title} -> {best}")
                    return best
                
                # 3. Если точных совпадений нет, берём первый подходящий результат
                for el in elements:
                    if not isinstance(el, dict):
                        continue
                    
                    catalog_ns = el.get("catalogNs") or {}
                    mappings = catalog_ns.get("mappings") or []
                    for m in mappings:
                        if isinstance(m, dict) and m.get("pageSlug"):
                            slug = m["pageSlug"]
                            if slug and not (len(slug) == 32 and '-' not in slug):
                                if not any(bad in slug.lower() for bad in bad_keywords):
                                    log.info(f"GraphQL (filtered) resolved slug: {title} -> {slug}")
                                    return slug
        except urllib.error.HTTPError as e:
            log.debug(f"GraphQL HTTP {e.code} on {endpoint}: {e.reason}")
        except Exception as e:
            log.debug(f"GraphQL error on {endpoint}: {e}")
    return ""


def open_store_page(data):
    is_steam = data.get("is_steam_owned", False)
    is_epic = data.get("is_epic_owned", False)
    appid = str(data.get("appid") or "").strip()
    slug = str(data.get("slug") or "").strip()
    title = str(data.get("name") or "").strip()
    namespace = str(data.get("namespace") or "").strip()
    catalog_id = str(data.get("catalog_item_id") or "").strip()
    
    if is_steam and appid.isdigit():
        url = f"steam://store/{appid}"
        try:
            webbrowser.open(url)
            log.info(f"Steam store (client) opened: {url}")
            return True
        except Exception as e:
            log.error(f"Failed to open Steam client store: {e}")
            return False
        
    if is_epic:
        if not slug and not namespace and not catalog_id:
            messagebox.showwarning(
                "Epic",
                f"Не удалось получить слаг для «{title}».\n"
                f"Страница продукта в Epic Games Launcher недоступна.\n"
                f"Попробуйте пересинхронизировать Epic.")
            return False

        # 1. Основной путь: через catalogOffer (точный слаг базовой игры)
        full_slug = _get_epic_slug_via_catalog(namespace, catalog_id)
        
        # 2. Если не вышло, пробуем через поиск
        if not full_slug:
            search_title = title.replace(" (Epic)", "").replace(" (Steam)", "").strip()
            full_slug = _resolve_epic_slug_via_graphql(search_title)
            
        # 3. Если всё равно пусто, используем базовый слаг
        if not full_slug:
            full_slug = slug

        if not full_slug:
            messagebox.showwarning(
                "Epic",
                f"Не удалось определить URL для «{title}».\n"
                f"Пересинхронизируйте библиотеку Epic.")
            return False

        url = f"com.epicgames.launcher://store/product/{full_slug}"
        try:
            webbrowser.open(url)
            log.info(f"Epic store page opened: {url}")
            return True
        except Exception as e:
            log.error(f"Failed to open Epic client store: {e}")
            return False
        
    messagebox.showinfo("Магазин", "Не удалось определить магазин для этой игры.")
    return False


def sync_steam_account():
    from ui.views import show_scanner
    from ui.sidebar import update_steam_status

    key = state["app_config"].get("steam_api_key", "").strip()
    sid_raw = state["app_config"].get("steam_id", "").strip()
    if not key or not sid_raw:
        from ui.dialogs import connect_steam_dialog
        connect_steam_dialog()
        key = state["app_config"].get("steam_api_key", "").strip()
        sid_raw = state["app_config"].get("steam_id", "").strip()
        if not key or not sid_raw:
            return

    show_scanner()
    ui_state.listbox.delete(0, tk.END)
    ui_state.listbox.insert(tk.END, "Steam sync через Web API")
    ui_state.root.update()
    log.info("Старт Steam sync.")

    def worker():
        games, err = fetch_steam_games(sid_raw, key)

        def ui():
            try:
                if err:
                    _log_line(f"Ошибка: {err}")
                    messagebox.showerror("Steam", err)
                    return
                new_count = 0
                for name, data in games.items():
                    existing = any(normalize_name(t.replace(" (Steam)", "").replace(" (Epic)", "")) == normalize_name(name)
                                   for t in state["library"])
                    merge_into_library(name, data)
                    if not existing:
                        new_count += 1
                _log_line(f"Из Steam: {len(games)} (новых: {new_count})")
                _log_line("Сканирую локальные диски...")
                update_steam_status()
                save_library()
                scan_all_drives()
            except Exception as e:
                log.error(f"Steam sync UI: {e}")

        ui_state.root.after(0, ui)

    threading.Thread(target=worker, daemon=True).start()


def sync_epic_games(prefer_legendary: bool = True, enrich_info: bool = False):
    from ui.views import show_scanner, show_library
    from ui.library_view import refresh_library
    from ui.sidebar import update_epic_status

    show_scanner()
    ui_state.listbox.delete(0, tk.END)
    ui_state.listbox.insert(tk.END, "Epic sync")
    ui_state.root.update()

    def worker():
        local_games, local_err = fetch_epic_games()
        if local_err:
            log.info(f"Epic local: {local_err}")

        library_games = {}
        lib_err = None

        try:
            from epic_auth_embedded import is_logged_in, fetch_epic_library
            ok, name = is_logged_in()
            if ok:
                log.info(f"Epic аккаунт: {name}")
                library_games, lib_err = fetch_epic_library()
                if lib_err:
                    log.warning(f"Epic library: {lib_err}")
            else:
                lib_err = "Epic не привязан."
                log.info("Epic sync: аккаунт не привязан, только локальные.")
        except ImportError as e:
            lib_err = f"epic_auth_embedded недоступен: {e}"
            log.error(f"Epic sync import: {e}")
        except Exception as e:
            lib_err = f"Ошибка чтения библиотеки Epic: {e}"
            log.exception("Epic sync worker")

        def ui():
            try:
                for title in list(state["library"].keys()):
                    d = state["library"].get(title, {})
                    if isinstance(d, dict) and d.get("is_epic_owned"):
                        if is_non_game(d.get("appid", "")):
                            del state["library"][title]
                            continue
                        if d.get("is_dlc") and title.endswith(" Content"):
                            del state["library"][title]
                            continue

                merged = dict(local_games or {})
                if library_games:
                    for name, data in library_games.items():
                        if name in merged:
                            cur = merged[name]
                            for k, v in data.items():
                                if k in ("is_installed", "is_epic_owned", "is_dlc"):
                                    cur[k] = bool(cur.get(k)) or bool(v)
                                elif k == "path":
                                    if v and (not cur.get(k)
                                              or not os.path.exists(cur.get(k))):
                                        cur[k] = v
                                elif not cur.get(k):
                                    cur[k] = v
                        else:
                            merged[name] = data

                if not merged:
                    parts = []
                    if local_err:
                        parts.append(local_err)
                    if lib_err:
                        parts.append(lib_err)
                    _log_line("Ничего не получено. " + " ".join(parts))
                    return

                new_count = 0
                for name, data in merged.items():
                    existing = any(normalize_name(t.replace(" (Steam)", "").replace(" (Epic)", "")) == normalize_name(name)
                                   for t in state["library"])
                    merge_into_library(name, data)
                    if not existing:
                        new_count += 1

                _log_line(f"Из Epic: {len(merged)} (новых: {new_count})")
                if lib_err:
                    _log_line(f"Примечание: {lib_err}")
                update_epic_status()
                save_library()
                refresh_library()
                show_library()
            except Exception as e:
                log.error(f"Epic sync UI: {e}")

        ui_state.root.after(0, ui)

    threading.Thread(target=worker, daemon=True).start()


def scan_all_drives():
    from ui.views import show_scanner
    from ui.library_view import refresh_library

    show_scanner()
    ui_state.listbox.delete(0, tk.END)
    drives = get_all_drives()
    _log_line(f"Диски: {', '.join(drives)}")

    steam_manifests = read_steam_manifests()
    _log_line(f"Steam-манифестов: {len(steam_manifests)}")

    stores = get_store_paths(drives)
    if not stores:
        _log_line("Игровые каталоги не найдены.")
    else:
        _log_line(f"Сканирую {len(stores)} каталогов...")
    ui_state.root.update()

    found = 0

    for appid, install_dir in steam_manifests.items():
        exe = find_best_exe(install_dir)
        if not exe:
            continue
        target = None
        for title, data in state["library"].items():
            if str(data.get("appid", "")) == str(appid):
                target = title
                break
        payload = {
            "appid": str(appid),
            "path": exe,
            "is_installed": True,
            "is_steam_owned": True,
            "install_location": install_dir,
        }
        if target:
            state["library"][target].update(payload)
            _log_line(f"[S] {target}  ->  {exe}")
        else:
            folder_name = os.path.basename(os.path.normpath(install_dir))
            payload["name"] = folder_name
            state["library"].setdefault(folder_name, {}).update(payload)
            _log_line(f"[S] {folder_name}  ->  {exe}")
        found += 1

    for store in stores:
        try:
            for item in os.listdir(store):
                full = os.path.join(store, item)
                if not os.path.isdir(full):
                    continue
                exe = find_best_exe(full)
                if not exe:
                    continue
                nk = normalize_name(item)
                existing_title = None
                for t in state["library"]:
                    base = t.replace(" (Steam)", "").replace(" (Epic)", "")
                    if normalize_name(base) == nk:
                        existing_title = t
                        break
                if existing_title:
                    cur = state["library"][existing_title]
                    cur["path"] = exe
                    cur["is_installed"] = True
                    cur.setdefault("is_steam_owned", False)
                    cur.setdefault("is_epic_owned", False)
                else:
                    state["library"][item] = {
                        "name": item, "path": exe,
                        "is_installed": True,
                        "is_steam_owned": False,
                        "is_epic_owned": False,
                    }
                _log_line(f"[+] {item}  ->  {exe}")
                found += 1
        except PermissionError:
            continue
        except Exception as e:
            log.error(f"Скан {store}: {e}")
            continue

    _log_line("-" * 60)
    _log_line(f"Найдено: {found}")
    save_library()
    refresh_library()


def add_custom_folder():
    from ui.views import show_scanner
    from ui.library_view import refresh_library

    folder = filedialog.askdirectory(title="Папка с игрой или играми")
    if not folder:
        return
    folder = os.path.normpath(folder)
    if not os.path.isdir(folder):
        messagebox.showerror("Ошибка", f"Путь не является папкой:\n{folder}")
        return

    show_scanner()
    ui_state.listbox.delete(0, tk.END)
    _log_line(f"Сканирую: {folder}")
    ui_state.root.update()

    added, found = set(), 0

    def commit(title, exe):
        nonlocal found
        merge_into_library(title, {"name": title, "path": exe,
                                   "is_installed": True})
        _log_line(f"[+] {title}")
        added.add(exe)
        found += 1

    exe = find_best_exe(folder)
    if exe:
        commit(os.path.basename(folder), exe)
    try:
        for sub in os.listdir(folder):
            sub_path = os.path.join(folder, sub)
            if not os.path.isdir(sub_path):
                continue
            exe = find_best_exe(sub_path)
            if exe and exe not in added:
                commit(sub, exe)
    except PermissionError as e:
        _log_line(f"Нет доступа: {e}")
    except Exception as e:
        _log_line(f"Ошибка: {e}")

    _log_line("-" * 60)
    _log_line(f"Добавлено: {found}")
    save_library()
    refresh_library()


def _steam_installed_running():
    if os.name != "nt":
        return False
    try:
        out = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq steam.exe", "/NH"],
            capture_output=True, text=True, timeout=5,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return "steam.exe" in (out.stdout or "").lower()
    except Exception:
        return False


def _launch_steam_client():
    if _steam_installed_running():
        return True
    candidates = []
    try:
        import winreg
        for hive, path in [
            (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam"),
        ]:
            try:
                with winreg.OpenKey(hive, path) as k:
                    val, _ = winreg.QueryValueEx(k, "SteamExe")
                    if val and os.path.isfile(val):
                        candidates.append(val)
            except Exception:
                continue
    except Exception:
        pass
    for p in [r"C:\Program Files (x86)\Steam\steam.exe",
              r"C:\Program Files\Steam\steam.exe"]:
        if os.path.isfile(p):
            candidates.append(p)
    if not candidates:
        return False
    try:
        subprocess.Popen([candidates[0]],
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        for _ in range(10):
            time.sleep(0.5)
            if _steam_installed_running():
                time.sleep(1.0)
                return True
        return True
    except Exception as e:
        log.error(f"Запуск Steam: {e}")
        return False


def _is_epic_running():
    if os.name != "nt":
        return False
    try:
        out = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq EpicGamesLauncher.exe", "/NH"],
            capture_output=True, text=True, timeout=5,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return "epicgameslauncher.exe" in (out.stdout or "").lower()
    except Exception:
        return False


def _find_epic_exe():
    for p in [
        r"C:\Program Files\Epic Games\Launcher\Portal\Binaries\Win64\EpicGamesLauncher.exe",
        r"C:\Program Files (x86)\Epic Games\Launcher\Portal\Binaries\Win64\EpicGamesLauncher.exe",
        r"D:\Program Files\Epic Games\Launcher\Portal\Binaries\Win64\EpicGamesLauncher.exe",
        r"D:\Epic Games\Launcher\Portal\Binaries\Win64\EpicGamesLauncher.exe",
    ]:
        if os.path.isfile(p):
            return p
    return None


def _launch_epic_client(url=None):
    if _is_epic_running():
        return True
    exe = _find_epic_exe()
    if not exe:
        return False
    try:
        args = [exe]
        if url:
            args.append(url)
        subprocess.Popen(args,
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return True
    except Exception as e:
        log.error(f"Запуск Epic Launcher: {e}")
        return False


def _epic_install(data):
    title = data.get("name") or data.get("appid") or "?"

    if data.get("is_dlc"):
        messagebox.showinfo(
            "Epic",
            f"«{title}» — это DLC (дополнение).\n\n"
            f"Установите базовую игру, и дополнение установится автоматически.")
        return

    url = build_epic_install_url(data, interactive=True)
    if not url:
        messagebox.showwarning(
            "Epic",
            f"Не удалось построить URL установки для «{title}».\n\n"
            f"Нет полного триплета namespace + catalogItemId + appId.\n"
            f"Попробуйте пересинхронизировать Epic.")
        return

    log.info(f"Epic install URL: {url}")

    def worker():
        was_running = _is_epic_running()
        if not was_running:
            if _launch_epic_client(url):
                log.info(f"Epic Launcher запущен с URL: {url}")
                return
            log.warning("Epic Launcher не запустился с URL, fallback на webbrowser.open.")
        try:
            webbrowser.open(url)
            log.info(f"Epic install URL открыт (интерактивный): {url}")
        except Exception as e:
            log.error(f"Epic install протокол не сработал: {e}")
            ui_state.root.after(0, lambda: messagebox.showerror(
                "Epic",
                f"Не удалось открыть Epic Launcher.\n\n"
                f"Проверь, что Epic Games Launcher установлен.\n\n"
                f"Ошибка: {e}"))

    threading.Thread(target=worker, daemon=True).start()


def _epic_launch(data):
    title = data.get("name") or data.get("appid") or "?"

    if data.get("is_dlc"):
        messagebox.showinfo(
            "Epic",
            f"«{title}» — это DLC.\n\n"
            f"Оно не запускается отдельно. Запустите базовую игру.")
        return

    url = build_epic_launch_url(data)
    if not url:
        messagebox.showwarning(
            "Epic",
            f"Не удалось построить URL запуска для «{title}».\n"
            f"Пересинхронизируйте Epic.")
        return

    log.info(f"Epic launch URL: {url}")

    def worker():
        was_running = _is_epic_running()
        if not was_running:
            if _launch_epic_client(url):
                log.info(f"Epic Launcher запущен с URL: {url}")
                return
        try:
            webbrowser.open(url)
            log.info(f"Epic launch URL открыт: {url}")
        except Exception as e:
            log.error(f"Epic launch протокол не сработал: {e}")
            ui_state.root.after(0, lambda: messagebox.showerror(
                "Epic", f"Не удалось запустить:\n{e}"))

    threading.Thread(target=worker, daemon=True).start()


def run_game(data):
    is_steam = data.get("is_steam_owned", False)
    is_epic = data.get("is_epic_owned", False)
    installed = data.get("is_installed", False)
    appid = str(data.get("appid") or "")

    if is_steam and appid.isdigit():
        if os.name == "nt" and not _steam_installed_running():
            _launch_steam_client()
        try:
            webbrowser.open(f"steam://run/{appid}")
            log.info(f"Steam запуск: {data.get('name')}")
        except Exception as e:
            messagebox.showerror("Steam", str(e))
        return

    if is_epic and installed:
        _epic_launch(data)
        return

    if is_epic and not installed:
        _epic_install(data)
        return

    if installed and data.get("path") and os.path.exists(data["path"]):
        try:
            os.chdir(os.path.dirname(data["path"]))
            os.startfile(data["path"])
        except Exception as e:
            messagebox.showerror("Ошибка запуска", str(e))
        return

    if installed and data.get("install_location"):
        exe = find_best_exe(data["install_location"])
        if exe and os.path.exists(exe):
            try:
                os.chdir(os.path.dirname(exe))
                os.startfile(exe)
            except Exception as e:
                messagebox.showerror("Ошибка запуска", str(e))
            return
        messagebox.showwarning("Не найден exe",
                               f"Папка: {data.get('install_location')}")
        return

    if is_steam and appid:
        url = data.get("install_url") or f"steam://install/{appid}"
        webbrowser.open(url)
        return

    messagebox.showwarning("Запуск", "Не удалось определить способ.")