# language: Python 3.10+, file: ui/views.py
# Переключатели вкладок: показ библиотеки / журнала.

from ui import state as ui_state
from ui.library_view import refresh_library
from logger import get_logger

log = get_logger()


def show_scanner():
    try:
        ui_state.library_frame.pack_forget()
        ui_state.scan_frame.pack(fill="both", expand=True)
        ui_state.title_label.config(text="Журнал сканирования")
    except Exception:
        pass


def show_library():
    try:
        ui_state.scan_frame.pack_forget()
        ui_state.library_frame.pack(fill="both", expand=True)
        ui_state.title_label.config(text="Моя Библиотека")
        refresh_library()
    except Exception:
        pass