# language: Python 3.10+, file: ui/state.py
# Глобальные ссылки на виджеты. Заполняются при сборке главного окна.

root = None
title_label = None
listbox = None
scan_frame = None
library_frame = None
lib_inner_frame = None
lib_canvas = None
theme_btn = None
steam_status_lbl = None
epic_status_lbl = None
inner_window_id = None
filter_buttons = {}
search_entry = None