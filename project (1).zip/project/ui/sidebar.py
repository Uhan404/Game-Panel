# language: Python 3.10+, file: ui/sidebar.py
# Левая панель: статусы Steam/Epic и кнопки действий.

import tkinter as tk
from config import THEMES, state
from ui import state as ui_state
from ui.theme import register_widget, toggle_theme
from logger import get_logger

log = get_logger()


def update_steam_status():
    try:
        key = state["app_config"].get("steam_api_key", "").strip()
        sid = state["app_config"].get("steam_id", "").strip()
        c = THEMES.get(state.get("theme"), THEMES["dark"])
        if key and sid:
            ui_state.steam_status_lbl.config(text=f"Steam: {sid[:10]}… (API)",
                                             fg=c["badge_installed"])
        elif key:
            ui_state.steam_status_lbl.config(text="Steam: ключ есть",
                                             fg=c["badge_steam"])
        else:
            ui_state.steam_status_lbl.config(text="Steam: не привязан",
                                             fg=c["danger"])
    except tk.TclError:
        pass


def update_epic_status():
    try:
        c = THEMES.get(state.get("theme"), THEMES["dark"])
        from epic_auth_embedded import is_logged_in
        ok, name = is_logged_in()
        if ok:
            ui_state.epic_status_lbl.config(
                text=f"Epic: {name or 'вход выполнен'}",
                fg=c["badge_epic"])
        else:
            ui_state.epic_status_lbl.config(text="Epic: не привязан",
                                            fg=c["danger"])
    except tk.TclError:
        pass
    except Exception as e:
        log.warning(f"update_epic_status: {e}")


def build_sidebar(parent):
    from ui.actions import (scan_all_drives, sync_steam_account,
                            add_custom_folder, sync_epic_games)
    from ui.dialogs import connect_steam_dialog, epic_login_dialog
    from ui.views import show_library, show_scanner

    sidebar = register_widget(tk.Frame(parent, width=240), "sidebar")
    sidebar.pack(side="left", fill="y")
    sidebar.pack_propagate(False)

    register_widget(tk.Label(sidebar, text="ГЕЙМ ПАНЕЛЬ",
                             font=("Segoe UI", 14, "bold")),
                    "sidebar_title").pack(pady=(20, 10))

    ui_state.steam_status_lbl = tk.Label(
        sidebar, font=("Segoe UI", 9, "bold"),
        bg=THEMES[state["theme"]]["sidebar"])
    ui_state.steam_status_lbl.pack(pady=(0, 2))
    update_steam_status()

    ui_state.epic_status_lbl = tk.Label(
        sidebar, font=("Segoe UI", 9, "bold"),
        bg=THEMES[state["theme"]]["sidebar"])
    ui_state.epic_status_lbl.pack(pady=(0, 12))
    update_epic_status()

    def btn(text, font_size=10, bold=False, accent=False, cmd=None):
        f = ("Segoe UI", font_size, "bold") if bold else ("Segoe UI", font_size)
        b = register_widget(tk.Button(
            sidebar, text=text, font=f, borderwidth=0, cursor="hand2",
            command=cmd), "btn_accent" if accent else "btn")
        b.pack(fill="x", padx=12, pady=4, ipady=5)
        return b

    btn("Сканировать диски", bold=True, accent=True, cmd=scan_all_drives)
    btn("Синхронизировать Steam", cmd=sync_steam_account)
    btn("Steam API ключ…", font_size=9, cmd=connect_steam_dialog)

    tk.Frame(sidebar, bg=THEMES[state["theme"]]["sidebar"], height=8).pack()

    btn("Войти в Epic", bold=True, accent=True, cmd=epic_login_dialog)
    btn("Синхронизировать Epic", cmd=lambda: sync_epic_games(True))
    btn("Epic: только установленные", font_size=9,
        cmd=lambda: sync_epic_games(False))

    tk.Frame(sidebar, bg=THEMES[state["theme"]]["sidebar"], height=8).pack()

    btn("Добавить папку...", cmd=add_custom_folder)
    btn("Моя Библиотека", bold=True, cmd=show_library)
    btn("Журнал", cmd=show_scanner)

    ui_state.theme_btn = register_widget(tk.Button(
        sidebar, text="Светлая тема", font=("Segoe UI", 10), borderwidth=0,
        cursor="hand2", command=toggle_theme), "btn")
    ui_state.theme_btn.pack(side="bottom", fill="x", padx=12, pady=20, ipady=5)

    return sidebar