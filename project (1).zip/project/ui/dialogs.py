# language: Python 3.10+, file: ui/dialogs.py
# Все диалоги: Steam API, Epic login, Epic install.

import os
import webbrowser
import tkinter as tk
from tkinter import messagebox, filedialog

from config import (THEMES, state, API_KEY_PAGE, save_config,
                    DEFAULT_EPIC_INSTALL_PATH)
from epic_games import ensure_writable_dir
from ui import state as ui_state
from ui.clipboard import bind_entry_clipboard
from logger import get_logger

log = get_logger()


# --- Steam API ---

def prompt_api_key_dialog():
    dlg = tk.Toplevel(ui_state.root)
    dlg.title("Steam API")
    dlg.geometry("560x480")
    dlg.resizable(False, False)
    dlg.transient(ui_state.root)
    dlg.grab_set()
    x = ui_state.root.winfo_x() + (ui_state.root.winfo_width() // 2) - 280
    y = ui_state.root.winfo_y() + (ui_state.root.winfo_height() // 2) - 240
    dlg.geometry(f"+{x}+{y}")

    c = THEMES.get(state.get("theme"), THEMES["dark"])
    dlg.configure(bg=c["bg"])

    tk.Label(dlg, text="Steam Web API", bg=c["bg"], fg=c["text"],
             font=("Segoe UI", 13, "bold"), anchor="w"
             ).pack(fill="x", padx=20, pady=(20, 6))

    instruction = (
        "1. Открой страницу получения API-ключа (кнопка ниже).\n"
        "2. Войди под своим Steam-аккаунтом.\n"
        "3. В поле «Domain Name» впиши любое слово.\n"
        "4. Согласись с условиями — ключ выдаётся сразу.\n"
        "5. Скопируй ключ в поле ниже.\n"
        "6. SteamID подставь свой — 17 цифр или ссылку на профиль."
    )
    tk.Label(dlg, text=instruction, bg=c["bg"], fg=c["text_muted"],
             font=("Segoe UI", 9), justify="left", anchor="w",
             wraplength=520).pack(fill="x", padx=20, pady=(0, 10))

    tk.Button(dlg, text="Открыть steamcommunity.com/dev/apikey",
              bg=c["btn"], fg=c["text"], borderwidth=0, cursor="hand2",
              font=("Segoe UI", 9),
              command=lambda: webbrowser.open(API_KEY_PAGE)
              ).pack(padx=20, pady=(0, 14), anchor="w")

    tk.Label(dlg, text="Steam Web API ключ", bg=c["bg"], fg=c["text"],
             font=("Segoe UI", 10, "bold"), anchor="w"
             ).pack(fill="x", padx=20, pady=(4, 4))

    key_entry = tk.Entry(dlg, font=("Consolas", 10), bg=c["card"], fg=c["text"],
                         insertbackground=c["text"], relief="flat", bd=6)
    key_entry.pack(fill="x", padx=20)
    key_entry.insert(0, state["app_config"].get("steam_api_key", ""))
    bind_entry_clipboard(key_entry, dlg)

    tk.Label(dlg, text="SteamID64 или ссылка на профиль", bg=c["bg"],
             fg=c["text"], font=("Segoe UI", 10, "bold"), anchor="w"
             ).pack(fill="x", padx=20, pady=(14, 4))

    id_entry = tk.Entry(dlg, font=("Consolas", 10), bg=c["card"], fg=c["text"],
                        insertbackground=c["text"], relief="flat", bd=6)
    id_entry.pack(fill="x", padx=20)
    id_entry.insert(0, state["app_config"].get("steam_id", ""))
    bind_entry_clipboard(id_entry, dlg)

    result = {"ok": False}

    def on_ok():
        result["ok"] = True
        result["api_key"] = key_entry.get().strip()
        result["steam_id"] = id_entry.get().strip()
        dlg.destroy()

    row = tk.Frame(dlg, bg=c["bg"])
    row.pack(fill="x", padx=20, pady=20)
    tk.Button(row, text="Сохранить и синхронизировать",
              bg=c["accent"], fg="#ffffff", borderwidth=0, cursor="hand2",
              command=on_ok).pack(side="right", padx=(6, 0), ipady=4, ipadx=8)
    tk.Button(row, text="Отмена", bg=c["btn"], fg=c["text"],
              borderwidth=0, cursor="hand2",
              command=dlg.destroy).pack(side="right", ipady=4, ipadx=8)

    key_entry.focus_set()
    dlg.wait_window()
    return result if result["ok"] else None


def connect_steam_dialog():
    from ui.actions import sync_steam_account
    from ui.sidebar import update_steam_status

    res = prompt_api_key_dialog()
    if not res:
        return
    state["app_config"]["steam_api_key"] = res["api_key"]
    state["app_config"]["steam_id"] = res["steam_id"]
    save_config()
    update_steam_status()
    if res["api_key"] and res["steam_id"]:
        sync_steam_account()


# --- Epic login ---

def epic_login_dialog():
    """Кнопка «Войти в Epic». Запускает встроенный legendary.exe auth."""
    from epic_auth_embedded import is_logged_in, logout, run_legendary_auth
    from ui.sidebar import update_epic_status
    from ui.actions import sync_epic_games

    try:
        ok, name = is_logged_in()
    except Exception as e:
        log.error(f"epic_login_dialog is_logged_in: {e}")
        ok, name = False, None

    if ok:
        if messagebox.askyesno("Epic",
                               f"Уже вошёл как {name}.\n\nВыйти?"):
            ok2, msg = logout()
            log.info(f"Epic logout: {ok2} {msg}")
            update_epic_status()
        return

    def on_success():
        update_epic_status()
        sync_epic_games(prefer_legendary=True)

    run_legendary_auth(ui_state.root, on_success=on_success)


# --- Epic install ---

def _ensure_epic_install_dir():
    path = state["app_config"].get("epic_install_path", "").strip()
    if path:
        ok, err = ensure_writable_dir(path)
        if ok:
            return path
        log.warning(f"Epic path негоден ({path}): {err}")
    ok, _ = ensure_writable_dir(DEFAULT_EPIC_INSTALL_PATH)
    if ok:
        state["app_config"]["epic_install_path"] = DEFAULT_EPIC_INSTALL_PATH
        save_config()
        return DEFAULT_EPIC_INSTALL_PATH
    home_games = os.path.join(os.path.expanduser("~"), "Games")
    ok, _ = ensure_writable_dir(home_games)
    if ok:
        state["app_config"]["epic_install_path"] = home_games
        save_config()
        return home_games
    return None


def epic_install(data):
    """Установка игры через Epic Games Launcher.
    Делегирует в _epic_install из ui/actions.py."""
    from ui.actions import _epic_install
    _epic_install(data)