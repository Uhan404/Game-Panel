# language: Python 3.10+, file: ui/library_view.py
# Сетка карточек игр, скролл, контекстное меню карточки.

import os
import threading
import tkinter as tk
from tkinter import messagebox, filedialog

from PIL import Image, ImageTk

from config import (THEMES, state, delete_from_library, dedup_library,
                    safe_filename, CACHE_DIR)
from icons import load_game_icon, fetch_steam_cover, fetch_epic_cover
from scanner import open_game_location
from ui import state as ui_state
from ui.theme import register_widget, apply_theme
from logger import get_logger

log = get_logger()


def build_library_view(parent):
    library_frame = register_widget(tk.Frame(parent), "bg")
    lib_sb = tk.Scrollbar(library_frame, orient="vertical")
    lib_sb.pack(side="right", fill="y")

    lib_canvas = register_widget(
        tk.Canvas(library_frame, highlightthickness=0,
                  yscrollcommand=lib_sb.set), "bg")
    lib_sb.config(command=lib_canvas.yview)

    lib_inner_frame = register_widget(tk.Frame(lib_canvas), "bg")
    inner_window_id = lib_canvas.create_window(
        (0, 0), window=lib_inner_frame, anchor="nw")

    lib_inner_frame.bind("<Configure>", _on_inner_configure)
    lib_canvas.bind("<Configure>", _sync_canvas_width)
    lib_canvas.pack(side="left", fill="both", expand=True, padx=10)

    ui_state.library_frame = library_frame
    ui_state.lib_canvas = lib_canvas
    ui_state.lib_inner_frame = lib_inner_frame
    ui_state.inner_window_id = inner_window_id

    return library_frame


def _sync_canvas_width(event):
    if state.get("refreshing") or event.width <= 1:
        return
    try:
        ui_state.lib_canvas.itemconfigure(ui_state.inner_window_id,
                                          width=event.width)
    except tk.TclError:
        pass


def _on_inner_configure(event):
    if state.get("refreshing"):
        return
    try:
        ui_state.lib_canvas.configure(
            scrollregion=ui_state.lib_canvas.bbox("all"))
    except tk.TclError:
        pass


def refresh_library():
    from ui.filters import passes_filter, get_search_query

    if state.get("refreshing"):
        return
    state["refreshing"] = True
    query = get_search_query()

    try:
        dedup_library()
        ui_state.lib_canvas.unbind("<Configure>")
        ui_state.lib_canvas.yview_moveto(0)

        for w in ui_state.lib_inner_frame.winfo_children():
            w.destroy()

        state["widgets_to_theme"] = [
            (w, t) for w, t in state["widgets_to_theme"]
            if t not in ("card", "card_text")
        ]

        items = [(t, d) for t, d in state["library"].items()
                 if isinstance(d, dict) and passes_filter(d)]
        if query:
            q = query.lower()
            items = [(t, d) for t, d in items if q in t.lower()]
        items.sort(key=lambda x: x[0])

        if not items:
            lbl = register_widget(tk.Label(
                ui_state.lib_inner_frame,
                text="Ничего не найдено.",
                font=("Segoe UI", 12)), "text")
            lbl.grid(row=0, column=0, pady=60, padx=60)
            return

        colors = THEMES.get(state.get("theme"), THEMES["dark"])
        max_cols = 4
        for i in range(max_cols):
            ui_state.lib_inner_frame.columnconfigure(i, weight=1, minsize=180)

        row, col = 0, 0
        for title, data in items:
            _build_card(title, data, row, col, colors)
            col += 1
            if col >= max_cols:
                col = 0
                row += 1

    except Exception as e:
        log.error(f"refresh_library: {e}")
    finally:
        try:
            ui_state.lib_canvas.bind("<Configure>", _sync_canvas_width)
            ui_state.lib_inner_frame.update_idletasks()
            ui_state.lib_canvas.configure(
                scrollregion=ui_state.lib_canvas.bbox("all"))
            apply_theme()
        except Exception:
            pass
        state["refreshing"] = False


def _build_card(title, data, row, col, colors):
    from ui.actions import run_game

    installed = data.get("is_installed", False)
    exe = data.get("path") if installed else None
    appid = data.get("appid")
    display = title if len(title) <= 18 else title[:15] + "..."

    card = register_widget(tk.Frame(ui_state.lib_inner_frame, bd=0,
                                    padx=12, pady=12), "card")
    card.grid(row=row, column=col, padx=10, pady=10, sticky="nsew")

    icon_lbl = register_widget(tk.Label(card, cursor="hand2"), "card")
    photo = load_game_icon(
        title, exe, appid, icon_lbl, root=ui_state.root,
        is_epic=data.get("is_epic_owned", False),
        namespace=data.get("namespace") or "",
        catalog_item_id=data.get("catalog_item_id") or "")
    if photo is not None:
        icon_lbl.config(image=photo)
    icon_lbl.pack(pady=(0, 6))

    if installed:
        badge_text = "Установлена"
        badge_bg = colors["badge_installed"]
    elif data.get("is_epic_owned"):
        badge_text = "Epic"
        badge_bg = colors["badge_epic"]
    elif data.get("is_steam_owned"):
        badge_text = "Steam"
        badge_bg = colors["badge_steam"]
    else:
        badge_text = "?"
        badge_bg = colors["text_muted"]

    tk.Label(card, text=badge_text, font=("Segoe UI", 7, "bold"),
             fg="#ffffff", bg=badge_bg, padx=6, pady=2).pack(pady=(0, 6))

    name_lbl = register_widget(
        tk.Label(card, text=display, font=("Segoe UI", 10, "bold")),
        "card_text")
    name_lbl.pack(pady=(0, 10))

    btn_text = "Играть" if installed else "Установить"
    btn_type = "btn_accent" if installed else "btn"
    play_btn = register_widget(tk.Button(
        card, text=btn_text, font=("Segoe UI", 9, "bold"),
        borderwidth=0, cursor="hand2",
        command=lambda d=data: run_game(d)), btn_type)
    play_btn.pack(fill="x", ipady=4)

    for w in (card, icon_lbl, name_lbl, play_btn):
        w.bind("<Button-3>",
               lambda e, t=title, d=data, l=icon_lbl:
               open_icon_menu(e, t, d, l))


def open_icon_menu(event, title, data, label):
    from ui.actions import run_game
    from ui.actions import _epic_install as epic_install
    from ui.actions import open_store_page

    menu = tk.Menu(ui_state.root, tearoff=0)
    exe = data.get("path") if data.get("is_installed") else None
    appid = data.get("appid")
    is_epic = data.get("is_epic_owned", False)
    is_steam = data.get("is_steam_owned", False)
    namespace = data.get("namespace") or ""
    catalog_id = data.get("catalog_item_id") or ""

    def update_steam_cover():
        _async_cover_update(title, label,
                            lambda: fetch_steam_cover(title, appid), "Steam")

    def update_epic_cover():
        _async_cover_update(title, label,
                            lambda: fetch_epic_cover(namespace, catalog_id,
                                                     app_name=appid),
                            "Epic")

    def pick_local():
        path = filedialog.askopenfilename(
            title="Обложка",
            filetypes=[("Изображения", "*.png *.jpg *.jpeg *.ico *.bmp")])
        if not path:
            return
        try:
            img = Image.open(path).resize((72, 72), Image.Resampling.LANCZOS)
            safe = safe_filename(title)
            from config import CACHE_DIR
            os.makedirs(CACHE_DIR, exist_ok=True)
            img.save(os.path.join(CACHE_DIR, f"{safe}.png"))
            photo = ImageTk.PhotoImage(img)
            state["icon_cache"][title] = photo
            label.config(image=photo)
        except Exception as e:
            messagebox.showerror("Ошибка", str(e))

    if exe and os.path.exists(exe):
        menu.add_command(label="Открыть папку с игрой",
                         command=lambda: open_game_location(exe))
        menu.add_separator()
        
    if is_steam or is_epic:
        menu.add_command(label="Открыть в магазине",
                         command=lambda: open_store_page(data))

    if is_epic:
        menu.add_command(label="Обновить обложку из Epic", command=update_epic_cover)
        if not data.get("is_installed"):
            menu.add_command(label="Установить через Epic",
                             command=lambda: epic_install(data))
    if is_steam:
        menu.add_command(label="Обновить обложку из Steam",
                         command=update_steam_cover)
    if not is_epic and not is_steam:
        menu.add_command(label="Обновить обложку из Steam",
                         command=update_steam_cover)

    menu.add_command(label="Выбрать свою обложку", command=pick_local)

    if not data.get("is_installed") and data.get("is_steam_owned"):
        menu.add_separator()
        menu.add_command(label="Установить через Steam",
                         command=lambda: run_game(data))

    menu.add_separator()
    menu.add_command(label="Удалить из библиотеки",
                     command=lambda: _delete_and_refresh(title))

    try:
        menu.tk_popup(event.x_root, event.y_root)
    except tk.TclError:
        pass


def _async_cover_update(title, label, loader, source):
    def task():
        try:
            img = loader()
        except Exception as e:
            log.error(f"cover update {source}: {e}")
            img = None
        if not img:
            ui_state.root.after(0, lambda: messagebox.showinfo(
                source, f"Обложка не найдена: {title}"))
            return

        safe = safe_filename(title)
        try:
            from config import CACHE_DIR
            os.makedirs(CACHE_DIR, exist_ok=True)
            img.save(os.path.join(CACHE_DIR, f"{safe}.png"))
        except Exception:
            pass

        def apply():
            if not label.winfo_exists():
                return
            try:
                photo = ImageTk.PhotoImage(img)
                state["icon_cache"][title] = photo
                label.config(image=photo)
            except Exception:
                pass
        ui_state.root.after(0, apply)

    threading.Thread(target=task, daemon=True).start()


def _delete_and_refresh(title):
    if messagebox.askyesno("Удаление", f"Удалить «{title}»?"):
        delete_from_library(title)
        refresh_library()