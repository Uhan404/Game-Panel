# language: Python 3.10+, file: ui/scanner_view.py
# Журнал сканирования (Listbox).

import tkinter as tk
from config import state
from ui import state as ui_state
from ui.theme import register_widget


def build_scanner_view(parent):
    scan_frame = register_widget(tk.Frame(parent), "bg")

    sb = tk.Scrollbar(scan_frame)
    sb.pack(side="right", fill="y")

    listbox = register_widget(tk.Listbox(
        scan_frame, font=("Consolas", 10), borderwidth=0,
        highlightthickness=1, yscrollcommand=sb.set), "listbox")
    listbox.pack(side="left", fill="both", expand=True, padx=20, pady=(0, 20))
    sb.config(command=listbox.yview)

    ui_state.scan_frame = scan_frame
    ui_state.listbox = listbox
    return scan_frame