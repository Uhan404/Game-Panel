# language: Python 3.10+, file: ui/filters.py
# Фильтры и поисковое поле.

import tkinter as tk
from config import THEMES, state
from ui import state as ui_state
from logger import get_logger

log = get_logger()

FILTERS = [
    ("all", "Все"),
    ("apps", "Приложения"),
    ("dlc", "DLC"),
    ("steam", "Steam"),
    ("epic", "Epic"),
    ("installed", "Установленные"),
    ("local", "Локальные"),
]


def set_filter(key):
    state["filter"] = key
    update_filter_buttons()
    from ui.library_view import refresh_library
    refresh_library()


def update_filter_buttons():
    c = THEMES.get(state.get("theme"), THEMES["dark"])
    active = state.get("filter", "all")
    for key, btn in ui_state.filter_buttons.items():
        try:
            if not btn.winfo_exists():
                continue
            btn.configure(
                bg=c["accent"] if key == active else c["btn"],
                fg="#ffffff" if key == active else c["text"])
        except tk.TclError:
            pass


def passes_filter(data):
    f = state.get("filter", "all")
    is_dlc = data.get("is_dlc", False)

    if f == "all":
        return not is_dlc
    if f == "dlc":
        return is_dlc
    if f == "apps":
        return not is_dlc

    installed = data.get("is_installed", False)
    is_steam = data.get("is_steam_owned", False)
    is_epic = data.get("is_epic_owned", False)

    if f == "steam":
        return is_steam and not is_dlc
    if f == "epic":
        return is_epic and not is_dlc
    if f == "installed":
        return installed and not is_dlc
    if f == "local":
        return installed and not is_steam and not is_epic and not is_dlc
    return True


def build_search_and_filters(parent):
    c = THEMES.get(state.get("theme"), THEMES["dark"])

    search_frame = tk.Frame(parent, bg=c["bg"])
    search_frame.pack(fill="x", padx=20, pady=(0, 6))

    ui_state.search_entry = tk.Entry(
        search_frame, font=("Segoe UI", 10),
        bg=c["card"], fg=c["text_muted"],
        insertbackground=c["text"], relief="flat", bd=4)
    ui_state.search_entry.pack(fill="x", ipady=5)
    ui_state.search_entry.insert(0, "Поиск по названию...")

    def on_focus_in(e):
        if ui_state.search_entry.get() == "Поиск по названию...":
            ui_state.search_entry.delete(0, tk.END)
            ui_state.search_entry.config(fg=THEMES[state["theme"]]["text"])

    def on_focus_out(e):
        if not ui_state.search_entry.get():
            ui_state.search_entry.insert(0, "Поиск по названию...")
            ui_state.search_entry.config(fg=THEMES[state["theme"]]["text_muted"])

    def trigger(e=None):
        try:
            ui_state.root.after(300, _do_search)
        except Exception:
            pass

    def _do_search():
        from ui.library_view import refresh_library
        refresh_library()

    ui_state.search_entry.bind("<FocusIn>", on_focus_in)
    ui_state.search_entry.bind("<FocusOut>", on_focus_out)
    ui_state.search_entry.bind("<Return>", _do_search)
    ui_state.search_entry.bind("<KeyRelease>", trigger)

    filter_bar = tk.Frame(parent, bg=c["bg"])
    filter_bar.pack(fill="x", padx=20, pady=(0, 10))

    ui_state.filter_buttons = {}
    for key, label in FILTERS:
        b = tk.Button(filter_bar, text=label, font=("Segoe UI", 9),
                      borderwidth=0, cursor="hand2", padx=10, pady=4,
                      command=lambda k=key: set_filter(k))
        b.pack(side="left", padx=(0, 6))
        ui_state.filter_buttons[key] = b

    update_filter_buttons()
    return search_frame, filter_bar


def get_search_query():
    try:
        e = ui_state.search_entry
        if e is None or not e.winfo_exists():
            return ""
        q = e.get().strip()
        if q == "Поиск по названию...":
            return ""
        return q
    except Exception:
        return ""