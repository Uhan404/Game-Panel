# language: Python 3.10+, file: ui/clipboard.py
# Бинды Ctrl+C/V/X/A и контекстное меню для tk.Entry и tk.Text.

import tkinter as tk
from logger import get_logger

log = get_logger()


def bind_entry_clipboard(entry, parent):
    def paste(e=None):
        try:
            entry.insert(tk.INSERT, parent.clipboard_get())
        except Exception:
            pass
        return "break"

    def copy(e=None):
        try:
            parent.clipboard_clear()
            parent.clipboard_append(entry.selection_get())
        except Exception:
            pass
        return "break"

    def cut(e=None):
        try:
            parent.clipboard_clear()
            parent.clipboard_append(entry.selection_get())
            entry.delete("sel.first", "sel.last")
        except Exception:
            pass
        return "break"

    def select_all(e=None):
        try:
            entry.select_range(0, tk.END)
            entry.icursor(tk.END)
        except Exception:
            pass
        return "break"

    try:
        entry.bind("<Control-v>", paste)
        entry.bind("<Control-V>", paste)
        entry.bind("<Control-c>", copy)
        entry.bind("<Control-C>", copy)
        entry.bind("<Control-x>", cut)
        entry.bind("<Control-X>", cut)
        entry.bind("<Control-a>", select_all)
        entry.bind("<Control-A>", select_all)
        entry.bind("<Shift-Insert>", paste)

        menu = tk.Menu(entry, tearoff=0)
        menu.add_command(label="Вставить", command=paste)
        menu.add_command(label="Копировать", command=copy)
        menu.add_command(label="Вырезать", command=cut)
        menu.add_command(label="Выделить всё", command=select_all)
        entry.bind("<Button-3>", lambda e: menu.tk_popup(e.x_root, e.y_root))
    except Exception as e:
        log.error(f"bind_entry_clipboard: {e}")


def bind_text_clipboard(text_widget, parent):
    menu = tk.Menu(text_widget, tearoff=0)

    def paste(event=None):
        try:
            data = parent.clipboard_get()
        except Exception:
            return "break"
        try:
            if text_widget.tag_ranges(tk.SEL):
                text_widget.delete(tk.SEL_FIRST, tk.SEL_LAST)
        except Exception:
            pass
        text_widget.insert(tk.INSERT, data)
        return "break"

    def copy(event=None):
        try:
            data = text_widget.get(tk.SEL_FIRST, tk.SEL_LAST)
        except Exception:
            return "break"
        try:
            parent.clipboard_clear()
            parent.clipboard_append(data)
        except Exception:
            pass
        return "break"

    def cut(event=None):
        try:
            data = text_widget.get(tk.SEL_FIRST, tk.SEL_LAST)
        except Exception:
            return "break"
        try:
            parent.clipboard_clear()
            parent.clipboard_append(data)
            text_widget.delete(tk.SEL_FIRST, tk.SEL_LAST)
        except Exception:
            pass
        return "break"

    def select_all(event=None):
        text_widget.tag_add(tk.SEL, "1.0", tk.END)
        text_widget.mark_set(tk.INSERT, "1.0")
        text_widget.see(tk.INSERT)
        return "break"

    def clear_all(event=None):
        text_widget.delete("1.0", tk.END)
        return "break"

    menu.add_command(label="Вставить", command=paste)
    menu.add_command(label="Копировать", command=copy)
    menu.add_command(label="Вырезать", command=cut)
    menu.add_separator()
    menu.add_command(label="Выделить всё", command=select_all)
    menu.add_command(label="Очистить", command=clear_all)

    text_widget.bind("<Control-v>", paste)
    text_widget.bind("<Control-V>", paste)
    text_widget.bind("<Control-c>", copy)
    text_widget.bind("<Control-C>", copy)
    text_widget.bind("<Control-x>", cut)
    text_widget.bind("<Control-X>", cut)
    text_widget.bind("<Control-a>", select_all)
    text_widget.bind("<Control-A>", select_all)
    text_widget.bind("<Shift-Insert>", paste)
    text_widget.bind("<Button-3>", lambda e: menu.tk_popup(e.x_root, e.y_root))