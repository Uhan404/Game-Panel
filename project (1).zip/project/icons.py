# language: Python 3.10+, file: icons.py
# Иконки exe + обложки Steam и Epic.

import os
import io
import re
import json
import ctypes
import ctypes.wintypes
import urllib.request
import urllib.parse
import threading

from PIL import Image, ImageTk, ImageDraw, ImageFont
from config import CACHE_DIR, state
from logger import get_logger

log = get_logger()


def _safe_name(title):
    return re.sub(r'[<>:"/\\|?*]', "_", title)


def _cache_path(title):
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
    except OSError as e:
        log.error(f"Не создать CACHE_DIR: {e}")
    return os.path.join(CACHE_DIR, f"{_safe_name(title)}.png")


def _save_cache_atomic(img, path):
    tmp = path + ".tmp"
    try:
        img.save(tmp, "PNG")
        os.replace(tmp, path)
        return True
    except Exception as e:
        log.error(f"Не сохранить кэш {path}: {e}")
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass
        return False


# --- Steam cover ---

STEAM_IMG_FORMATS = [
    "header.jpg",
    "capsule_231x87.jpg",
    "library_600x900.jpg",
    "library_hero.jpg",
    "logo.png",
]


def _crop_square(img, size=72):
    w, h = img.size
    s = min(w, h)
    l, t = (w - s) // 2, (h - s) // 2
    return img.crop((l, t, l + s, t + s)).resize((size, size), Image.Resampling.LANCZOS)


def fetch_steam_cover(title, appid=None):
    try:
        if not appid:
            encoded = urllib.parse.quote(title)
            url = f"https://steamcommunity.com/actions/SearchApps/{encoded}"
            try:
                with urllib.request.urlopen(url, timeout=8) as resp:
                    data = json.loads(resp.read().decode())
                    if data:
                        appid = data[0]["appid"]
            except Exception:
                return None
        if not appid:
            return None
        base = "https://cdn.cloudflare.steamstatic.com/steam/apps"
        for fmt in STEAM_IMG_FORMATS:
            try:
                img_url = f"{base}/{appid}/{fmt}"
                with urllib.request.urlopen(img_url, timeout=8) as r:
                    img = Image.open(io.BytesIO(r.read())).convert("RGBA")
                return _crop_square(img)
            except Exception:
                continue
        return None
    except Exception as e:
        log.error(f"fetch_steam_cover '{title}': {e}")
        return None


# --- Epic cover ---

EPIC_GRAPHQL_ENDPOINTS = [
    "https://launcher.store.epicgames.com/graphql",
    "https://graphql.epicgames.com/graphql",
]

CATALOG_QUERY = """
query catalogQuery($namespace: String!, $id: String!) {
  Catalog {
    catalogOffer(namespace: $namespace, id: $id) {
      title
      keyImages { type url }
    }
  }
}
"""


def _epic_graphql(query, variables):
    body = json.dumps({"query": query, "variables": variables}).encode("utf-8")
    last_err = None
    for endpoint in EPIC_GRAPHQL_ENDPOINTS:
        try:
            req = urllib.request.Request(
                endpoint, data=body,
                headers={
                    "Content-Type": "application/json",
                    "User-Agent": "GamePanel/1.0",
                    "Origin": "https://store.epicgames.com",
                    "Referer": "https://store.epicgames.com/",
                },
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=12) as r:
                return json.loads(r.read().decode("utf-8", errors="ignore"))
        except Exception as e:
            last_err = e
            continue
    if last_err:
        raise last_err
    raise RuntimeError("Все Epic GraphQL endpoints провалились.")


def _pick_epic_image(images):
    wanted = [
        "DieselStoreFrontWide", "OfferImageWide", "Takeover",
        "OfferImageTall", "DieselStoreFrontTall", "Thumbnail",
    ]
    for t in wanted:
        for img in images:
            if img.get("type") == t and img.get("url"):
                return img["url"]
    for img in images:
        if img.get("url"):
            return img["url"]
    return None


def _download_image(url):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "GamePanel/1.0"})
        with urllib.request.urlopen(req, timeout=12) as r:
            img = Image.open(io.BytesIO(r.read())).convert("RGBA")
        return _crop_square(img)
    except Exception as e:
        log.debug(f"Epic image download: {e}")
        return None


def _fetch_epic_cover_by_graphql(namespace, catalog_item_id):
    if not namespace or not catalog_item_id:
        return None
    try:
        data = _epic_graphql(CATALOG_QUERY, {
            "namespace": namespace,
            "id": catalog_item_id,
        })
        offer = (data.get("data", {})
                 .get("Catalog", {})
                 .get("catalogOffer") or {})
        images = offer.get("keyImages") or []
    except Exception as e:
        log.debug(f"Epic GraphQL: {e}")
        return None
    if not images:
        return None
    url = _pick_epic_image(images)
    if not url:
        return None
    return _download_image(url)


def _fetch_epic_cover_by_slug(slug):
    """Fallback по slug — если slug известен."""
    if not slug:
        return None
    for url in [
        f"https://store-content.ak.epicgames.com/api/en-US/content/products/{slug}",
    ]:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "GamePanel/1.0"})
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read().decode("utf-8", errors="ignore"))
        except Exception:
            continue
        for page in (data.get("pages") or []):
            d = page.get("data") or {}
            img_url = (d.get("hero") or d.get("socialImage")
                       or d.get("image") or d.get("featuredMedia"))
            if isinstance(img_url, dict):
                img_url = img_url.get("src") or img_url.get("url")
            if img_url:
                img = _download_image(img_url)
                if img:
                    return img
    return None


def fetch_epic_cover(namespace, catalog_item_id, app_name=None):
    img = _fetch_epic_cover_by_graphql(namespace, catalog_item_id)
    if img:
        return img
    for cand in (app_name, (app_name or "").lower()):
        if cand:
            img = _fetch_epic_cover_by_slug(cand)
            if img:
                return img
    return None


# --- exe icon ---

class _ICONINFO(ctypes.Structure):
    _fields_ = [
        ("fIcon", ctypes.wintypes.BOOL),
        ("xHotspot", ctypes.wintypes.DWORD),
        ("yHotspot", ctypes.wintypes.DWORD),
        ("hbmMask", ctypes.wintypes.HBITMAP),
        ("hbmColor", ctypes.wintypes.HBITMAP),
    ]


class _BITMAP(ctypes.Structure):
    _fields_ = [
        ("bmType", ctypes.wintypes.LONG),
        ("bmWidth", ctypes.wintypes.LONG),
        ("bmHeight", ctypes.wintypes.LONG),
        ("bmWidthBytes", ctypes.wintypes.LONG),
        ("bmPlanes", ctypes.wintypes.WORD),
        ("bmBitsPixel", ctypes.wintypes.WORD),
        ("bmBits", ctypes.c_void_p),
    ]


class _BMIH(ctypes.Structure):
    _fields_ = [
        ("biSize", ctypes.wintypes.DWORD),
        ("biWidth", ctypes.wintypes.LONG),
        ("biHeight", ctypes.wintypes.LONG),
        ("biPlanes", ctypes.wintypes.WORD),
        ("biBitCount", ctypes.wintypes.WORD),
        ("biCompression", ctypes.wintypes.DWORD),
        ("biSizeImage", ctypes.wintypes.DWORD),
        ("biXPelsPerMeter", ctypes.wintypes.LONG),
        ("biYPelsPerMeter", ctypes.wintypes.LONG),
        ("biClrUsed", ctypes.wintypes.DWORD),
        ("biClrImportant", ctypes.wintypes.DWORD),
    ]


def extract_exe_icon(exe_path, size=128):
    """Извлекает иконку из exe через PrivateExtractIconsW.

    Фикс OverflowError: HICON — это HANDLE (void*), на 64-битном Python
    ctypes.wintypes.HICON может быть c_void_p, но PrivateExtractIconsW
    ожидает указатель на массив HICON. Передаём c_void_p явно, а сам
    результат конвертируем в int через .value.
    """
    if not exe_path or not os.path.exists(exe_path) or os.name != "nt":
        return None
    try:
        user32 = ctypes.windll.user32
        gdi32 = ctypes.windll.gdi32

        # Явно задаём прототип, чтобы не полагаться на дефолтный int.
        user32.PrivateExtractIconsW.restype = ctypes.wintypes.UINT
        user32.PrivateExtractIconsW.argtypes = [
            ctypes.wintypes.LPCWSTR, ctypes.c_int,
            ctypes.c_int, ctypes.c_int,
            ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.wintypes.UINT),
            ctypes.wintypes.UINT, ctypes.wintypes.UINT,
        ]
        user32.GetIconInfo.restype = ctypes.wintypes.BOOL
        user32.GetIconInfo.argtypes = [
            ctypes.c_void_p, ctypes.POINTER(_ICONINFO),
        ]
        user32.DestroyIcon.restype = ctypes.wintypes.BOOL
        user32.DestroyIcon.argtypes = [ctypes.c_void_p]
        user32.GetDC.restype = ctypes.wintypes.HDC
        user32.GetDC.argtypes = [ctypes.wintypes.HWND]
        user32.ReleaseDC.restype = ctypes.c_int
        user32.ReleaseDC.argtypes = [ctypes.wintypes.HWND, ctypes.wintypes.HDC]

        gdi32.GetObjectW.restype = ctypes.c_int
        gdi32.GetObjectW.argtypes = [
            ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p,
        ]
        gdi32.CreateCompatibleDC.restype = ctypes.wintypes.HDC
        gdi32.CreateCompatibleDC.argtypes = [ctypes.wintypes.HDC]
        gdi32.SelectObject.restype = ctypes.c_void_p
        gdi32.SelectObject.argtypes = [ctypes.wintypes.HDC, ctypes.c_void_p]
        gdi32.GetDIBits.restype = ctypes.c_int
        gdi32.GetDIBits.argtypes = [
            ctypes.wintypes.HDC, ctypes.c_void_p, ctypes.wintypes.UINT,
            ctypes.wintypes.UINT, ctypes.c_void_p,
            ctypes.POINTER(_BMIH), ctypes.wintypes.UINT,
        ]
        gdi32.DeleteDC.restype = ctypes.wintypes.BOOL
        gdi32.DeleteDC.argtypes = [ctypes.wintypes.HDC]
        gdi32.DeleteObject.restype = ctypes.wintypes.BOOL
        gdi32.DeleteObject.argtypes = [ctypes.c_void_p]

        hicon = ctypes.c_void_p()
        n_icons = user32.PrivateExtractIconsW(
            ctypes.c_wchar_p(exe_path), 0, size, size,
            ctypes.byref(hicon), None, 1, 0,
        )
        if n_icons <= 0 or not hicon.value:
            return None

        info = _ICONINFO()
        if not user32.GetIconInfo(hicon, ctypes.byref(info)):
            user32.DestroyIcon(hicon)
            return None

        bmp = _BITMAP()
        gdi32.GetObjectW(info.hbmColor, ctypes.sizeof(bmp), ctypes.byref(bmp))
        w, h = bmp.bmWidth, bmp.bmHeight
        if w == 0 or h == 0:
            user32.DestroyIcon(hicon)
            if info.hbmColor:
                gdi32.DeleteObject(info.hbmColor)
            if info.hbmMask:
                gdi32.DeleteObject(info.hbmMask)
            return None

        hdc = user32.GetDC(None)
        mem = gdi32.CreateCompatibleDC(hdc)
        bmi = _BMIH(
            biSize=ctypes.sizeof(_BMIH), biWidth=w, biHeight=-h,
            biPlanes=1, biBitCount=32, biCompression=0,
        )
        buf = ctypes.create_string_buffer(w * h * 4)
        old = gdi32.SelectObject(mem, info.hbmColor)
        gdi32.GetDIBits(mem, info.hbmColor, 0, h, buf,
                        ctypes.byref(bmi), 0)
        gdi32.SelectObject(mem, old)
        gdi32.DeleteDC(mem)
        user32.ReleaseDC(None, hdc)

        if info.hbmColor:
            gdi32.DeleteObject(info.hbmColor)
        if info.hbmMask:
            gdi32.DeleteObject(info.hbmMask)
        user32.DestroyIcon(hicon)

        return Image.frombytes("RGBA", (w, h), buf.raw, "raw", "BGRA") \
            .resize((72, 72), Image.Resampling.LANCZOS)
    except Exception as e:
        log.debug(f"extract_exe_icon '{exe_path}': {e}")
        return None


def create_fallback_icon(text, size=(72, 72)):
    img = Image.new("RGBA", size, color=(40, 44, 60, 255))
    draw = ImageDraw.Draw(img)
    words = [w for w in text.split() if w and w[0].isalnum()]
    initials = "".join(w[0] for w in words[:2]).upper() if words else "GM"
    initials = re.sub(r"[^A-Za-zА-Яа-я0-9]", "", initials) or "GM"
    try:
        font = ImageFont.truetype("Segoe UI", 26)
    except IOError:
        font = ImageFont.load_default()
    try:
        bbox = draw.textbbox((0, 0), initials, font=font)
    except Exception:
        bbox = (0, 0, size[0] // 2, size[1] // 2)
    w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
    draw.text(((size[0] - w) / 2, (size[1] - h) / 2 - 2),
              initials, fill=(255, 255, 255), font=font)
    return img


def load_game_icon(title, exe_path, appid=None, label=None,
                   root=None, is_epic=False, namespace=None, catalog_item_id=None):
    cached = _cache_path(title)

    if os.path.exists(cached):
        try:
            img = Image.open(cached).resize((72, 72), Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(img)
            state["icon_cache"][title] = photo
            if label:
                label.config(image=photo)
            return photo
        except Exception:
            try:
                os.remove(cached)
            except OSError:
                pass

    if exe_path and os.path.exists(exe_path):
        img = extract_exe_icon(exe_path)
        if img:
            _save_cache_atomic(img, cached)
            try:
                photo = ImageTk.PhotoImage(img)
                state["icon_cache"][title] = photo
                if label:
                    label.config(image=photo)
                return photo
            except Exception as e:
                log.error(f"PhotoImage из exe {title}: {e}")

    try:
        photo = ImageTk.PhotoImage(create_fallback_icon(title))
    except Exception as e:
        log.error(f"Fallback icon {title}: {e}")
        return None

    state["icon_cache"][title] = photo

    def worker():
        img = None
        try:
            if is_epic:
                img = fetch_epic_cover(namespace, catalog_item_id, app_name=appid)
            if img is None and appid and str(appid).isdigit():
                img = fetch_steam_cover(title, appid)
            if img is None and not is_epic:
                img = fetch_steam_cover(title, None)
        except Exception as e:
            log.error(f"worker иконки '{title}': {e}")
            return
        if img is None:
            return
        _save_cache_atomic(img, cached)

        def apply():
            if not (label and label.winfo_exists()):
                return
            try:
                new_photo = ImageTk.PhotoImage(img)
                state["icon_cache"][title] = new_photo
                label.config(image=new_photo)
            except Exception:
                pass
        if root:
            try:
                root.after(0, apply)
            except Exception:
                pass

    try:
        threading.Thread(target=worker, daemon=True).start()
    except Exception as e:
        log.error(f"Старт worker иконки '{title}': {e}")

    return photo