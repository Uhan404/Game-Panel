# language: Python 3.10+, file: epic_oauth.py
# Epic OAuth Device Code Flow. Fallback-путь.

import os
import json
import time
import base64
import urllib.request
import urllib.parse
import urllib.error
import webbrowser
import threading
import tkinter as tk
from tkinter import messagebox

from logger import get_logger
from epic_games import build_epic_install_url, build_epic_launch_url, make_epic_slug

log = get_logger()

EPIC_CLIENTS = [
    ("xyza78911yFOApzIuyHeoK6AklG9ZpaR",
     "0OYu5GSrOoYri2HGmKe7A6icoGcVbJc1XmymjMClPIk"),
    ("34a02cf8f4414e29b15921876da36f9a",
     "34a02cf8f4414e29b15921876da36f9a"),
]

DEVICE_AUTH_URL = ("https://account-public-service-prod.ol.epicgames.com"
                   "/account/api/oauth/deviceAuthorization")
TOKEN_URL = ("https://account-public-service-prod.ol.epicgames.com"
             "/account/api/oauth/token")
ACCOUNT_URL = ("https://account-public-service-prod.ol.epicgames.com"
               "/account/api/public/account")
LIBRARY_URL = ("https://library-service.live.use1a.on.epicgames.com"
               "/library/api/public/items")

DEV_PORTAL_URL = "https://dev.epicgames.com/portal/"

TOKEN_FILE = os.path.join(os.getcwd(), "epic_auth_token.json")


def _http_post(url, data_dict, headers=None, timeout=15):
    body = urllib.parse.urlencode(data_dict).encode("utf-8")
    h = {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "GamePanel/1.0",
        "Accept": "application/json",
    }
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, data=body, headers=h, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="ignore"))


def _http_get(url, headers=None, timeout=15):
    h = {"User-Agent": "GamePanel/1.0", "Accept": "application/json"}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, headers=h, method="GET")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="ignore"))


def _basic_auth_header(client_id, client_secret):
    raw = f"{client_id}:{client_secret}".encode("utf-8")
    return base64.b64encode(raw).decode("ascii")


def load_saved_token():
    if not os.path.exists(TOKEN_FILE):
        return None
    try:
        with open(TOKEN_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        log.warning(f"load_saved_token: {e}")
        return None


def save_token(token_data):
    try:
        with open(TOKEN_FILE, "w", encoding="utf-8") as f:
            json.dump(token_data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        log.error(f"save_token: {e}")
        return False


def delete_token():
    try:
        if os.path.exists(TOKEN_FILE):
            os.remove(TOKEN_FILE)
    except Exception:
        pass


def is_token_valid(token_data):
    if not token_data:
        return False
    expires_at = token_data.get("expires_at", 0)
    return time.time() < expires_at - 60


def refresh_token_if_needed(token_data):
    if not token_data:
        return None
    if is_token_valid(token_data):
        return token_data
    rt = token_data.get("refresh_token")
    if not rt:
        return None
    try:
        data = _http_post(TOKEN_URL, {
            "grant_type": "refresh_token",
            "refresh_token": rt,
            "token_type": "eg1",
        }, headers={
            "Authorization": "basic " + token_data.get("_auth_basic", ""),
        })
        data["expires_at"] = time.time() + data.get("expires_in", 3600)
        data["_auth_basic"] = token_data.get("_auth_basic", "")
        save_token(data)
        return data
    except Exception as e:
        log.warning(f"refresh_token: {e}")
        return None


def _request_device_code(client_id, client_secret):
    auth_basic = _basic_auth_header(client_id, client_secret)
    url = f"{DEVICE_AUTH_URL}?grant_type=device_code"
    req = urllib.request.Request(url, method="POST", headers={
        "Authorization": "basic " + auth_basic,
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "GamePanel/1.0",
        "Accept": "application/json",
    })
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read().decode("utf-8", errors="ignore")), auth_basic
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", errors="ignore")
        except Exception:
            pass
        try:
            data = json.loads(body)
            err_msg = (data.get("errorMessage")
                       or data.get("errorCode")
                       or body[:200])
        except Exception:
            err_msg = body[:200] or f"HTTP {e.code}"
        return None, f"HTTP {e.code}: {err_msg}"
    except Exception as e:
        return None, f"Сеть: {e}"


def _poll_token(auth_basic, device_code, interval, expires_in):
    deadline = time.time() + expires_in
    interval = max(interval or 3, 2)
    while time.time() < deadline:
        time.sleep(interval)
        try:
            req = urllib.request.Request(
                TOKEN_URL, method="POST",
                data=urllib.parse.urlencode({
                    "grant_type": "device_code",
                    "device_code": device_code,
                    "token_type": "eg1",
                }).encode("utf-8"),
                headers={
                    "Authorization": "basic " + auth_basic,
                    "Content-Type": "application/x-www-form-urlencoded",
                    "User-Agent": "GamePanel/1.0",
                    "Accept": "application/json",
                },
            )
            with urllib.request.urlopen(req, timeout=15) as r:
                data = json.loads(r.read().decode("utf-8", errors="ignore"))
                data["expires_at"] = time.time() + data.get("expires_in", 3600)
                data["_auth_basic"] = auth_basic
                return data, None
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8", errors="ignore")
            except Exception:
                pass
            if "authorization_pending" in body:
                continue
            if "slow_down" in body:
                interval += 2
                continue
            if "expired_token" in body:
                return None, "Код истёк. Попробуй снова."
            if "access_denied" in body:
                return None, "Пользователь отклонил вход."
            return None, f"HTTP {e.code}: {body[:200]}"
        except Exception as e:
            log.debug(f"poll: {e}")
            continue
    return None, "Таймаут ожидания подтверждения."


def show_device_code_dialog(parent, on_success=None):
    dlg = tk.Toplevel(parent)
    dlg.title("Вход в Epic")
    dlg.geometry("580x560")
    dlg.resizable(False, False)
    dlg.transient(parent)
    dlg.grab_set()
    x = parent.winfo_x() + (parent.winfo_width() // 2) - 290
    y = parent.winfo_y() + (parent.winfo_height() // 2) - 280
    dlg.geometry(f"+{x}+{y}")

    try:
        from config import THEMES, state
        c = THEMES.get(state.get("theme"), THEMES["dark"])
    except Exception:
        c = {"bg": "#0b0e14", "card": "#1a1f2c", "text": "#f0f2f5",
             "text_muted": "#8a94a6", "accent": "#00d26a",
             "btn": "#242b3d", "danger": "#ef4444"}

    dlg.configure(bg=c["bg"])

    tk.Label(dlg, text="Вход в Epic", bg=c["bg"], fg=c["text"],
             font=("Segoe UI", 14, "bold")).pack(pady=(18, 6))

    status_lbl = tk.Label(dlg, text="Запрашиваю код у Epic…",
                          bg=c["bg"], fg=c["text_muted"],
                          font=("Segoe UI", 10), wraplength=540)
    status_lbl.pack(padx=20, pady=(0, 10))

    code_var = tk.StringVar(value="——————")
    code_lbl = tk.Label(dlg, textvariable=code_var,
                        bg=c["card"], fg=c["accent"],
                        font=("Consolas", 26, "bold"),
                        padx=20, pady=16)
    code_lbl.pack(padx=20, pady=(0, 10), fill="x")

    url_lbl = tk.Label(dlg, text="", bg=c["bg"], fg=c["text_muted"],
                       font=("Segoe UI", 9), wraplength=540, justify="center")
    url_lbl.pack(padx=20, pady=(0, 10))

    button_row = tk.Frame(dlg, bg=c["bg"])
    button_row.pack(padx=20, pady=(0, 6), fill="x")

    def copy_code():
        code = code_var.get().strip()
        if not code or set(code) == {"—"}:
            status_lbl.config(text="Код ещё не получен от Epic.",
                              fg=c["danger"])
            return
        try:
            dlg.clipboard_clear()
            dlg.clipboard_append(code)
            status_lbl.config(text="Код скопирован. Вставь в браузере.",
                              fg=c["accent"])
        except Exception:
            pass

    def open_url():
        try:
            webbrowser.open("https://www.epicgames.com/activate")
        except Exception as e:
            status_lbl.config(text=f"Не удалось открыть браузер: {e}",
                              fg=c["danger"])

    tk.Button(button_row, text="Скопировать код",
              bg=c["btn"], fg=c["text"], borderwidth=0, cursor="hand2",
              command=copy_code).pack(side="left", fill="x", expand=True,
                                     ipady=6, padx=(0, 6))
    tk.Button(button_row, text="Открыть epicgames.com/activate",
              bg=c["accent"], fg="#ffffff", borderwidth=0, cursor="hand2",
              command=open_url).pack(side="left", fill="x", expand=True,
                                     ipady=6)

    footer = tk.Label(dlg, text="", bg=c["bg"], fg=c["text_muted"],
                      font=("Segoe UI", 9), wraplength=540)
    footer.pack(pady=(8, 4))

    extra_row = tk.Frame(dlg, bg=c["bg"])
    extra_row.pack(padx=20, pady=(0, 20), fill="x")

    def open_dev_portal():
        try:
            webbrowser.open(DEV_PORTAL_URL)
        except Exception:
            pass

    tk.Button(extra_row, text="Зарегистрировать своё приложение в Epic Dev Portal",
              bg=c["bg"], fg=c["text_muted"], borderwidth=0, cursor="hand2",
              font=("Segoe UI", 8, "underline"),
              command=open_dev_portal).pack(fill="x")

    result = {"token": None, "error": None, "done": False}

    def worker():
        last_err = ""
        for cid, secret in EPIC_CLIENTS:
            device, auth_basic = _request_device_code(cid, secret)
            if isinstance(auth_basic, str) and device is None:
                last_err = auth_basic
                log.warning(f"device code для {cid[:12]}…: {auth_basic}")
                continue
            if not device:
                last_err = "пустой ответ от Epic"
                continue

            user_code = device.get("user_code", "")
            device_code = device.get("device_code", "")
            interval = device.get("interval", 3)
            expires_in = device.get("expires_in", 600)

            def ui_code(code=user_code):
                code_var.set(code)
                url_lbl.config(text="Открой epicgames.com/activate и введи код")
                status_lbl.config(text="Ожидаю подтверждения…",
                                  fg=c["text_muted"])

            try:
                parent.after(0, ui_code)
            except Exception:
                pass

            token, err = _poll_token(auth_basic, device_code,
                                     interval, expires_in)
            if token:
                result["token"] = token
                break
            last_err = err or "неизвестно"
            log.warning(f"poll для {cid[:12]}…: {err}")

        result["error"] = None if result["token"] else last_err
        result["done"] = True

    threading.Thread(target=worker, daemon=True).start()

    def check_done():
        if result["done"]:
            if result["token"]:
                save_token(result["token"])
                status_lbl.config(text="Успех. Можно закрыть окно.",
                                  fg=c["accent"])
                messagebox.showinfo("Epic", "Вход выполнен.")
                dlg.destroy()
                if on_success:
                    on_success()
            else:
                status_lbl.config(text="Не удалось войти", fg=c["danger"])
                footer.config(
                    text=(f"Ошибка: {result['error']}\n\n"
                          f"Если 401 authentication_failed — Epic отозвал "
                          f"этот client_id. Единственный стабильный путь — "
                          f"зарегистрировать своё приложение в Dev Portal."))
            return
        dlg.after(800, check_done)

    dlg.after(800, check_done)
    dlg.wait_window()


def is_logged_in():
    token = load_saved_token()
    if not token:
        return False, None
    token = refresh_token_if_needed(token)
    if not token:
        return False, None
    try:
        data = _http_get(
            f"{ACCOUNT_URL}/{token.get('account_id','')}",
            headers={"Authorization": f"bearer {token['access_token']}"})
        name = data.get("displayName") or data.get("email") or "Epic-аккаунт"
        return True, name
    except Exception as e:
        log.warning(f"is_logged_in check: {e}")
        return False, None


def fetch_epic_library():
    token = load_saved_token()
    token = refresh_token_if_needed(token)
    if not token:
        return None, "Нет валидного токена. Сначала войди."

    account_id = token.get("account_id")
    if not account_id:
        return None, "В токене нет account_id."

    headers = {
        "Authorization": f"bearer {token['access_token']}",
        "Accept": "application/json",
    }

    url = f"{LIBRARY_URL}?includeMetadata=true"
    try:
        data = _http_get(url, headers=headers, timeout=20)
    except urllib.error.HTTPError as e:
        if e.code == 401:
            delete_token()
            return None, "Токен истёк. Войди заново."
        return None, f"HTTP {e.code} от Epic Library API."

    records = (data.get("records")
               or data.get("response", {}).get("records")
               or [])
    if not records:
        return None, "Библиотека пуста или API вернул неожиданную структуру."

    out = {}
    for rec in records:
        catalog_id = rec.get("catalogItemId") or rec.get("id") or ""
        namespace = rec.get("namespace") or ""
        app_name = rec.get("appName") or rec.get("productId") or catalog_id
        title = rec.get("sandboxName") or rec.get("productName") or app_name
        slug = rec.get("productSlug") or ""

        is_dlc = rec.get("isDLC", False)
        if namespace and catalog_id:
            try:
                cat_url = (f"https://catalog-public-service-prod06.ol.epicgames.com"
                           f"/catalog/api/shared/namespace/{namespace}/bulk/items"
                           f"?id={catalog_id}&includeDLCDetails=true"
                           f"&includeMainGameDetails=true&country=US&locale=en")
                cat_data = _http_get(cat_url, headers=headers, timeout=10)
                item = cat_data.get(catalog_id) if isinstance(cat_data, dict) else None
                if isinstance(item, dict):
                    title = item.get("title") or title
                    namespace = item.get("namespace") or namespace
                    slug = item.get("productSlug") or slug
                    
                    main_game = item.get("mainGameItem")
                    categories = item.get("categories") or []
                    if main_game or "digitalextra" in categories or "addons" in categories:
                        is_dlc = True
            except Exception:
                pass

        if not slug:
            slug = make_epic_slug(title)

        entry = {
            "name": title,
            "appid": app_name,
            "namespace": namespace,
            "catalog_item_id": catalog_id,
            "slug": slug,
            "is_installed": False,
            "is_epic_owned": True,
            "source": "epic",
            "is_dlc": is_dlc,
        }
        entry["launch_url"] = build_epic_launch_url(entry)
        entry["install_url"] = build_epic_install_url(entry, interactive=False)
        out[title] = entry

    return out, None