# language: Python 3.10+, file: epic_auth_embedded.py
# Авторизация Epic через встроенный legendary.exe + прямой Epic Library API.

import os
import sys
import json
import shutil
import tempfile
import threading
import subprocess
import urllib.request
import urllib.error
import urllib.parse
import webbrowser
import tkinter as tk
from tkinter import messagebox

from logger import get_logger
from epic_games import (build_epic_install_url, build_epic_launch_url,
                        is_hex, is_non_game)

log = get_logger()

LEGENDARY_CONFIG_DIRS = [
    os.path.join(os.path.expanduser("~"), ".config", "legendary"),
    os.path.join(os.environ.get("LOCALAPPDATA", ""), "legendary"),
]

RUNTIME_DIR = os.path.join(tempfile.gettempdir(), "GamePanel")

LIBRARY_URL = ("https://library-service.live.use1a.on.epicgames.com"
               "/library/api/public/items?includeMetadata=true")

CATALOG_BULK_URL = ("https://catalog-public-service-prod06.ol.epicgames.com"
                    "/catalog/api/shared/namespace/{namespace}/bulk/items"
                    "?id={catalog_id}&includeDLCDetails=true"
                    "&includeMainGameDetails=true&country=US&locale=en")


def _get_clean_env():
    """Очищает переменные окружения от мусора PyInstaller, чтобы legendary.exe работал."""
    env = os.environ.copy()
    for key in ("PYTHONHOME", "PYTHONPATH", "PYTHONEXECUTABLE", "PYTHONSTARTUP"):
        env.pop(key, None)
    if hasattr(sys, "_MEIPASS"):
        env["PATH"] = env["PATH"].replace(sys._MEIPASS + os.pathsep, "")
        env["PATH"] = env["PATH"].replace(sys._MEIPASS, "")
    return env


def _find_embedded_legendary():
    if hasattr(sys, "_MEIPASS"):
        candidate = os.path.join(sys._MEIPASS, "legendary.exe")
        if os.path.isfile(candidate):
            return candidate
    here = os.path.dirname(os.path.abspath(__file__))
    candidate = os.path.join(here, "legendary.exe")
    if os.path.isfile(candidate):
        return candidate
    path_exe = shutil.which("legendary")
    if path_exe:
        return path_exe
    return None


def extract_embedded_legendary():
    src = _find_embedded_legendary()
    if not src:
        return None, ("Встроенный legendary.exe не найден. "
                      "Положи legendary.exe рядом с main.py "
                      "или в корень проекта перед сборкой.")
    try:
        os.makedirs(RUNTIME_DIR, exist_ok=True)
    except OSError as e:
        return None, f"Не создать {RUNTIME_DIR}: {e}"

    dst = os.path.join(RUNTIME_DIR, "legendary.exe")
    try:
        if os.path.isfile(dst) and os.path.getsize(dst) == os.path.getsize(src):
            return dst, None
    except OSError:
        pass
    try:
        shutil.copy2(src, dst)
        return dst, None
    except Exception as e:
        return None, f"Не распаковать legendary.exe: {e}"


def legendary_config_dir():
    for d in LEGENDARY_CONFIG_DIRS:
        if d and os.path.isdir(d):
            return d
    return LEGENDARY_CONFIG_DIRS[0]


def is_logged_in():
    user = _load_user_json()
    if user:
        name = user.get("displayName") or user.get("account_id")
        if name:
            return True, name
    return False, None


def _load_user_json():
    try:
        cfg = legendary_config_dir()
        user_file = os.path.join(cfg, "user.json")
        if os.path.isfile(user_file):
            with open(user_file, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as e:
        log.warning(f"_load_user_json: {e}")
    return None


def logout():
    try:
        cfg = legendary_config_dir()
        user_file = os.path.join(cfg, "user.json")
        if os.path.isfile(user_file):
            os.remove(user_file)
        return True, "Логин сброшен."
    except Exception as e:
        return False, f"Ошибка: {e}"


def _run_legendary(args, timeout=60):
    exe_path, err = extract_embedded_legendary()
    if not exe_path:
        return "", err or "legendary не найден", -1

    try:
        res = subprocess.run(
            [exe_path] + args,
            capture_output=True, text=True, timeout=timeout,
            encoding="utf-8", errors="ignore",
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            env=_get_clean_env()
        )
        return res.stdout or "", res.stderr or "", res.returncode
    except subprocess.TimeoutExpired:
        return "", "legendary не ответил за отведённое время", -1
    except Exception as e:
        return "", f"Ошибка запуска legendary: {e}", -1


def _parse_legendary_json(stdout):
    if not stdout:
        return None
    text = stdout.strip()
    for start_char, end_char in (("[", "]"), ("{", "}")):
        idx = text.find(start_char)
        if idx < 0:
            continue
        last = text.rfind(end_char)
        if last <= idx:
            continue
        chunk = text[idx:last + 1]
        try:
            return json.loads(chunk)
        except json.JSONDecodeError:
            continue
    return None


def _http_get_json(url, headers):
    req = urllib.request.Request(url, headers=headers, method="GET")
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode("utf-8", errors="ignore"))


def fetch_epic_library():
    user = _load_user_json()
    if not user:
        return None, "Epic не привязан (нет user.json)."
    token = user.get("access_token")
    if not token:
        return None, "В user.json нет access_token."

    headers = {
        "Authorization": f"bearer {token}",
        "Accept": "application/json",
        "User-Agent": "GamePanel/1.0",
    }

    data = None
    try:
        data = _http_get_json(LIBRARY_URL, headers)
    except urllib.error.HTTPError as e:
        if e.code == 401:
            log.info("Epic Library API 401, обновляю токен через legendary...")
            _run_legendary(["list", "--json"], timeout=90)
            user = _load_user_json()
            if user:
                token = user.get("access_token")
                headers["Authorization"] = f"bearer {token}"
                try:
                    data = _http_get_json(LIBRARY_URL, headers)
                except Exception as e2:
                    return None, f"Ошибка Epic Library API после обновления токена: {e2}"
            else:
                return None, "Не удалось обновить токен."
        else:
            return None, f"HTTP {e.code} от Epic Library API."

    if not data:
        return None, "Пустой ответ от Epic Library API."

    records = (data.get("records") or data.get("response", {}).get("records") or [])
    if not records:
        return None, "Библиотека Epic пуста."

    out = {}
    for rec in records:
        catalog_id = rec.get("catalogItemId") or rec.get("id") or ""
        namespace = rec.get("namespace") or ""
        app_name = rec.get("appName") or rec.get("productId") or catalog_id
        title = rec.get("sandboxName") or rec.get("productName") or app_name
        slug = rec.get("productSlug") or rec.get("urlSlug") or ""

        if not namespace or not catalog_id:
            continue

        is_dlc = rec.get("isDLC", False)
        
        try:
            cat_url = CATALOG_BULK_URL.format(namespace=namespace, catalog_id=catalog_id)
            cat_data = _http_get_json(cat_url, headers)
            item = cat_data.get(catalog_id) if isinstance(cat_data, dict) else None
            if isinstance(item, dict):
                title = item.get("title") or title
                slug = item.get("urlSlug") or item.get("productSlug") or slug
                
                main_game = item.get("mainGameItem")
                categories = item.get("categories") or []
                if main_game or "digitalextra" in categories or "addons" in categories:
                    is_dlc = True

                release_info = item.get("releaseInfo") or []
                if isinstance(release_info, list) and release_info:
                    for ri in release_info:
                        if isinstance(ri, dict):
                            real_app_name = ri.get("appId")
                            if real_app_name:
                                app_name = real_app_name
                                break
        except Exception as e:
            log.debug(f"Catalog bulk '{catalog_id}': {e}")

        if is_non_game(app_name):
            continue
        if is_dlc and title.endswith(" Content"):
            continue

        entry = {
            "name": title,
            "appid": app_name,
            "namespace": namespace,
            "catalog_item_id": catalog_id,
            "slug": slug,
            "is_installed": False,
            "is_epic_owned": True,
            "source": "epic",
            "is_dlc": is_dlc,
        }
        entry["launch_url"] = build_epic_launch_url(entry)
        entry["install_url"] = build_epic_install_url(entry, interactive=False)
        out[title] = entry

    log.info(f"Epic Library API: получено {len(out)} игр.")
    return out, None


def run_legendary_auth(parent, on_success=None):
    """Открывает браузер и показывает окно для ввода кода авторизации."""
    exe_path, err = extract_embedded_legendary()
    if not exe_path:
        messagebox.showerror("Epic", err)
        return

    # ВАЖНО: Удаляем старый битый user.json перед авторизацией, чтобы legendary не падал
    cfg = legendary_config_dir()
    user_file = os.path.join(cfg, "user.json")
    if os.path.exists(user_file):
        try:
            os.remove(user_file)
        except Exception as e:
            log.warning(f"Не удалось удалить старый user.json: {e}")

    # Открываем браузер для входа
    webbrowser.open("https://legendary.gl/epiclogin")

    dlg = tk.Toplevel(parent)
    dlg.title("Вход в Epic Games")
    dlg.geometry("550x340")
    dlg.resizable(False, False)
    dlg.transient(parent)
    dlg.grab_set()

    try:
        from config import THEMES, state
        c = THEMES.get(state.get("theme"), THEMES["dark"])
    except Exception:
        c = {"bg": "#0b0e14", "card": "#1a1f2c", "text": "#f0f2f5",
             "text_muted": "#8a94a6", "accent": "#00d26a",
             "btn": "#242b3d", "danger": "#ef4444"}

    dlg.configure(bg=c["bg"])

    tk.Label(dlg, text="Вход в Epic Games", bg=c["bg"], fg=c["text"],
             font=("Segoe UI", 14, "bold")).pack(pady=(15, 10))

    text_instructions = (
        "1. В браузере, который только что открылся, войдите в аккаунт Epic.\n"
        "2. После входа скопируйте значение поля \"authorizationCode\".\n"
        "3. Вставьте этот код в поле ниже и нажмите «Войти».\n"
        "⚠ Код действует 5 минут. Не затягивайте с вводом."
    )
    tk.Label(dlg, text=text_instructions, bg=c["bg"], fg=c["text_muted"],
             font=("Segoe UI", 9), justify="left").pack(padx=20, pady=(0, 10), anchor="w")

    code_var = tk.StringVar()
    entry = tk.Entry(dlg, textvariable=code_var, font=("Consolas", 10),
                     bg=c["card"], fg=c["text"], insertbackground=c["text"],
                     relief="flat", bd=6)
    entry.pack(fill="x", padx=20, pady=(0, 10))
    entry.focus_set()

    # --- НАТИВНАЯ ВСТАВКА ТЕКСТА (Меню ПКМ + Горячие клавиши) ---
    def paste_text(event=None):
        try:
            entry.insert(tk.INSERT, dlg.clipboard_get())
        except Exception:
            pass
        return "break"

    menu = tk.Menu(entry, tearoff=0)
    menu.add_command(label="Вставить", command=paste_text)
    menu.add_command(label="Копировать", command=lambda: entry.event_generate("<<Copy>>"))
    menu.add_command(label="Вырезать", command=lambda: entry.event_generate("<<Cut>>"))
    menu.add_separator()
    menu.add_command(label="Очистить", command=lambda: entry.delete(0, tk.END))

    entry.bind("<Button-3>", lambda e: menu.tk_popup(e.x_root, e.y_root))
    entry.bind("<Control-v>", paste_text)
    entry.bind("<Control-V>", paste_text)
    entry.bind("<Shift-Insert>", paste_text)
    # -------------------------------------------------------------

    status_lbl = tk.Label(dlg, text="", bg=c["bg"], fg=c["danger"], font=("Segoe UI", 9), wraplength=500)
    status_lbl.pack(pady=(0, 5))

    def submit():
        code = code_var.get().strip()
        if not code:
            status_lbl.config(text="Код не может быть пустым.")
            return

        status_lbl.config(text="Авторизация...", fg=c["accent"])
        dlg.update()

        try:
            startupinfo = None
            if os.name == 'nt':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE

            # Отправляем чистый код строкой, БЕЗ json.dumps
            res = subprocess.run(
                [exe_path, "auth", "--code", code],
                capture_output=True, text=True, timeout=30,
                startupinfo=startupinfo,
                env=_get_clean_env()
            )
            
            log.debug(f"Legendary auth output:\nSTDOUT: {res.stdout}\nSTDERR: {res.stderr}\nRET: {res.returncode}")
            
            # Проверяем, появился ли user.json, или legendary выдал ошибку
            ok, name = is_logged_in()
            if ok:
                dlg.destroy()
                messagebox.showinfo("Epic", f"Вход выполнен: {name}")
                if on_success:
                    on_success()
            else:
                err_out = (res.stderr or res.stdout or "").strip()
                err_out = err_out.split("\n")[-1][:150]
                status_lbl.config(text=f"Ошибка: {err_out}")
                log.error(f"legendary auth failed. Output: {err_out}")
                
        except Exception as e:
            status_lbl.config(text=f"Ошибка запуска: {e}")

    btn_frame = tk.Frame(dlg, bg=c["bg"])
    btn_frame.pack(fill="x", padx=20, pady=(5, 15))

    tk.Button(btn_frame, text="Войти", bg=c["accent"], fg="#ffffff",
              borderwidth=0, cursor="hand2", font=("Segoe UI", 10, "bold"),
              command=submit).pack(side="right", ipady=4, ipadx=15)

    tk.Button(btn_frame, text="Отмена", bg=c["btn"], fg=c["text"],
              borderwidth=0, cursor="hand2", font=("Segoe UI", 10),
              command=dlg.destroy).pack(side="right", padx=(0, 10), ipady=4, ipadx=15)