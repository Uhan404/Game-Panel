# language: Python 3.10+, file: logger.py
# Единый логгер приложения.

import os
import logging
from logging.handlers import RotatingFileHandler

LOG_FILE = os.path.join(os.getcwd(), "game_panel.log")
_logger = None


def get_logger():
    global _logger
    if _logger is not None:
        return _logger

    _logger = logging.getLogger("GamePanel")
    _logger.setLevel(logging.DEBUG)

    if _logger.handlers:
        return _logger

    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # В файл — с ротацией, максимум 1 МБ × 3 файла.
    try:
        fh = RotatingFileHandler(LOG_FILE, maxBytes=1_000_000,
                                 backupCount=3, encoding="utf-8")
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(fmt)
        _logger.addHandler(fh)
    except Exception:
        # Если файл недоступен — тихо идём без файлового handler'а.
        pass

    # В консоль — только WARNING и выше, чтобы не мусорить.
    try:
        ch = logging.StreamHandler()
        ch.setLevel(logging.WARNING)
        ch.setFormatter(fmt)
        _logger.addHandler(ch)
    except Exception:
        pass

    return _logger