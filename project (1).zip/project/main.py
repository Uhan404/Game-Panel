# language: Python 3.10+, file: main.py
import os
import sys
import subprocess
import traceback

# --- ФИКС ДЛЯ PYINSTALLER ---
if getattr(sys, 'frozen', False):
    os.chdir(os.path.dirname(sys.executable))
# ----------------------------

def _ensure_python_version():
    if sys.version_info < (3, 10):
        print(f"Требуется Python 3.10+. Сейчас {sys.version}")
        sys.exit(1)

def _pip_install(package):
    try:
        res = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--user", "--upgrade",
             package],
            capture_output=True, text=True, timeout=180)
        return res.returncode == 0
    except Exception:
        return False


def _bootstrap_dependencies():
    """При запуске .exe всё уже внутри — функция ничего не делает.
    При запуске из исходников ставит только Pillow. Legendary-gl
    пользователь ставит сам, если хочет синхронизацию Epic."""
    required = {"PIL": "pillow"}
    missing = []
    for mod, pip_name in required.items():
        try:
            __import__(mod)
        except ImportError:
            missing.append(pip_name)

    if not missing:
        return

    print(f"Устанавливаю зависимости: {', '.join(missing)}")
    for pkg in missing:
        ok = _pip_install(pkg)
        print(f"  {'OK' if ok else 'FAIL'}: {pkg}")


def _safe_run():
    try:
        _ensure_python_version()
        _bootstrap_dependencies()

        from config import load_config, load_library
        from ui import build_window

        load_config()
        load_library()
        build_window()
    except Exception as e:
        tb = traceback.format_exc()
        print("=== Критическая ошибка запуска ===")
        print(tb)
        try:
            from logger import get_logger
            get_logger().critical(f"Запуск провален:\n{tb}")
        except Exception:
            pass
        try:
            import tkinter as tk
            from tkinter import messagebox
            r = tk.Tk()
            r.withdraw()
            messagebox.showerror("Game Panel — ошибка запуска",
                                 f"Приложение не запустилось:\n\n{e}")
            r.destroy()
        except Exception:
            pass
        sys.exit(1)


if __name__ == "__main__":
    _safe_run()